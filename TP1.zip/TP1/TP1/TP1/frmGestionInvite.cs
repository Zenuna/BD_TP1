﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmGestionInvite : Form
    {
        public String noUtilisateur;
        static String maChaineDeConnexion = "Data Source = sqlinfo.cgodin.qc.ca; Initial Catalog = BD5B6TP1_KoumaJouanique; Persist Security Info=True;User ID = 5B6Kouma;Password=1PetitDioulaBanchi";
        SqlConnection maConnexion = new SqlConnection(maChaineDeConnexion);
        public frmGestionInvite()
        {
            InitializeComponent();
        }

        private void inviteBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.inviteBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bD5B6TP1_KoumaJouaniqueDataSet);

        }

        private void frmGestionInvite_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Invite'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.inviteTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Invite);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.PrenomNomClient'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.prenomNomClientTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.PrenomNomClient);
        }

        private void btnPremierInvite_Click(object sender, EventArgs e)
        {
            inviteBindingSource.MoveFirst();
        }

        private void btnInvitePrecedent_Click(object sender, EventArgs e)
        {
            inviteBindingSource.MovePrevious();
        }

        private void btnDernierInvite_Click(object sender, EventArgs e)
        {
            inviteBindingSource.MoveLast();
        }

        private void btnInviteSuivant_Click(object sender, EventArgs e)
        {
            inviteBindingSource.MoveNext();
        }

        private void btnSupprInvite_Click(object sender, EventArgs e)
        {
            String strNoInvite = dgInvite.CurrentRow.Cells[0].Value.ToString();
            String strPrenomNomInvite = dgInvite.CurrentRow.Cells[1].Value.ToString();
            DialogResult res = MessageBox.Show(this, "Voulez-vous vraiment supprimer l'invité " + strPrenomNomInvite + "?", "Suppression d'un invité", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
            if (res == DialogResult.OK)
            {
                inviteBindingSource.RemoveCurrent();
                /*SqlCommand maCommande = new SqlCommand(" DELETE FROM Invite WHERE NoInvite=" + strNoInvite, maConnexion);
                maConnexion.Open();
                maCommande.ExecuteNonQuery();
                maConnexion.Close();*/
                try
                {
                    tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                }
                catch (DBConcurrencyException erreur)
                {
                    String strNomComplet = erreur.Row["dgPrenomNom"].ToString();
                    MessageBox.Show("Conflit d'accès concurrentiel pour l'invité " + strNomComplet + ".Aucun enregistrement possible.", "Conflit d'accès");
                }
            }
        }

        private void btnAjouterInvite_Click(object sender, EventArgs e)
        {
            if (dgInvite.Rows.Count == 9) MessageBox.Show("Vous ne pouvez pas avoir plus de 9 invités par client");
            else if (cbClient.SelectedValue == null) MessageBox.Show("Sélectionner un client dans la liste de clients");
            else
            {
                inviteBindingSource.CancelEdit();
                String strClientNo = cbClient.SelectedValue.ToString();
                int intClientNo = -1;
                int.TryParse(strClientNo, out intClientNo);
                if (dgInvite.Rows.Count <= 0)
                {
                    inviteBindingSource.AddNew();
                    dgInvite.CurrentRow.Cells[0].Value = intClientNo + 1;
                }
                else
                {
                    dgInvite.Sort(dgInvite.Columns["dgNoInvite"], ListSortDirection.Ascending);
                    int intValeurCourante = -1;
                    int intCompteur = 0;
                    Boolean bTrouver = false;
                    foreach (DataGridViewRow row in dgInvite.Rows)
                    {
                        if (intCompteur == 0) intValeurCourante = int.Parse(row.Cells[0].Value.ToString());
                        else if (!bTrouver)
                        {
                            if (intValeurCourante + 1 != int.Parse(row.Cells[0].Value.ToString()))
                            {
                                bTrouver = true;
                                intValeurCourante += 1;
                            }
                            else
                            {
                                intValeurCourante = int.Parse(row.Cells[0].Value.ToString());
                            }
                        }
                        intCompteur++;
                    }
                    if (!bTrouver) intValeurCourante += 1;
                    inviteBindingSource.AddNew();
                    dgInvite.CurrentRow.Cells[0].Value = intValeurCourante;
                }
            }
        }

        private void dgInvite_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {
            String msgErreur = "";
            if (dgInvite["dgNoInvite", e.RowIndex].Value != null && cbClient.SelectedValue != null)
            {
                String strClientNo = cbClient.SelectedValue.ToString();
                int intClientNo = -1;
                int.TryParse(strClientNo, out intClientNo);
                String strNoInvite = dgInvite["dgNoInvite", e.RowIndex].Value.ToString();
                String strNomInvite = dgInvite["dgPrenomNom", e.RowIndex].Value.ToString();

                if (strClientNo.Trim() == "" || strNoInvite.Trim() == "" || strNomInvite.Trim() == "")
                {
                    msgErreur = "Aucune colonne ne peut être vide, ni le nom du client";
                    e.Cancel = true;
                }
                else
                {
                    SqlCommand maCommande = new SqlCommand(" SELECT NoInvite FROM Invite WHERE NoInvite = '" + strNoInvite + "'", maConnexion);
                    maConnexion.Open();
                    SqlDataReader monReader = maCommande.ExecuteReader();
                    if (monReader.Read())
                    {
                        monReader.Close();
                        /*maCommande = new SqlCommand(" UPDATE Invite SET NomPrenom = '" + strNomInvite + " WHERE NoInvite = " + strNoInvite, maConnexion);
                        maCommande.ExecuteNonQuery();*/
                        try
                        {
                            tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                        }
                        catch (DBConcurrencyException erreur)
                        {
                            String strNomComplet = erreur.Row["dgPrenomNom"].ToString();
                            MessageBox.Show("Conflit d'accès concurrentiel pour l'invité " + strNomComplet + ".Aucun enregistrement possible.", "Conflit d'accès");
                        }
                    }
                    else
                    {
                        monReader.Close();
                        /*maCommande = new SqlCommand(" INSERT INTO Invite VALUES ('" + strNoInvite + "','" + strNomInvite + "','" + strClientNo + "')", maConnexion);
                        maCommande.ExecuteNonQuery();*/
                        try
                        {
                            tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                        }
                        catch (DBConcurrencyException erreur)
                        {
                            String strNomComplet = erreur.Row["dgPrenomNom"].ToString();
                            MessageBox.Show("Conflit d'accès concurrentiel pour l'invité " + strNomComplet + ".Aucun enregistrement possible.", "Conflit d'accès");
                        }
                    }
                    maConnexion.Close();
                }
                dgInvite.Rows[e.RowIndex].ErrorText = msgErreur;
            }
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {

        }
    }
}
