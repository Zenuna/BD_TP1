﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmGestionUtilisateur : Form
    {
        public String noUtilisateur;
        static String maChaineDeConnexion = "Data Source = sqlinfo.cgodin.qc.ca; Initial Catalog = BD5B6TP1_KoumaJouanique; Persist Security Info=True;User ID = 5B6Kouma;Password=1PetitDioulaBanchi";
        SqlConnection maConnexion = new SqlConnection(maChaineDeConnexion);
        public frmGestionUtilisateur()
        {
            InitializeComponent();
        }

        private void utilisateurBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.utilisateurBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bD5B6TP1_KoumaJouaniqueDataSet);

        }

        private void frmGestionUtilisateur_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.typeUtilisateur'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.typeUtilisateurTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.typeUtilisateur);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Utilisateur'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.utilisateurTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Utilisateur);

        }

        private void btnPremierUtil_Click(object sender, EventArgs e)
        {
            utilisateurBindingSource.MoveFirst();
        }

        private void btnUtilPrecedent_Click(object sender, EventArgs e)
        {
            utilisateurBindingSource.MovePrevious();
        }

        private void btnUtilSuivant_Click(object sender, EventArgs e)
        {
            utilisateurBindingSource.MoveNext();
        }

        private void btnDernierUtil_Click(object sender, EventArgs e)
        {
            utilisateurBindingSource.MoveLast();
        }

        private void btnAjouterUtil_Click(object sender, EventArgs e)
        {
            utilisateurBindingSource.CancelEdit();
            utilisateurBindingSource.AddNew();
            maConnexion.Open();
            SqlCommand maCommande = new SqlCommand(" SELECT MAX(NoUtilisateur) FROM Utilisateur ", maConnexion);
            dynamic NoUtil = maCommande.ExecuteScalar();
            maConnexion.Close();
            utilisateurDataGridView.CurrentRow.Cells[0].Value = NoUtil + 1;
            utilisateurDataGridView.CurrentRow.Cells[1].ReadOnly = false;
        }

        private void btnSupprUtil_Click(object sender, EventArgs e)
        {
            String strNoUtil = utilisateurDataGridView.CurrentRow.Cells[0].Value.ToString();
            String strNomUtil = utilisateurDataGridView.CurrentRow.Cells[1].Value.ToString();
            if(strNoUtil != noUtilisateur)
            {
                DialogResult res = MessageBox.Show(this, "Voulez-vous vraiment supprimer l'utilisateur " + strNomUtil + "?", "Suppression d'un compte", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
                if(res == DialogResult.OK)
                {
                    utilisateurBindingSource.RemoveCurrent();
                    //SqlCommand maCommande = new SqlCommand(" DELETE FROM Utilisateur WHERE NoUtilisateur=" + strNoUtil, maConnexion);
                    //maConnexion.Open();
                    //maCommande.ExecuteNonQuery();
                    //maConnexion.Close();
                    try
                    {
                        tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                    }
                    catch (DBConcurrencyException erreur)
                    {
                        MessageBox.Show("Conflit d'accès concurrentiel pour l'utilisateur " + erreur.Row["dgTxtNomUtil"].ToString() + ".Aucun enregistrement possible.", "Conflit d'accès");
                    }
                }

            }
            else
            {
                MessageBox.Show("Vous ne pouvez supprimer votre propre compte","Suppression d'un compte");
            }


        }
        
        private void utilisateurDataGridView_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {
            String msgErreur = "";
            if(utilisateurDataGridView["dgTxtNoUtil", e.RowIndex].Value != null)
            {
                String strNoUtil = utilisateurDataGridView["dgTxtNoUtil", e.RowIndex].Value.ToString();
                String strNomUtil = utilisateurDataGridView["dgTxtNomUtil", e.RowIndex].Value.ToString();
                String strMdeP = utilisateurDataGridView["dgTxtMdeP", e.RowIndex].Value.ToString();
                String strNoType = utilisateurDataGridView["dgTypeUtilisateur", e.RowIndex].Value.ToString();
                if (strNomUtil.Trim() == "" || strMdeP.Trim() == "" || strNoType.Trim() == "")
                {
                    msgErreur = "Aucune colonne ne peut être vide";
                    e.Cancel = true;
                }
                else
                {

                    SqlCommand maCommande = new SqlCommand(" SELECT NoUtilisateur, NoTypeUtilisateur FROM Utilisateur WHERE NomUtilisateur = '" + strNomUtil+"'", maConnexion);
                    maConnexion.Open();
                    SqlDataReader monReader = maCommande.ExecuteReader();
                    if (monReader.Read())
                        {
                        if (!monReader["NoUtilisateur"].ToString().Equals(strNoUtil))
                        {
                            monReader.Close();
                            msgErreur = "Le nom d'utilisateur doit être unique";
                            e.Cancel = true;
                        }
                        else
                        {
                            if (monReader["NoUtilisateur"].ToString().Equals(noUtilisateur) && !monReader["NoTypeUtilisateur"].ToString().Equals(strNoType))
                            {
                                msgErreur = "Vous ne pouvez pas modifier votre propre type d'utilisateur";
                                e.Cancel = true;
                            }
                            else
                            {
                                monReader.Close();
                                //maCommande = new SqlCommand(" UPDATE Utilisateur SET MotDePasse = '" + strMdeP + "', NoTypeUtilisateur ='" + strNoType + "'" + " WHERE NoUtilisateur = " + strNoUtil, maConnexion);
                                //maCommande.ExecuteNonQuery();
                                try
                                {
                                    tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                                }
                                catch (DBConcurrencyException erreur)
                                {
                                    MessageBox.Show("Conflit d'accès concurrentiel pour l'utilisateur " + erreur.Row["dgTxtNomUtil"].ToString() + ".Aucun enregistrement possible.", "Conflit d'accès");
                                }
                            }
                        }
                    }
                    else
                    {
                        monReader.Close();
                        //maCommande = new SqlCommand(" INSERT INTO Utilisateur VALUES ('" + strNoUtil + "','" + strNomUtil + "','" + strMdeP + "','" + strNoType + "')", maConnexion);
                        //maCommande.ExecuteNonQuery();
                        try
                        {
                            tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                        }
                        catch(DBConcurrencyException erreur)
                        {
                            MessageBox.Show("Conflit d'accès concurrentiel pour l'utilisateur " + erreur.Row["dgTxtNomUtil"].ToString() + ".Aucun enregistrement possible.", "Conflit d'accès");
                        }
                        utilisateurDataGridView["dgTxtNomUtil", e.RowIndex].ReadOnly = true;
                    }
                    maConnexion.Close();
                }
                utilisateurDataGridView.Rows[e.RowIndex].ErrorText = msgErreur;
             }
        }
    }
}
