﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TP1
{
    public partial class frmConnexion : Form
    {
        static String maChaineDeConnexion = "Data Source = sqlinfo.cgodin.qc.ca; Initial Catalog = BD5B6TP1_KoumaJouanique; Persist Security Info=True;User ID = 5B6Kouma;Password=1PetitDioulaBanchi";
        public frmConnexion()
        {
            InitializeComponent();
        }

        private void btnConnexion_Click(object sender, EventArgs e)
        {
            SqlConnection maConnexion = new SqlConnection(maChaineDeConnexion);
            maConnexion.Open();
            String maRequeteSQL = "select NoUtilisateur from Utilisateur where NomUtilisateur = '" + txtNomUtilisateur.Text.Trim() + "' and MotDePasse = '" + txtMDP.Text.Trim() + "'";
            SqlCommand maCommande = new SqlCommand(maRequeteSQL, maConnexion);
            dynamic NoUtilisateur = maCommande.ExecuteScalar();
            if (NoUtilisateur == null) lblInfo.Text = "Connexion échouée";
            else
            {
                lblInfo.Text = "Connexion réussie";
                maRequeteSQL = "select t.Identification from typeUtilisateur T inner join Utilisateur U on t.NoTypeUtilisateur = u.NoTypeUtilisateur where u.NoUtilisateur = '" + NoUtilisateur + "'";
                maCommande = new SqlCommand(maRequeteSQL, maConnexion);
                dynamic Identification = maCommande.ExecuteScalar();
                if(Identification == "Admin")
                {
                    this.Hide();
                    frmMenuAdmin fMenuAdmin = new frmMenuAdmin();
                    fMenuAdmin.noUtilisateur = NoUtilisateur + "";
                    fMenuAdmin.ShowDialog();
                    txtNomUtilisateur.Text = "";
                    txtMDP.Text = "";
                    lblInfo.Text = "Tapez votre nom d'utilisateur et votre mot de passe";
                    this.Show();
                }
                else if(Identification == "Préposé")
                {
                    this.Hide();
                    frmMenuPrepose fMenuPrepose = new frmMenuPrepose();
                    fMenuPrepose.ShowDialog();
                    txtNomUtilisateur.Text = "";
                    txtMDP.Text = "";
                    lblInfo.Text = "Tapez votre nom d'utilisateur et votre mot de passe";
                    this.Show();
                }
                //frmMenu fMenu = new frmMenu();
                //fReserVoyag.noClient = noClient.ToString();
               // fMenu.ShowDialog();
            }

            maConnexion.Close();

        }
    }
}
