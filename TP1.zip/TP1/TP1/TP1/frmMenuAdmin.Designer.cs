﻿namespace TP1
{
    partial class frmMenuAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBienvenue = new System.Windows.Forms.Label();
            this.btnGererUsers = new System.Windows.Forms.Button();
            this.btnQuitter = new System.Windows.Forms.Button();
            this.btnDeconnexion = new System.Windows.Forms.Button();
            this.btnVisualiserRapport = new System.Windows.Forms.Button();
            this.btnReserverChambre = new System.Windows.Forms.Button();
            this.btnGererChambre = new System.Windows.Forms.Button();
            this.btnPlannifierSoins = new System.Windows.Forms.Button();
            this.btnGererSOins = new System.Windows.Forms.Button();
            this.btnGererAssistantEtSoins = new System.Windows.Forms.Button();
            this.btnGererCLientEtInvite = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblBienvenue
            // 
            this.lblBienvenue.AutoSize = true;
            this.lblBienvenue.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBienvenue.Location = new System.Drawing.Point(225, 9);
            this.lblBienvenue.Name = "lblBienvenue";
            this.lblBienvenue.Size = new System.Drawing.Size(324, 48);
            this.lblBienvenue.TabIndex = 0;
            this.lblBienvenue.Text = "Bienvenue Chèr(e) administrateur\r\n        Que désirez vous faire ?";
            this.lblBienvenue.Click += new System.EventHandler(this.lblBienvenue_Click);
            // 
            // btnGererUsers
            // 
            this.btnGererUsers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGererUsers.Location = new System.Drawing.Point(23, 60);
            this.btnGererUsers.Name = "btnGererUsers";
            this.btnGererUsers.Size = new System.Drawing.Size(171, 89);
            this.btnGererUsers.TabIndex = 1;
            this.btnGererUsers.Text = "1. Gérer les utilisateurs";
            this.btnGererUsers.UseVisualStyleBackColor = true;
            this.btnGererUsers.Click += new System.EventHandler(this.btnGererUsers_Click);
            // 
            // btnQuitter
            // 
            this.btnQuitter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitter.Location = new System.Drawing.Point(564, 487);
            this.btnQuitter.Name = "btnQuitter";
            this.btnQuitter.Size = new System.Drawing.Size(171, 89);
            this.btnQuitter.TabIndex = 2;
            this.btnQuitter.Text = "10. Quitter l’application";
            this.btnQuitter.UseVisualStyleBackColor = true;
            // 
            // btnDeconnexion
            // 
            this.btnDeconnexion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeconnexion.Location = new System.Drawing.Point(564, 379);
            this.btnDeconnexion.Name = "btnDeconnexion";
            this.btnDeconnexion.Size = new System.Drawing.Size(171, 89);
            this.btnDeconnexion.TabIndex = 3;
            this.btnDeconnexion.Text = "9. Se déconnecter";
            this.btnDeconnexion.UseVisualStyleBackColor = true;
            // 
            // btnVisualiserRapport
            // 
            this.btnVisualiserRapport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVisualiserRapport.Location = new System.Drawing.Point(564, 273);
            this.btnVisualiserRapport.Name = "btnVisualiserRapport";
            this.btnVisualiserRapport.Size = new System.Drawing.Size(171, 89);
            this.btnVisualiserRapport.TabIndex = 4;
            this.btnVisualiserRapport.Text = "8. Visualiser des rapports";
            this.btnVisualiserRapport.UseVisualStyleBackColor = true;
            // 
            // btnReserverChambre
            // 
            this.btnReserverChambre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReserverChambre.Location = new System.Drawing.Point(564, 169);
            this.btnReserverChambre.Name = "btnReserverChambre";
            this.btnReserverChambre.Size = new System.Drawing.Size(171, 89);
            this.btnReserverChambre.TabIndex = 5;
            this.btnReserverChambre.Text = "7. Réserver des chambres (pour les clients)";
            this.btnReserverChambre.UseVisualStyleBackColor = true;
            // 
            // btnGererChambre
            // 
            this.btnGererChambre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGererChambre.Location = new System.Drawing.Point(564, 60);
            this.btnGererChambre.Name = "btnGererChambre";
            this.btnGererChambre.Size = new System.Drawing.Size(171, 89);
            this.btnGererChambre.TabIndex = 6;
            this.btnGererChambre.Text = "6. Gérer les chambres";
            this.btnGererChambre.UseVisualStyleBackColor = true;
            // 
            // btnPlannifierSoins
            // 
            this.btnPlannifierSoins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlannifierSoins.Location = new System.Drawing.Point(23, 487);
            this.btnPlannifierSoins.Name = "btnPlannifierSoins";
            this.btnPlannifierSoins.Size = new System.Drawing.Size(171, 89);
            this.btnPlannifierSoins.TabIndex = 7;
            this.btnPlannifierSoins.Text = "5. Planifier des soins pour les clients et leurs invités";
            this.btnPlannifierSoins.UseVisualStyleBackColor = true;
            // 
            // btnGererSOins
            // 
            this.btnGererSOins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGererSOins.Location = new System.Drawing.Point(23, 379);
            this.btnGererSOins.Name = "btnGererSOins";
            this.btnGererSOins.Size = new System.Drawing.Size(171, 89);
            this.btnGererSOins.TabIndex = 8;
            this.btnGererSOins.Text = "4. Gérer les soins";
            this.btnGererSOins.UseVisualStyleBackColor = true;
            // 
            // btnGererAssistantEtSoins
            // 
            this.btnGererAssistantEtSoins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGererAssistantEtSoins.Location = new System.Drawing.Point(23, 273);
            this.btnGererAssistantEtSoins.Name = "btnGererAssistantEtSoins";
            this.btnGererAssistantEtSoins.Size = new System.Drawing.Size(171, 89);
            this.btnGererAssistantEtSoins.TabIndex = 9;
            this.btnGererAssistantEtSoins.Text = "3. Gérer les assistants et les soins qu’ils offrent";
            this.btnGererAssistantEtSoins.UseVisualStyleBackColor = true;
            // 
            // btnGererCLientEtInvite
            // 
            this.btnGererCLientEtInvite.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGererCLientEtInvite.Location = new System.Drawing.Point(23, 169);
            this.btnGererCLientEtInvite.Name = "btnGererCLientEtInvite";
            this.btnGererCLientEtInvite.Size = new System.Drawing.Size(171, 89);
            this.btnGererCLientEtInvite.TabIndex = 10;
            this.btnGererCLientEtInvite.Text = "2. Gérer les clients et leurs invités";
            this.btnGererCLientEtInvite.UseVisualStyleBackColor = true;
            // 
            // frmMenuAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(757, 588);
            this.Controls.Add(this.btnGererCLientEtInvite);
            this.Controls.Add(this.btnGererAssistantEtSoins);
            this.Controls.Add(this.btnGererSOins);
            this.Controls.Add(this.btnPlannifierSoins);
            this.Controls.Add(this.btnGererChambre);
            this.Controls.Add(this.btnReserverChambre);
            this.Controls.Add(this.btnVisualiserRapport);
            this.Controls.Add(this.btnDeconnexion);
            this.Controls.Add(this.btnQuitter);
            this.Controls.Add(this.btnGererUsers);
            this.Controls.Add(this.lblBienvenue);
            this.Name = "frmMenuAdmin";
            this.Text = "frmMenuAdmin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBienvenue;
        private System.Windows.Forms.Button btnGererUsers;
        private System.Windows.Forms.Button btnQuitter;
        private System.Windows.Forms.Button btnDeconnexion;
        private System.Windows.Forms.Button btnVisualiserRapport;
        private System.Windows.Forms.Button btnReserverChambre;
        private System.Windows.Forms.Button btnGererChambre;
        private System.Windows.Forms.Button btnPlannifierSoins;
        private System.Windows.Forms.Button btnGererSOins;
        private System.Windows.Forms.Button btnGererAssistantEtSoins;
        private System.Windows.Forms.Button btnGererCLientEtInvite;
    }
}