﻿namespace TP1
{
    partial class frmGestionUtilisateur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnPremierUtil = new System.Windows.Forms.Button();
            this.btnUtilPrecedent = new System.Windows.Forms.Button();
            this.btnUtilSuivant = new System.Windows.Forms.Button();
            this.btnDernierUtil = new System.Windows.Forms.Button();
            this.utilisateurBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.btnAjouterUtil = new System.Windows.Forms.Button();
            this.btnSupprUtil = new System.Windows.Forms.Button();
            this.errMessage = new System.Windows.Forms.ErrorProvider(this.components);
            this.utilisateurTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.UtilisateurTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.typeUtilisateurBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.typeUtilisateurTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typeUtilisateurTableAdapter();
            this.utilisateurDataGridView = new System.Windows.Forms.DataGridView();
            this.dgTxtNoUtil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgTxtNomUtil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgTxtMdeP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgTypeUtilisateur = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.btnAnnuler = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.utilisateurBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMessage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeUtilisateurBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.utilisateurDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPremierUtil
            // 
            this.btnPremierUtil.Location = new System.Drawing.Point(12, 247);
            this.btnPremierUtil.Name = "btnPremierUtil";
            this.btnPremierUtil.Size = new System.Drawing.Size(103, 23);
            this.btnPremierUtil.TabIndex = 8;
            this.btnPremierUtil.Text = "Premier utilisateur";
            this.btnPremierUtil.UseVisualStyleBackColor = true;
            this.btnPremierUtil.Click += new System.EventHandler(this.btnPremierUtil_Click);
            // 
            // btnUtilPrecedent
            // 
            this.btnUtilPrecedent.Location = new System.Drawing.Point(121, 247);
            this.btnUtilPrecedent.Name = "btnUtilPrecedent";
            this.btnUtilPrecedent.Size = new System.Drawing.Size(117, 23);
            this.btnUtilPrecedent.TabIndex = 9;
            this.btnUtilPrecedent.Text = "Utilisateur précédent";
            this.btnUtilPrecedent.UseVisualStyleBackColor = true;
            this.btnUtilPrecedent.Click += new System.EventHandler(this.btnUtilPrecedent_Click);
            // 
            // btnUtilSuivant
            // 
            this.btnUtilSuivant.Location = new System.Drawing.Point(244, 247);
            this.btnUtilSuivant.Name = "btnUtilSuivant";
            this.btnUtilSuivant.Size = new System.Drawing.Size(111, 23);
            this.btnUtilSuivant.TabIndex = 10;
            this.btnUtilSuivant.Text = "Utilisateur suivant";
            this.btnUtilSuivant.UseVisualStyleBackColor = true;
            this.btnUtilSuivant.Click += new System.EventHandler(this.btnUtilSuivant_Click);
            // 
            // btnDernierUtil
            // 
            this.btnDernierUtil.Location = new System.Drawing.Point(361, 247);
            this.btnDernierUtil.Name = "btnDernierUtil";
            this.btnDernierUtil.Size = new System.Drawing.Size(107, 23);
            this.btnDernierUtil.TabIndex = 11;
            this.btnDernierUtil.Text = "Dernier utilisateur";
            this.btnDernierUtil.UseVisualStyleBackColor = true;
            this.btnDernierUtil.Click += new System.EventHandler(this.btnDernierUtil_Click);
            // 
            // utilisateurBindingSource
            // 
            this.utilisateurBindingSource.DataMember = "Utilisateur";
            this.utilisateurBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnAjouterUtil
            // 
            this.btnAjouterUtil.Location = new System.Drawing.Point(12, 276);
            this.btnAjouterUtil.Name = "btnAjouterUtil";
            this.btnAjouterUtil.Size = new System.Drawing.Size(103, 23);
            this.btnAjouterUtil.TabIndex = 12;
            this.btnAjouterUtil.Text = "Ajouter utilisateur";
            this.btnAjouterUtil.UseVisualStyleBackColor = true;
            this.btnAjouterUtil.Click += new System.EventHandler(this.btnAjouterUtil_Click);
            // 
            // btnSupprUtil
            // 
            this.btnSupprUtil.Location = new System.Drawing.Point(361, 276);
            this.btnSupprUtil.Name = "btnSupprUtil";
            this.btnSupprUtil.Size = new System.Drawing.Size(107, 23);
            this.btnSupprUtil.TabIndex = 14;
            this.btnSupprUtil.Text = "Supprimer utilisateur";
            this.btnSupprUtil.UseVisualStyleBackColor = true;
            this.btnSupprUtil.Click += new System.EventHandler(this.btnSupprUtil_Click);
            // 
            // errMessage
            // 
            this.errMessage.ContainerControl = this;
            // 
            // utilisateurTableAdapter
            // 
            this.utilisateurTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = this.utilisateurTableAdapter;
            // 
            // typeUtilisateurBindingSource
            // 
            this.typeUtilisateurBindingSource.DataMember = "typeUtilisateur";
            this.typeUtilisateurBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // typeUtilisateurTableAdapter
            // 
            this.typeUtilisateurTableAdapter.ClearBeforeFill = true;
            // 
            // utilisateurDataGridView
            // 
            this.utilisateurDataGridView.AllowUserToAddRows = false;
            this.utilisateurDataGridView.AllowUserToDeleteRows = false;
            this.utilisateurDataGridView.AutoGenerateColumns = false;
            this.utilisateurDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.utilisateurDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.utilisateurDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgTxtNoUtil,
            this.dgTxtNomUtil,
            this.dgTxtMdeP,
            this.dgTypeUtilisateur});
            this.utilisateurDataGridView.DataSource = this.utilisateurBindingSource;
            this.utilisateurDataGridView.Location = new System.Drawing.Point(12, 12);
            this.utilisateurDataGridView.Name = "utilisateurDataGridView";
            this.utilisateurDataGridView.RowHeadersWidth = 40;
            this.utilisateurDataGridView.Size = new System.Drawing.Size(456, 220);
            this.utilisateurDataGridView.TabIndex = 14;
            this.utilisateurDataGridView.RowValidating += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.utilisateurDataGridView_RowValidating);
            // 
            // dgTxtNoUtil
            // 
            this.dgTxtNoUtil.DataPropertyName = "NoUtilisateur";
            this.dgTxtNoUtil.HeaderText = "Numéro d\'utilisateur";
            this.dgTxtNoUtil.Name = "dgTxtNoUtil";
            this.dgTxtNoUtil.ReadOnly = true;
            // 
            // dgTxtNomUtil
            // 
            this.dgTxtNomUtil.DataPropertyName = "NomUtilisateur";
            this.dgTxtNomUtil.HeaderText = "Nom d\'utilisateur";
            this.dgTxtNomUtil.MaxInputLength = 20;
            this.dgTxtNomUtil.Name = "dgTxtNomUtil";
            this.dgTxtNomUtil.ReadOnly = true;
            // 
            // dgTxtMdeP
            // 
            this.dgTxtMdeP.DataPropertyName = "MotDePasse";
            this.dgTxtMdeP.HeaderText = "Mot de Passe";
            this.dgTxtMdeP.MaxInputLength = 20;
            this.dgTxtMdeP.Name = "dgTxtMdeP";
            // 
            // dgTypeUtilisateur
            // 
            this.dgTypeUtilisateur.DataPropertyName = "NoTypeUtilisateur";
            this.dgTypeUtilisateur.DataSource = this.typeUtilisateurBindingSource;
            this.dgTypeUtilisateur.DisplayMember = "Identification";
            this.dgTypeUtilisateur.HeaderText = "Type d\'utilisateur";
            this.dgTypeUtilisateur.Name = "dgTypeUtilisateur";
            this.dgTypeUtilisateur.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgTypeUtilisateur.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgTypeUtilisateur.ValueMember = "NoTypeUtilisateur";
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(214, 276);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(58, 23);
            this.btnAnnuler.TabIndex = 15;
            this.btnAnnuler.Text = "Annuler";
            // 
            // frmGestionUtilisateur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 331);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.utilisateurDataGridView);
            this.Controls.Add(this.btnSupprUtil);
            this.Controls.Add(this.btnAjouterUtil);
            this.Controls.Add(this.btnDernierUtil);
            this.Controls.Add(this.btnUtilSuivant);
            this.Controls.Add(this.btnUtilPrecedent);
            this.Controls.Add(this.btnPremierUtil);
            this.Name = "frmGestionUtilisateur";
            this.Text = "Gestion utilisateur";
            this.Load += new System.EventHandler(this.frmGestionUtilisateur_Load);
            ((System.ComponentModel.ISupportInitialize)(this.utilisateurBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMessage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeUtilisateurBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.utilisateurDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource utilisateurBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.UtilisateurTableAdapter utilisateurTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button btnPremierUtil;
        private System.Windows.Forms.Button btnUtilPrecedent;
        private System.Windows.Forms.Button btnUtilSuivant;
        private System.Windows.Forms.Button btnDernierUtil;
        private System.Windows.Forms.Button btnAjouterUtil;
        private System.Windows.Forms.Button btnSupprUtil;
        private System.Windows.Forms.ErrorProvider errMessage;
        private System.Windows.Forms.BindingSource typeUtilisateurBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typeUtilisateurTableAdapter typeUtilisateurTableAdapter;
        private System.Windows.Forms.DataGridView utilisateurDataGridView;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgTxtNoUtil;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgTxtNomUtil;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgTxtMdeP;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgTypeUtilisateur;
    }
}