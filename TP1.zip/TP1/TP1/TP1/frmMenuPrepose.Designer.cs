﻿namespace TP1
{
    partial class frmMenuPrepose
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBienvenue = new System.Windows.Forms.Label();
            this.btnQuitter = new System.Windows.Forms.Button();
            this.btnDeconnexion = new System.Windows.Forms.Button();
            this.btnReserverChambre = new System.Windows.Forms.Button();
            this.btnPlanifierSoinsClientEtInvite = new System.Windows.Forms.Button();
            this.btnGererClientEtInvite = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblBienvenue
            // 
            this.lblBienvenue.AutoSize = true;
            this.lblBienvenue.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBienvenue.Location = new System.Drawing.Point(213, 9);
            this.lblBienvenue.Name = "lblBienvenue";
            this.lblBienvenue.Size = new System.Drawing.Size(270, 48);
            this.lblBienvenue.TabIndex = 1;
            this.lblBienvenue.Text = "Bienvenue chèr(e) préposé\r\n   Que désirez vous faire ?";
            // btnQuitter
            // 
            this.btnQuitter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitter.Location = new System.Drawing.Point(280, 146);
            this.btnQuitter.Name = "btnQuitter";
            this.btnQuitter.Size = new System.Drawing.Size(171, 89);
            this.btnQuitter.TabIndex = 2;
            this.btnQuitter.Text = "5. Quitter l’application";
            this.btnQuitter.UseVisualStyleBackColor = true;
            this.btnQuitter.Click += new System.EventHandler(this.btnQuitter_Click);
            // 
            // btnDeconnexion
            // 
            this.btnDeconnexion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeconnexion.Location = new System.Drawing.Point(542, 206);
            this.btnDeconnexion.Name = "btnDeconnexion";
            this.btnDeconnexion.Size = new System.Drawing.Size(171, 89);
            this.btnDeconnexion.TabIndex = 3;
            this.btnDeconnexion.Text = "4. Se déconnecter";
            this.btnDeconnexion.UseVisualStyleBackColor = true;
            this.btnDeconnexion.Click += new System.EventHandler(this.btnDeconnexion_Click);
            // 
            // btnReserverChambre
            // 
            this.btnReserverChambre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReserverChambre.Location = new System.Drawing.Point(542, 84);
            this.btnReserverChambre.Name = "btnReserverChambre";
            this.btnReserverChambre.Size = new System.Drawing.Size(171, 89);
            this.btnReserverChambre.TabIndex = 4;
            this.btnReserverChambre.Text = "3. Réserver des chambres";
            this.btnReserverChambre.UseVisualStyleBackColor = true;
            // 
            // btnPlanifierSoinsClientEtInvite
            // 
            this.btnPlanifierSoinsClientEtInvite.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlanifierSoinsClientEtInvite.Location = new System.Drawing.Point(12, 206);
            this.btnPlanifierSoinsClientEtInvite.Name = "btnPlanifierSoinsClientEtInvite";
            this.btnPlanifierSoinsClientEtInvite.Size = new System.Drawing.Size(171, 89);
            this.btnPlanifierSoinsClientEtInvite.TabIndex = 5;
            this.btnPlanifierSoinsClientEtInvite.Text = "2. Planifier des soins pour les clients et leurs invités";
            this.btnPlanifierSoinsClientEtInvite.UseVisualStyleBackColor = true;
            // 
            // btnGererClientEtInvite
            // 
            this.btnGererClientEtInvite.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGererClientEtInvite.Location = new System.Drawing.Point(12, 84);
            this.btnGererClientEtInvite.Name = "btnGererClientEtInvite";
            this.btnGererClientEtInvite.Size = new System.Drawing.Size(171, 89);
            this.btnGererClientEtInvite.TabIndex = 6;
            this.btnGererClientEtInvite.Text = "1. Gérer les clients et leurs invités ";
            this.btnGererClientEtInvite.UseVisualStyleBackColor = true;
            // 
            // frmMenuPrepose
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 327);
            this.Controls.Add(this.btnGererClientEtInvite);
            this.Controls.Add(this.btnPlanifierSoinsClientEtInvite);
            this.Controls.Add(this.btnReserverChambre);
            this.Controls.Add(this.btnDeconnexion);
            this.Controls.Add(this.btnQuitter);
            this.Controls.Add(this.lblBienvenue);
            this.Name = "frmMenuPrepose";
            this.Text = "frmMenuPrepose";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBienvenue;
        private System.Windows.Forms.Button btnQuitter;
        private System.Windows.Forms.Button btnDeconnexion;
        private System.Windows.Forms.Button btnReserverChambre;
        private System.Windows.Forms.Button btnPlanifierSoinsClientEtInvite;
        private System.Windows.Forms.Button btnGererClientEtInvite;
    }
}