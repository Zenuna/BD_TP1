﻿namespace TP1
{
    partial class frmMenuGestionAssistantSoin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAssistant = new System.Windows.Forms.Button();
            this.btnSoinsAssistants = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAssistant
            // 
            this.btnAssistant.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssistant.Location = new System.Drawing.Point(12, 12);
            this.btnAssistant.Name = "btnAssistant";
            this.btnAssistant.Size = new System.Drawing.Size(234, 89);
            this.btnAssistant.TabIndex = 14;
            this.btnAssistant.Text = "1. Gestion des assistants";
            this.btnAssistant.UseVisualStyleBackColor = true;
            this.btnAssistant.Click += new System.EventHandler(this.btnAssistant_Click);
            // 
            // btnSoinsAssistants
            // 
            this.btnSoinsAssistants.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoinsAssistants.Location = new System.Drawing.Point(12, 107);
            this.btnSoinsAssistants.Name = "btnSoinsAssistants";
            this.btnSoinsAssistants.Size = new System.Drawing.Size(234, 89);
            this.btnSoinsAssistants.TabIndex = 13;
            this.btnSoinsAssistants.Text = "2. Gestion des soins d\'assistant";
            this.btnSoinsAssistants.UseVisualStyleBackColor = true;
            this.btnSoinsAssistants.Click += new System.EventHandler(this.btnSoinsAssistants_Click);
            // 
            // frmMenuGestionAssistantSoin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(260, 215);
            this.Controls.Add(this.btnAssistant);
            this.Controls.Add(this.btnSoinsAssistants);
            this.Name = "frmMenuGestionAssistantSoin";
            this.Text = "frmMenuGestionAssistantSoin";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAssistant;
        private System.Windows.Forms.Button btnSoinsAssistants;
    }
}