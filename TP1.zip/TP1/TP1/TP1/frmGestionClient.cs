﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmGestionClient : Form
    {
        public String noUtilisateur;
        static String maChaineDeConnexion = "Data Source = sqlinfo.cgodin.qc.ca; Initial Catalog = BD5B6TP1_KoumaJouanique; Persist Security Info=True;User ID = 5B6Kouma;Password=1PetitDioulaBanchi";
        SqlConnection maConnexion = new SqlConnection(maChaineDeConnexion);
        public frmGestionClient()
        {
            InitializeComponent();
        }

        private void clientBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.clientBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bD5B6TP1_KoumaJouaniqueDataSet);

        }

        private void frmGestionClient_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Invite'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.inviteTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Invite);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Invite'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.inviteTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Invite);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Client'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.clientTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Client);

        }

        private void btnPremierClient_Click(object sender, EventArgs e)
        {
            clientBindingSource.MoveFirst();
        }

        private void btnClientPrecedent_Click(object sender, EventArgs e)
        {
            clientBindingSource.MovePrevious();
        }

        private void btnClientSuivant_Click(object sender, EventArgs e)
        {
            clientBindingSource.MoveNext();
        }

        private void btnDernierClient_Click(object sender, EventArgs e)
        {
            clientBindingSource.MoveLast();
        }

        private void btnAjouterClient_Click(object sender, EventArgs e)
        {
            clientBindingSource.CancelEdit();
            clientBindingSource.AddNew();
            maConnexion.Open();
            SqlCommand maCommande = new SqlCommand(" SELECT MAX(NoClient) FROM Client ", maConnexion);
            dynamic NoClient = maCommande.ExecuteScalar();
            if(dgClient.RowCount > 1)
            {
                dgClient.CurrentRow.Cells[0].Value = NoClient + 10; 
            }
            else
            {
                dgClient.CurrentRow.Cells[0].Value = 10;
            }
            maConnexion.Close();
            dgClient.CurrentRow.Cells[7].Value = DateTime.Now;
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {

        }

        private void btnSupprClient_Click(object sender, EventArgs e)
        {
            String strNoClient = dgClient.CurrentRow.Cells[0].Value.ToString();
            String strPrenomNomClient = dgClient.CurrentRow.Cells[2].Value.ToString() + " " + dgClient.CurrentRow.Cells[1].Value.ToString();
                DialogResult res = MessageBox.Show(this, "Voulez-vous vraiment supprimer le client " + strPrenomNomClient + "?", "Suppression d'un client", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
                if (res == DialogResult.OK)
                {
                    clientBindingSource.RemoveCurrent();
                    /*SqlCommand maCommande = new SqlCommand(" DELETE FROM Client WHERE NoClient=" + strNoClient, maConnexion);
                    maConnexion.Open();
                    maCommande.ExecuteNonQuery();
                    maConnexion.Close();*/
                try
                {
                    tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                }
                catch (DBConcurrencyException erreur)
                {
                    String strNomComplet = erreur.Row["dgPrenom"].ToString() + " " + erreur.Row["dgNom"].ToString();
                    MessageBox.Show("Conflit d'accès concurrentiel pour le client " + strNomComplet + ".Aucun enregistrement possible.", "Conflit d'accès");
                }
            }
        }

        private void dgClient_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {
            String msgErreur = "";
            if (dgClient["dgNoClient", e.RowIndex].Value != null)
            {
                String strNoClient = dgClient["dgNoClient", e.RowIndex].Value.ToString();
                String strNomClient = dgClient["dgNom", e.RowIndex].Value.ToString();
                String strPrenomClient = dgClient["dgPrenom", e.RowIndex].Value.ToString();
                String strVille = dgClient["dgVille", e.RowIndex].Value.ToString();
                String strPays = dgClient["dgPays", e.RowIndex].Value.ToString();
                String strAdresse = dgClient["dgAdresse", e.RowIndex].Value.ToString();
                String strCodePostal = dgClient["dgCodePostal", e.RowIndex].Value.ToString();
                String strDateInscription = dgClient["dgDateInscription", e.RowIndex].Value.ToString();

                if (strNoClient.Trim() == "" || strNomClient.Trim() == "" || strPrenomClient.Trim() == ""
                    || strVille.Trim() == "" || strPays.Trim() == "" || strAdresse.Trim() == "" || strCodePostal.Trim() == "")
                {
                    msgErreur = "Aucune colonne ne peut être vide";
                    e.Cancel = true;
                }
                else
                {

                    SqlCommand maCommande = new SqlCommand(" SELECT NoClient FROM Client WHERE NoClient = '" + strNoClient + "'", maConnexion);
                    maConnexion.Open();
                    SqlDataReader monReader = maCommande.ExecuteReader();
                    if (monReader.Read())
                    {
                        monReader.Close();
                        /*maCommande = new SqlCommand(" UPDATE Client SET Nom = '" + strNomClient + "', Prenom = '" + strPrenomClient + "', Ville = '" + strVille + "', Pays = '" + strPays + "', Adresse = '" + strAdresse + "', CodePostal ='" + strCodePostal + "'" + " WHERE NoClient = " + strNoClient, maConnexion);
                        maCommande.ExecuteNonQuery();*/
                        try
                        {
                            tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                        }
                        catch (DBConcurrencyException erreur)
                        {
                            String strNomComplet = erreur.Row["dgPrenom"].ToString() + " " + erreur.Row["dgNom"].ToString();
                            MessageBox.Show("Conflit d'accès concurrentiel pour le client " + strNomComplet + ".Aucun enregistrement possible.", "Conflit d'accès");
                        }
                    }
                    else
                    {
                        monReader.Close();
                        /*maCommande = new SqlCommand(" INSERT INTO Client VALUES ('" + strNoClient + "','" + strNomClient + "','" + strPrenomClient + "','" + strVille +"','" + strPays +"','" + strAdresse +"','" + strCodePostal +"','" + strDateInscription + "')", maConnexion);
                        maCommande.ExecuteNonQuery();*/
                        try
                        {
                            tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                        }
                        catch (DBConcurrencyException erreur)
                        {
                            String strNomComplet = erreur.Row["dgPrenom"].ToString() + " " + erreur.Row["dgNom"].ToString();
                            MessageBox.Show("Conflit d'accès concurrentiel pour le client " + strNomComplet + ".Aucun enregistrement possible.", "Conflit d'accès");
                        }
                    }
                    maConnexion.Close();
                }
                dgClient.Rows[e.RowIndex].ErrorText = msgErreur;
            }
        }
    }
}
