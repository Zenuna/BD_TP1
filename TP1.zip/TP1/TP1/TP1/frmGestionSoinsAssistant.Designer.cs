﻿namespace TP1
{
    partial class frmGestionSoinsAssistant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nomCompletLabel;
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.prenomNomAssistantBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.prenomNomAssistantTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PrenomNomAssistantTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.cbAssistant = new System.Windows.Forms.ComboBox();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.btnSupprSoin = new System.Windows.Forms.Button();
            this.btnAjouterSoin = new System.Windows.Forms.Button();
            this.btnDernierSoin = new System.Windows.Forms.Button();
            this.btnSoinSuivant = new System.Windows.Forms.Button();
            this.btnSoinPrecedent = new System.Windows.Forms.Button();
            this.btnPremierSoin = new System.Windows.Forms.Button();
            this.assistantSoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.assistantSoinTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.AssistantSoinTableAdapter();
            this.dgAssistantSoin = new System.Windows.Forms.DataGridView();
            this.soinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.soinTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.SoinTableAdapter();
            this.dgNoSoin = new System.Windows.Forms.DataGridViewComboBoxColumn();
            nomCompletLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prenomNomAssistantBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantSoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgAssistantSoin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soinBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // nomCompletLabel
            // 
            nomCompletLabel.AutoSize = true;
            nomCompletLabel.Location = new System.Drawing.Point(12, 9);
            nomCompletLabel.Name = "nomCompletLabel";
            nomCompletLabel.Size = new System.Drawing.Size(58, 13);
            nomCompletLabel.TabIndex = 1;
            nomCompletLabel.Text = "Assistant : ";
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // prenomNomAssistantBindingSource
            // 
            this.prenomNomAssistantBindingSource.DataMember = "PrenomNomAssistant";
            this.prenomNomAssistantBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // prenomNomAssistantTableAdapter
            // 
            this.prenomNomAssistantTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = this.prenomNomAssistantTableAdapter;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // cbAssistant
            // 
            this.cbAssistant.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.prenomNomAssistantBindingSource, "NomComplet", true));
            this.cbAssistant.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.prenomNomAssistantBindingSource, "NomComplet", true));
            this.cbAssistant.DataSource = this.prenomNomAssistantBindingSource;
            this.cbAssistant.DisplayMember = "NomComplet";
            this.cbAssistant.FormattingEnabled = true;
            this.cbAssistant.Location = new System.Drawing.Point(91, 6);
            this.cbAssistant.Name = "cbAssistant";
            this.cbAssistant.Size = new System.Drawing.Size(191, 21);
            this.cbAssistant.TabIndex = 2;
            this.cbAssistant.ValueMember = "NoAssistant";
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(288, 196);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(169, 23);
            this.btnAnnuler.TabIndex = 36;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            // 
            // btnSupprSoin
            // 
            this.btnSupprSoin.Location = new System.Drawing.Point(288, 231);
            this.btnSupprSoin.Name = "btnSupprSoin";
            this.btnSupprSoin.Size = new System.Drawing.Size(169, 23);
            this.btnSupprSoin.TabIndex = 35;
            this.btnSupprSoin.Text = "Supprimer soin";
            this.btnSupprSoin.UseVisualStyleBackColor = true;
            this.btnSupprSoin.Click += new System.EventHandler(this.btnSupprSoin_Click);
            // 
            // btnAjouterSoin
            // 
            this.btnAjouterSoin.Location = new System.Drawing.Point(288, 158);
            this.btnAjouterSoin.Name = "btnAjouterSoin";
            this.btnAjouterSoin.Size = new System.Drawing.Size(169, 23);
            this.btnAjouterSoin.TabIndex = 34;
            this.btnAjouterSoin.Text = "Ajouter soin";
            this.btnAjouterSoin.UseVisualStyleBackColor = true;
            this.btnAjouterSoin.Click += new System.EventHandler(this.btnAjouterSoin_Click);
            // 
            // btnDernierSoin
            // 
            this.btnDernierSoin.Location = new System.Drawing.Point(288, 120);
            this.btnDernierSoin.Name = "btnDernierSoin";
            this.btnDernierSoin.Size = new System.Drawing.Size(169, 23);
            this.btnDernierSoin.TabIndex = 33;
            this.btnDernierSoin.Text = "Dernier soin";
            this.btnDernierSoin.UseVisualStyleBackColor = true;
            this.btnDernierSoin.Click += new System.EventHandler(this.btnDernierSoin_Click);
            // 
            // btnSoinSuivant
            // 
            this.btnSoinSuivant.Location = new System.Drawing.Point(288, 82);
            this.btnSoinSuivant.Name = "btnSoinSuivant";
            this.btnSoinSuivant.Size = new System.Drawing.Size(169, 23);
            this.btnSoinSuivant.TabIndex = 32;
            this.btnSoinSuivant.Text = "Soin suivant";
            this.btnSoinSuivant.UseVisualStyleBackColor = true;
            this.btnSoinSuivant.Click += new System.EventHandler(this.btnSoinSuivant_Click);
            // 
            // btnSoinPrecedent
            // 
            this.btnSoinPrecedent.Location = new System.Drawing.Point(288, 44);
            this.btnSoinPrecedent.Name = "btnSoinPrecedent";
            this.btnSoinPrecedent.Size = new System.Drawing.Size(169, 23);
            this.btnSoinPrecedent.TabIndex = 31;
            this.btnSoinPrecedent.Text = "Soin précédent";
            this.btnSoinPrecedent.UseVisualStyleBackColor = true;
            this.btnSoinPrecedent.Click += new System.EventHandler(this.btnSoinPrecedent_Click);
            // 
            // btnPremierSoin
            // 
            this.btnPremierSoin.Location = new System.Drawing.Point(288, 6);
            this.btnPremierSoin.Name = "btnPremierSoin";
            this.btnPremierSoin.Size = new System.Drawing.Size(169, 23);
            this.btnPremierSoin.TabIndex = 30;
            this.btnPremierSoin.Text = "Premier soin";
            this.btnPremierSoin.UseVisualStyleBackColor = true;
            this.btnPremierSoin.Click += new System.EventHandler(this.btnPremierSoin_Click);
            // 
            // assistantSoinBindingSource
            // 
            this.assistantSoinBindingSource.DataMember = "FK_AssistantSoinNoAssistant1";
            this.assistantSoinBindingSource.DataSource = this.prenomNomAssistantBindingSource;
            // 
            // assistantSoinTableAdapter
            // 
            this.assistantSoinTableAdapter.ClearBeforeFill = true;
            // 
            // dgAssistantSoin
            // 
            this.dgAssistantSoin.AllowUserToAddRows = false;
            this.dgAssistantSoin.AllowUserToDeleteRows = false;
            this.dgAssistantSoin.AutoGenerateColumns = false;
            this.dgAssistantSoin.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgAssistantSoin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgAssistantSoin.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgNoSoin});
            this.dgAssistantSoin.DataSource = this.assistantSoinBindingSource;
            this.dgAssistantSoin.Location = new System.Drawing.Point(12, 34);
            this.dgAssistantSoin.Name = "dgAssistantSoin";
            this.dgAssistantSoin.Size = new System.Drawing.Size(270, 220);
            this.dgAssistantSoin.TabIndex = 36;
            // 
            // soinBindingSource
            // 
            this.soinBindingSource.DataMember = "Soin";
            this.soinBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // soinTableAdapter
            // 
            this.soinTableAdapter.ClearBeforeFill = true;
            // 
            // dgNoSoin
            // 
            this.dgNoSoin.DataSource = this.soinBindingSource;
            this.dgNoSoin.DisplayMember = "Description";
            this.dgNoSoin.HeaderText = "NoSoin";
            this.dgNoSoin.Name = "dgNoSoin";
            this.dgNoSoin.ReadOnly = true;
            this.dgNoSoin.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgNoSoin.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgNoSoin.ValueMember = "NoSoin";
            // 
            // frmGestionSoinsAssistant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(473, 269);
            this.Controls.Add(this.dgAssistantSoin);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnSupprSoin);
            this.Controls.Add(this.btnAjouterSoin);
            this.Controls.Add(this.btnDernierSoin);
            this.Controls.Add(this.btnSoinSuivant);
            this.Controls.Add(this.btnSoinPrecedent);
            this.Controls.Add(this.btnPremierSoin);
            this.Controls.Add(nomCompletLabel);
            this.Controls.Add(this.cbAssistant);
            this.Name = "frmGestionSoinsAssistant";
            this.Text = "Gestion des soins d\'assistant";
            this.Load += new System.EventHandler(this.frmGestionSoinsAssistant_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prenomNomAssistantBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantSoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgAssistantSoin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soinBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource prenomNomAssistantBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PrenomNomAssistantTableAdapter prenomNomAssistantTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ComboBox cbAssistant;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.Button btnSupprSoin;
        private System.Windows.Forms.Button btnAjouterSoin;
        private System.Windows.Forms.Button btnDernierSoin;
        private System.Windows.Forms.Button btnSoinSuivant;
        private System.Windows.Forms.Button btnSoinPrecedent;
        private System.Windows.Forms.Button btnPremierSoin;
        private System.Windows.Forms.BindingSource assistantSoinBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.AssistantSoinTableAdapter assistantSoinTableAdapter;
        private System.Windows.Forms.DataGridView dgAssistantSoin;
        private System.Windows.Forms.BindingSource soinBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.SoinTableAdapter soinTableAdapter;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgNoSoin;
    }
}