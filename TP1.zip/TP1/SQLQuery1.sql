use BD5B6TP1_KoumaJouanique


Print  'Cr�ation de la base de donn�es de l''agence de voyage Tototour.'
print  'Derni�re modification, 17 juillet 2018.'
print ''
Print  'destruction des tables...'
if object_id('AssistantSoin','U') is not null drop table AssistantSoin
if object_id('Assistant','U') is not null drop table Assistant
if object_id('Soin','U') is not null drop table Soin
if object_id('TypeSoin','U') is not null drop table TypeSoin
if object_id('PlanifSoin','U') is not null drop table PlanifSoin
if object_id('Invite','U') is not null  DROP TABLE Invite;
if object_id('ReservationChambre','U') is not null  DROP TABLE ReservationChambre;
if object_id('Client','U') is not null  DROP TABLE Client;
if object_id('Chambre','U') is not null  DROP TABLE Chambre;
if object_id('TypeChambre','U') is not null  DROP TABLE TypeChambre;

print 'Cr�ation des tables ========================================================'
print ''


Print  'Cr�ation de la TABLE TypeSoin...' 
CREATE TABLE TypeSoin (
   NoTypeSoin	NUMERIC(6) not null ,
   Description	varCHAR(76) ,
   CONSTRAINT pk_TypeSoin PRIMARY KEY(NoTypeSoin)
   );
/*insert into TypeSoin values(1,'Beaut�'),(2,'Sant�')*/

Print  'Cr�ation de la TABLE Assistant...' 
CREATE TABLE Assistant (
   NoAssistant	NUMERIC(6) not null ,
   Prenom	VARCHAR(20),
   Nom	VARCHAR(15),
   Specialites	VARCHAR(15),
   Remarques	varCHAR(76) ,
   CONSTRAINT pk_Assistant PRIMARY KEY(NoAssistant)
   );

Print  'Cr�ation de la TABLE Soin...' 
CREATE TABLE Soin (
   NoSoin NUMERIC(6) not null ,
   Description	varCHAR(76),
   Duree DATETIME,
   NoTpyeSoin	NUMERIC(6) not null,
   Prix	NUMERIC(5,2) ,
   CONSTRAINT pk_Soin PRIMARY KEY(NoSoin),
   CONSTRAINT FK_SoinNoTypeSoin FOREIGN KEY (NoTpyeSoin) REFERENCES TypeSoin(NoTypeSoin)
   );



Print  'Cr�ation de la TABLE AssistantSoin...' 
CREATE TABLE AssistantSoin (
   NoAssistant	NUMERIC(6) not null ,
   NoSoin NUMERIC(6) not null,
   CONSTRAINT pk_AssistantSoin  PRIMARY KEY(NoAssistant, NoSoin),
   CONSTRAINT FK_AssistantSoinNoSoin FOREIGN KEY (NoSoin) REFERENCES Soin(NoSoin),
   CONSTRAINT FK_AssistantSoinNoAssistant FOREIGN KEY (NoAssistant) REFERENCES Assistant(NoAssistant)
   );

Print  'Cr�ation de la TABLE PlanifSoin...' 
CREATE TABLE PlanifSoin (
   NoPersonne	NUMERIC(6) not null,
   NoAssistant	NUMERIC(6) not null ,
   DateHeure Datetime,
   NoSoin NUMERIC(6) not null,
   CONSTRAINT pk_PlanifSoin PRIMARY KEY(NoPersonne,NoAssistant,DateHeure),
   CONSTRAINT FK_PlanifSoinNoAssistant FOREIGN KEY (NoAssistant) REFERENCES Assistant(NoAssistant),
   CONSTRAINT FK_PlanifSoinNoSoin FOREIGN KEY (NoSoin) REFERENCES Soin(NoSoin)
   );

Print  'Cr�ation de la TABLE TypeChambre...' 
CREATE TABLE TypeChambre(
	NoTypeChambre int not null,
	Description varchar(50),
	PrixHaut Numeric(7,2),
	PrixBas Numeric(7,2),
	PrixMoyen Numeric(7,2),
	CONSTRAINT PK_NoTypeChambre PRIMARY KEY(NoTypeChambre)
)


Print  'Cr�ation de la TABLE Chambre...' 
CREATE TABLE Chambre(
	NoChambre int not null,
	Emplacement varchar(50),
	Decorations varchar(50),
	NoTypeChambre int not null,
	CONSTRAINT PK_NoChambre PRIMARY KEY(NoChambre),
	CONSTRAINT FK_NoTypeChambre FOREIGN KEY (NoTypeChambre) REFERENCES TypeChambre(NoTypeChambre)
)


Print  'Cr�ation de la TABLE Client...' 
CREATE TABLE Client(
	NoClient int not null,
	Nom varchar(20),
	Prenom varchar(20),
	Ville varchar(30),
	Pays varchar(20),
	Adresse varchar(50),
	CodePostal varchar(7),
	DateInscription DATETIME,
	CONSTRAINT PK_NoClient PRIMARY KEY (NoClient)
)


Print  'Cr�ation de la TABLE ReservationChambre...' 
CREATE TABLE ReservationChambre(
	NoClient int not null,
	NoChambre int not null,
	DateArrivee DATETIME,
	DateDepart DATETIME,
	NbPersonnes int,
	CONSTRAINT PK_Reservation PRIMARY KEY(NoClient, NoChambre, DateArrivee),
	CONSTRAINT FK_NoClient FOREIGN KEY (NoClient) REFERENCES Client(NoClient),
	CONSTRAINT FK_NoChambre FOREIGN KEY (NoChambre) REFERENCES Chambre(NoChambre)
)

Print  'Cr�ation de la TABLE Invite...' 
CREATE TABLE Invite(
	NoInvite int not null,
	NomPrenom varchar(50),
	NoClient int not null,
	CONSTRAINT PK_Invite PRIMARY KEY(NoInvite),
    CONSTRAINT FK_NoClientInvite FOREIGN KEY (NoClient) REFERENCES Client(NoClient)
)

Print	'Cr�ation de la TABLE typeUtilisateur...'
CREATE TABLE typeUtilisateur(
	NoTypeUtilisateur int not null,
	Identification varchar(8),
	CONSTRAINT PK_TypeUtilisateur PRIMARY KEY(NoTypeUtilisateur)
)

Print	'Cr�ation de la TABLE utilisateur...'
CREATE TABLE Utilisateur(
	NoUtilisateur int not null,
	NomUtilisateur varchar(20) UNIQUE,
	MotDePasse varchar(20),
	NoTypeUtilisateur int not null,
	CONSTRAINT FK_TypeUtilisateur FOREIGN KEY(NoTypeUtilisateur) REFERENCES typeUtilisateur(NoTypeUtilisateur)
)

INSERT INTO typeUtilisateur (NoTypeUtilisateur, Identification) VALUES (1,'Admin'),(2,'Pr�pos�')
INSERT INTO Utilisateur (NoUtilisateur,NomUtilisateur,MotDePasse,NoTypeUtilisateur) VALUES (1,'Jean Travaille','1',1),(2,'Karine Kifefrette','2',2)


select * from typeUtilisateur
select * from Utilisateur

select t.Identification from typeUtilisateur T inner join Utilisateur U on t.NoTypeUtilisateur = u.NoTypeUtilisateur where u.NoUtilisateur = 1