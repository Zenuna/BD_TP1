use BD5B6TP1_KoumaJouanique

select s.NoSoin, convert(nvarchar,s.NoSoin)+ ' ' +  t.Description AS 'NumeroEtDescription' from Soin S
inner join TypeSoin T 
on s.NoTypeSoin = t.NoTypeSoin

select * from Assistant
select * from Soin
select * from TypeSoin
select * from AssistantSoin

select * from PlanifSoin

select * from PlanifSoin where NoAssistant

select At.NoAssistant, convert(nvarchar,a.NoAssistant) + ' ' + a.Nom + ' ' + a.Prenom AS 'NumeroNomEtPrenomAssistant' from AssistantSoin AT
inner join Assistant A
on at.NoAssistant = a.NoAssistant where at.NoSoin = cboNoSoins.selectedValue

select NoSoin, convert(nvarchar,NoSoin)+ ' ' +  Description AS 'NumeroEtDescription' from Soin 

insert into AssistantSoin values(1,1)

select * from AssistantSoin
select * from PlanifSoin 


SELECT   COUNT(DateHeure) AS nbr_doublon
FROM     PlanifSoin where NoAssistant = 1
GROUP BY DateHeure
HAVING   COUNT(DateHeure) > 1 

select * from Invite


SELECT COUNT(DateHeure) FROM PlanifSoin where NoAssistant = 1 GROUP BY DateHeure HAVING COUNT(DateHeure) > 1 

select * from Chambre
select * from TypeChambre

select NoTypeChambre, convert(nvarchar,NoTypeChambre) + ' ' + Description AS 'Description' from TypeChambre

select * from Chambre
select * from PlanifSoin

SELECT count(*) FROM TypeChambre WHERE description IN ( SELECT Description FROM TypeChambre GROUP BY Description HAVING COUNT(*) > 1 )


SELECT count(*) FROM TypeChambre WHERE description IN ( SELECT Description FROM TypeChambre where description = 'Vraiment beau' GROUP BY Description HAVING COUNT(*) > 1 )

select * from ReservationChambre


select NoClient, convert(nvarchar,NoClient) + ' ' + Nom + ', ' + Prenom AS 'Nom' from Client