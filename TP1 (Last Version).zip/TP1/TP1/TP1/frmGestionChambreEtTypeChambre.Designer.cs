﻿namespace TP1
{
    partial class frmGestionChambreEtTypeChambre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGestionChambre = new System.Windows.Forms.Button();
            this.btnGestionTypeChambre = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGestionChambre
            // 
            this.btnGestionChambre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestionChambre.Location = new System.Drawing.Point(2, 12);
            this.btnGestionChambre.Name = "btnGestionChambre";
            this.btnGestionChambre.Size = new System.Drawing.Size(132, 63);
            this.btnGestionChambre.TabIndex = 0;
            this.btnGestionChambre.Text = "Gestion des chambres";
            this.btnGestionChambre.UseVisualStyleBackColor = true;
            this.btnGestionChambre.Click += new System.EventHandler(this.btnGestionChambre_Click);
            // 
            // btnGestionTypeChambre
            // 
            this.btnGestionTypeChambre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGestionTypeChambre.Location = new System.Drawing.Point(166, 12);
            this.btnGestionTypeChambre.Name = "btnGestionTypeChambre";
            this.btnGestionTypeChambre.Size = new System.Drawing.Size(168, 63);
            this.btnGestionTypeChambre.TabIndex = 1;
            this.btnGestionTypeChambre.Text = "Gestion des types de chambres";
            this.btnGestionTypeChambre.UseVisualStyleBackColor = true;
            this.btnGestionTypeChambre.Click += new System.EventHandler(this.btnGestionTypeChambre_Click);
            // 
            // frmGestionChambreEtTypeChambre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(355, 95);
            this.Controls.Add(this.btnGestionTypeChambre);
            this.Controls.Add(this.btnGestionChambre);
            this.Name = "frmGestionChambreEtTypeChambre";
            this.Text = "frmGestionChambreEtTypeChambre";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGestionChambre;
        private System.Windows.Forms.Button btnGestionTypeChambre;
    }
}