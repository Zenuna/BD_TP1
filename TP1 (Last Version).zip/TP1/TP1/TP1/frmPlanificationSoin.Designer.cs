﻿namespace TP1
{
    partial class frmPlanificationSoin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPlanificationSoin));
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.planifSoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.planifSoinTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PlanifSoinTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.planifSoinBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.planifSoinBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.planifSoinDataGridView = new System.Windows.Forms.DataGridView();
            this.dgNoPersonne = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgNoAssistant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgDateHeure = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgSoins = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAjouterReserVationSoin = new System.Windows.Forms.Button();
            this.btnSupprimerReservationSoin = new System.Windows.Forms.Button();
            this.btnEnregistrerModification = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinBindingNavigator)).BeginInit();
            this.planifSoinBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // planifSoinBindingSource
            // 
            this.planifSoinBindingSource.DataMember = "PlanifSoin";
            this.planifSoinBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // planifSoinTableAdapter
            // 
            this.planifSoinTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.NomClientTableAdapter = null;
            this.tableAdapterManager.PlanifSoinTableAdapter = this.planifSoinTableAdapter;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.typchambreEtDescriptionTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // planifSoinBindingNavigator
            // 
            this.planifSoinBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.planifSoinBindingNavigator.BindingSource = this.planifSoinBindingSource;
            this.planifSoinBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.planifSoinBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.planifSoinBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.planifSoinBindingNavigatorSaveItem});
            this.planifSoinBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.planifSoinBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.planifSoinBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.planifSoinBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.planifSoinBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.planifSoinBindingNavigator.Name = "planifSoinBindingNavigator";
            this.planifSoinBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.planifSoinBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.planifSoinBindingNavigator.TabIndex = 0;
            this.planifSoinBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Ajouter nouveau";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Nombre total d\'éléments";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Supprimer";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Placer en premier";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Déplacer vers le haut";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Position actuelle";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Déplacer vers le bas";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Placer en dernier";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // planifSoinBindingNavigatorSaveItem
            // 
            this.planifSoinBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.planifSoinBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("planifSoinBindingNavigatorSaveItem.Image")));
            this.planifSoinBindingNavigatorSaveItem.Name = "planifSoinBindingNavigatorSaveItem";
            this.planifSoinBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.planifSoinBindingNavigatorSaveItem.Text = "Enregistrer les données";
            this.planifSoinBindingNavigatorSaveItem.Click += new System.EventHandler(this.planifSoinBindingNavigatorSaveItem_Click);
            // 
            // planifSoinDataGridView
            // 
            this.planifSoinDataGridView.AutoGenerateColumns = false;
            this.planifSoinDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.planifSoinDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgNoPersonne,
            this.dgNoAssistant,
            this.dgDateHeure,
            this.dgSoins});
            this.planifSoinDataGridView.DataSource = this.planifSoinBindingSource;
            this.planifSoinDataGridView.Location = new System.Drawing.Point(12, 28);
            this.planifSoinDataGridView.Name = "planifSoinDataGridView";
            this.planifSoinDataGridView.Size = new System.Drawing.Size(444, 220);
            this.planifSoinDataGridView.TabIndex = 1;
            this.planifSoinDataGridView.RowValidating += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.planifSoinDataGridView_RowValidating);
            // 
            // dgNoPersonne
            // 
            this.dgNoPersonne.DataPropertyName = "NoPersonne";
            this.dgNoPersonne.HeaderText = "NoPersonne";
            this.dgNoPersonne.Name = "dgNoPersonne";
            // 
            // dgNoAssistant
            // 
            this.dgNoAssistant.DataPropertyName = "NoAssistant";
            this.dgNoAssistant.HeaderText = "NoAssistant";
            this.dgNoAssistant.Name = "dgNoAssistant";
            // 
            // dgDateHeure
            // 
            this.dgDateHeure.DataPropertyName = "DateHeure";
            this.dgDateHeure.HeaderText = "DateHeure";
            this.dgDateHeure.Name = "dgDateHeure";
            // 
            // dgSoins
            // 
            this.dgSoins.DataPropertyName = "NoSoin";
            this.dgSoins.HeaderText = "NoSoin";
            this.dgSoins.Name = "dgSoins";
            // 
            // btnAjouterReserVationSoin
            // 
            this.btnAjouterReserVationSoin.Location = new System.Drawing.Point(12, 275);
            this.btnAjouterReserVationSoin.Name = "btnAjouterReserVationSoin";
            this.btnAjouterReserVationSoin.Size = new System.Drawing.Size(183, 23);
            this.btnAjouterReserVationSoin.TabIndex = 2;
            this.btnAjouterReserVationSoin.Text = "Ajouter une reservation de soins";
            this.btnAjouterReserVationSoin.UseVisualStyleBackColor = true;
            this.btnAjouterReserVationSoin.Click += new System.EventHandler(this.btnAjouterReserVationSoin_Click);
            // 
            // btnSupprimerReservationSoin
            // 
            this.btnSupprimerReservationSoin.Location = new System.Drawing.Point(262, 275);
            this.btnSupprimerReservationSoin.Name = "btnSupprimerReservationSoin";
            this.btnSupprimerReservationSoin.Size = new System.Drawing.Size(194, 23);
            this.btnSupprimerReservationSoin.TabIndex = 3;
            this.btnSupprimerReservationSoin.Text = "Supprimer une réservation de soin";
            this.btnSupprimerReservationSoin.UseVisualStyleBackColor = true;
            this.btnSupprimerReservationSoin.Click += new System.EventHandler(this.btnSupprimerReservationSoin_Click);
            // 
            // btnEnregistrerModification
            // 
            this.btnEnregistrerModification.Location = new System.Drawing.Point(151, 319);
            this.btnEnregistrerModification.Name = "btnEnregistrerModification";
            this.btnEnregistrerModification.Size = new System.Drawing.Size(156, 23);
            this.btnEnregistrerModification.TabIndex = 4;
            this.btnEnregistrerModification.Text = "Enregistrer les modifications";
            this.btnEnregistrerModification.UseVisualStyleBackColor = true;
            this.btnEnregistrerModification.Click += new System.EventHandler(this.btnEnregistrerModification_Click);
            // 
            // frmPlanificationSoin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnEnregistrerModification);
            this.Controls.Add(this.btnSupprimerReservationSoin);
            this.Controls.Add(this.btnAjouterReserVationSoin);
            this.Controls.Add(this.planifSoinDataGridView);
            this.Controls.Add(this.planifSoinBindingNavigator);
            this.Name = "frmPlanificationSoin";
            this.Text = "frmPlanificationSoin";
            this.Load += new System.EventHandler(this.frmPlanificationSoin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinBindingNavigator)).EndInit();
            this.planifSoinBindingNavigator.ResumeLayout(false);
            this.planifSoinBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource planifSoinBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PlanifSoinTableAdapter planifSoinTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator planifSoinBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton planifSoinBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView planifSoinDataGridView;
        private System.Windows.Forms.Button btnAjouterReserVationSoin;
        private System.Windows.Forms.Button btnSupprimerReservationSoin;
        private System.Windows.Forms.Button btnEnregistrerModification;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgNoPersonne;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgNoAssistant;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgDateHeure;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgSoins;
    }
}