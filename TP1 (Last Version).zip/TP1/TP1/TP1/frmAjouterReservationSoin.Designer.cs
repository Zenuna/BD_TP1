﻿namespace TP1
{
    partial class frmAjouterReservationSoin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblClientOuInvite = new System.Windows.Forms.Label();
            this.lblNoAssistant = new System.Windows.Forms.Label();
            this.lblNoSoins = new System.Windows.Forms.Label();
            this.btnAjouter = new System.Windows.Forms.Button();
            this.btnFermer = new System.Windows.Forms.Button();
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.clientEtInviteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clientEtInviteTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ClientEtInviteTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.cboClientEtInvite = new System.Windows.Forms.ComboBox();
            this.numeroNomEtPrenomAssistantBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.numeroNomEtPrenomAssistantTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.NumeroNomEtPrenomAssistantTableAdapter();
            this.cboNoAssistant = new System.Windows.Forms.ComboBox();
            this.soinEtDescriptionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.soinEtDescriptionTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.SoinEtDescriptionTableAdapter();
            this.cboNoSoins = new System.Windows.Forms.ComboBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.lblHeure = new System.Windows.Forms.Label();
            this.errMessage = new System.Windows.Forms.ErrorProvider(this.components);
            this.dtpHeure = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientEtInviteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeroNomEtPrenomAssistantBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soinEtDescriptionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMessage)).BeginInit();
            this.SuspendLayout();
            // 
            // lblClientOuInvite
            // 
            this.lblClientOuInvite.AutoSize = true;
            this.lblClientOuInvite.Location = new System.Drawing.Point(41, 47);
            this.lblClientOuInvite.Name = "lblClientOuInvite";
            this.lblClientOuInvite.Size = new System.Drawing.Size(77, 13);
            this.lblClientOuInvite.TabIndex = 0;
            this.lblClientOuInvite.Text = "Client ou Invité";
            // 
            // lblNoAssistant
            // 
            this.lblNoAssistant.AutoSize = true;
            this.lblNoAssistant.Location = new System.Drawing.Point(41, 85);
            this.lblNoAssistant.Name = "lblNoAssistant";
            this.lblNoAssistant.Size = new System.Drawing.Size(66, 13);
            this.lblNoAssistant.TabIndex = 2;
            this.lblNoAssistant.Text = "No Assistant";
            // 
            // lblNoSoins
            // 
            this.lblNoSoins.AutoSize = true;
            this.lblNoSoins.Location = new System.Drawing.Point(41, 119);
            this.lblNoSoins.Name = "lblNoSoins";
            this.lblNoSoins.Size = new System.Drawing.Size(50, 13);
            this.lblNoSoins.TabIndex = 4;
            this.lblNoSoins.Text = "No Soins";
            // 
            // btnAjouter
            // 
            this.btnAjouter.Location = new System.Drawing.Point(360, 42);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(75, 23);
            this.btnAjouter.TabIndex = 6;
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.UseVisualStyleBackColor = true;
            this.btnAjouter.Click += new System.EventHandler(this.btnAjouter_Click);
            // 
            // btnFermer
            // 
            this.btnFermer.Location = new System.Drawing.Point(360, 109);
            this.btnFermer.Name = "btnFermer";
            this.btnFermer.Size = new System.Drawing.Size(75, 23);
            this.btnFermer.TabIndex = 7;
            this.btnFermer.Text = "Fermer";
            this.btnFermer.UseVisualStyleBackColor = true;
            this.btnFermer.Click += new System.EventHandler(this.btnFermer_Click);
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // clientEtInviteBindingSource
            // 
            this.clientEtInviteBindingSource.DataMember = "ClientEtInvite";
            this.clientEtInviteBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // clientEtInviteTableAdapter
            // 
            this.clientEtInviteTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // cboClientEtInvite
            // 
            this.cboClientEtInvite.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientEtInviteBindingSource, "Nom et numero", true));
            this.cboClientEtInvite.DataSource = this.clientEtInviteBindingSource;
            this.cboClientEtInvite.DisplayMember = "Nom et numero";
            this.cboClientEtInvite.FormattingEnabled = true;
            this.cboClientEtInvite.Location = new System.Drawing.Point(154, 44);
            this.cboClientEtInvite.Name = "cboClientEtInvite";
            this.cboClientEtInvite.Size = new System.Drawing.Size(121, 21);
            this.cboClientEtInvite.TabIndex = 9;
            this.cboClientEtInvite.ValueMember = "NumeroClientOuInvite";
            // 
            // numeroNomEtPrenomAssistantBindingSource
            // 
            this.numeroNomEtPrenomAssistantBindingSource.DataMember = "NumeroNomEtPrenomAssistant";
            this.numeroNomEtPrenomAssistantBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // numeroNomEtPrenomAssistantTableAdapter
            // 
            this.numeroNomEtPrenomAssistantTableAdapter.ClearBeforeFill = true;
            // 
            // cboNoAssistant
            // 
            this.cboNoAssistant.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.numeroNomEtPrenomAssistantBindingSource, "NumeroNomEtPrenomAssistant", true));
            this.cboNoAssistant.DataSource = this.numeroNomEtPrenomAssistantBindingSource;
            this.cboNoAssistant.DisplayMember = "NumeroNomEtPrenomAssistant";
            this.cboNoAssistant.FormattingEnabled = true;
            this.cboNoAssistant.Location = new System.Drawing.Point(154, 82);
            this.cboNoAssistant.Name = "cboNoAssistant";
            this.cboNoAssistant.Size = new System.Drawing.Size(121, 21);
            this.cboNoAssistant.TabIndex = 11;
            this.cboNoAssistant.ValueMember = "NoAssistant";
            // 
            // soinEtDescriptionBindingSource
            // 
            this.soinEtDescriptionBindingSource.DataMember = "SoinEtDescription";
            this.soinEtDescriptionBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // soinEtDescriptionTableAdapter
            // 
            this.soinEtDescriptionTableAdapter.ClearBeforeFill = true;
            // 
            // cboNoSoins
            // 
            this.cboNoSoins.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.soinEtDescriptionBindingSource, "NumeroEtDescription", true));
            this.cboNoSoins.DataSource = this.soinEtDescriptionBindingSource;
            this.cboNoSoins.DisplayMember = "NumeroEtDescription";
            this.cboNoSoins.FormattingEnabled = true;
            this.cboNoSoins.Location = new System.Drawing.Point(154, 116);
            this.cboNoSoins.Name = "cboNoSoins";
            this.cboNoSoins.Size = new System.Drawing.Size(121, 21);
            this.cboNoSoins.TabIndex = 12;
            this.cboNoSoins.ValueMember = "NoSoin";
            this.cboNoSoins.SelectedIndexChanged += new System.EventHandler(this.cboNoSoins_SelectedIndexChanged);
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(41, 156);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(30, 13);
            this.lblDate.TabIndex = 13;
            this.lblDate.Text = "Date";
            // 
            // dtpDate
            // 
            this.dtpDate.Location = new System.Drawing.Point(154, 150);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(200, 20);
            this.dtpDate.TabIndex = 14;
            // 
            // lblHeure
            // 
            this.lblHeure.AutoSize = true;
            this.lblHeure.Location = new System.Drawing.Point(44, 194);
            this.lblHeure.Name = "lblHeure";
            this.lblHeure.Size = new System.Drawing.Size(36, 13);
            this.lblHeure.TabIndex = 15;
            this.lblHeure.Text = "Heure";
            // 
            // errMessage
            // 
            this.errMessage.ContainerControl = this;
            // 
            // dtpHeure
            // 
            this.dtpHeure.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpHeure.Location = new System.Drawing.Point(154, 194);
            this.dtpHeure.Name = "dtpHeure";
            this.dtpHeure.ShowUpDown = true;
            this.dtpHeure.Size = new System.Drawing.Size(200, 20);
            this.dtpHeure.TabIndex = 16;
            // 
            // frmAjouterReservationSoin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 257);
            this.Controls.Add(this.dtpHeure);
            this.Controls.Add(this.lblHeure);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.cboNoSoins);
            this.Controls.Add(this.cboNoAssistant);
            this.Controls.Add(this.cboClientEtInvite);
            this.Controls.Add(this.btnFermer);
            this.Controls.Add(this.btnAjouter);
            this.Controls.Add(this.lblNoSoins);
            this.Controls.Add(this.lblNoAssistant);
            this.Controls.Add(this.lblClientOuInvite);
            this.Name = "frmAjouterReservationSoin";
            this.Text = "frmAjouterReservationSoin";
            this.Load += new System.EventHandler(this.frmAjouterReservationSoin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientEtInviteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeroNomEtPrenomAssistantBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soinEtDescriptionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMessage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblClientOuInvite;
        private System.Windows.Forms.Label lblNoAssistant;
        private System.Windows.Forms.Label lblNoSoins;
        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.Button btnFermer;
        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource clientEtInviteBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ClientEtInviteTableAdapter clientEtInviteTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ComboBox cboClientEtInvite;
        private System.Windows.Forms.BindingSource numeroNomEtPrenomAssistantBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.NumeroNomEtPrenomAssistantTableAdapter numeroNomEtPrenomAssistantTableAdapter;
        private System.Windows.Forms.ToolStrip fillToolStrip;
        private System.Windows.Forms.ToolStripLabel noSoinsToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox noSoinsToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillToolStripButton;
        private System.Windows.Forms.ComboBox cboNoAssistant;
        private System.Windows.Forms.BindingSource soinEtDescriptionBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.SoinEtDescriptionTableAdapter soinEtDescriptionTableAdapter;
        private System.Windows.Forms.ComboBox cboNoSoins;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Label lblHeure;
        private System.Windows.Forms.ErrorProvider errMessage;
        private System.Windows.Forms.DateTimePicker dtpHeure;
    }
}