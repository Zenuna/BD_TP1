﻿namespace TP1
{
    partial class frmGestionAssistant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgAssistant = new System.Windows.Forms.DataGridView();
            this.dgNoAssistant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPrenom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgNom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgSpecialites = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgRemarques = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assistantBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.btnSupprAssistant = new System.Windows.Forms.Button();
            this.btnAjouterAssistant = new System.Windows.Forms.Button();
            this.btnDernierAssistant = new System.Windows.Forms.Button();
            this.btnAssistantSuivant = new System.Windows.Forms.Button();
            this.btnAssistantPrecedent = new System.Windows.Forms.Button();
            this.btnPremierAssistant = new System.Windows.Forms.Button();
            this.assistantSoinDataGridView = new System.Windows.Forms.DataGridView();
            this.dgNoSoin = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.soinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.assistantSoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.assistantTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.AssistantTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.soinTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.SoinTableAdapter();
            this.assistantSoinTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.AssistantSoinTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dgAssistant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantSoinDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantSoinBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dgAssistant
            // 
            this.dgAssistant.AllowUserToAddRows = false;
            this.dgAssistant.AllowUserToDeleteRows = false;
            this.dgAssistant.AutoGenerateColumns = false;
            this.dgAssistant.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgAssistant.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgNoAssistant,
            this.dgPrenom,
            this.dgNom,
            this.dgSpecialites,
            this.dgRemarques});
            this.dgAssistant.DataSource = this.assistantBindingSource;
            this.dgAssistant.Location = new System.Drawing.Point(12, 12);
            this.dgAssistant.Name = "dgAssistant";
            this.dgAssistant.Size = new System.Drawing.Size(544, 220);
            this.dgAssistant.TabIndex = 1;
            this.dgAssistant.RowValidating += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgAssistant_RowValidating);
            // 
            // dgNoAssistant
            // 
            this.dgNoAssistant.DataPropertyName = "NoAssistant";
            this.dgNoAssistant.HeaderText = "NoAssistant";
            this.dgNoAssistant.Name = "dgNoAssistant";
            this.dgNoAssistant.ReadOnly = true;
            // 
            // dgPrenom
            // 
            this.dgPrenom.DataPropertyName = "Prenom";
            this.dgPrenom.HeaderText = "Prenom";
            this.dgPrenom.MaxInputLength = 20;
            this.dgPrenom.Name = "dgPrenom";
            // 
            // dgNom
            // 
            this.dgNom.DataPropertyName = "Nom";
            this.dgNom.HeaderText = "Nom";
            this.dgNom.MaxInputLength = 15;
            this.dgNom.Name = "dgNom";
            // 
            // dgSpecialites
            // 
            this.dgSpecialites.DataPropertyName = "Specialites";
            this.dgSpecialites.HeaderText = "Specialites";
            this.dgSpecialites.MaxInputLength = 15;
            this.dgSpecialites.Name = "dgSpecialites";
            // 
            // dgRemarques
            // 
            this.dgRemarques.DataPropertyName = "Remarques";
            this.dgRemarques.HeaderText = "Remarques";
            this.dgRemarques.MaxInputLength = 76;
            this.dgRemarques.Name = "dgRemarques";
            // 
            // assistantBindingSource
            // 
            this.assistantBindingSource.DataMember = "Assistant";
            this.assistantBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(162, 385);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(394, 23);
            this.btnAnnuler.TabIndex = 36;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            // 
            // btnSupprAssistant
            // 
            this.btnSupprAssistant.Location = new System.Drawing.Point(162, 414);
            this.btnSupprAssistant.Name = "btnSupprAssistant";
            this.btnSupprAssistant.Size = new System.Drawing.Size(394, 23);
            this.btnSupprAssistant.TabIndex = 35;
            this.btnSupprAssistant.Text = "Supprimer assistant";
            this.btnSupprAssistant.UseVisualStyleBackColor = true;
            this.btnSupprAssistant.Click += new System.EventHandler(this.btnSupprAssistant_Click);
            // 
            // btnAjouterAssistant
            // 
            this.btnAjouterAssistant.Location = new System.Drawing.Point(162, 356);
            this.btnAjouterAssistant.Name = "btnAjouterAssistant";
            this.btnAjouterAssistant.Size = new System.Drawing.Size(394, 23);
            this.btnAjouterAssistant.TabIndex = 34;
            this.btnAjouterAssistant.Text = "Ajouter assistant";
            this.btnAjouterAssistant.UseVisualStyleBackColor = true;
            this.btnAjouterAssistant.Click += new System.EventHandler(this.btnAjouterAssistant_Click);
            // 
            // btnDernierAssistant
            // 
            this.btnDernierAssistant.Location = new System.Drawing.Point(162, 327);
            this.btnDernierAssistant.Name = "btnDernierAssistant";
            this.btnDernierAssistant.Size = new System.Drawing.Size(394, 23);
            this.btnDernierAssistant.TabIndex = 33;
            this.btnDernierAssistant.Text = "Dernier assistant";
            this.btnDernierAssistant.UseVisualStyleBackColor = true;
            this.btnDernierAssistant.Click += new System.EventHandler(this.btnDernierAssistant_Click);
            // 
            // btnAssistantSuivant
            // 
            this.btnAssistantSuivant.Location = new System.Drawing.Point(162, 298);
            this.btnAssistantSuivant.Name = "btnAssistantSuivant";
            this.btnAssistantSuivant.Size = new System.Drawing.Size(394, 23);
            this.btnAssistantSuivant.TabIndex = 32;
            this.btnAssistantSuivant.Text = "Assistant suivant";
            this.btnAssistantSuivant.UseVisualStyleBackColor = true;
            this.btnAssistantSuivant.Click += new System.EventHandler(this.btnAssistantSuivant_Click);
            // 
            // btnAssistantPrecedent
            // 
            this.btnAssistantPrecedent.Location = new System.Drawing.Point(162, 269);
            this.btnAssistantPrecedent.Name = "btnAssistantPrecedent";
            this.btnAssistantPrecedent.Size = new System.Drawing.Size(394, 23);
            this.btnAssistantPrecedent.TabIndex = 31;
            this.btnAssistantPrecedent.Text = "Assistant précédent";
            this.btnAssistantPrecedent.UseVisualStyleBackColor = true;
            this.btnAssistantPrecedent.Click += new System.EventHandler(this.btnAssistantPrecedent_Click);
            // 
            // btnPremierAssistant
            // 
            this.btnPremierAssistant.Location = new System.Drawing.Point(162, 240);
            this.btnPremierAssistant.Name = "btnPremierAssistant";
            this.btnPremierAssistant.Size = new System.Drawing.Size(394, 23);
            this.btnPremierAssistant.TabIndex = 30;
            this.btnPremierAssistant.Text = "Premier assistant";
            this.btnPremierAssistant.UseVisualStyleBackColor = true;
            this.btnPremierAssistant.Click += new System.EventHandler(this.btnPremierAssistant_Click);
            // 
            // assistantSoinDataGridView
            // 
            this.assistantSoinDataGridView.AllowUserToAddRows = false;
            this.assistantSoinDataGridView.AllowUserToDeleteRows = false;
            this.assistantSoinDataGridView.AutoGenerateColumns = false;
            this.assistantSoinDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.assistantSoinDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgNoSoin});
            this.assistantSoinDataGridView.DataSource = this.assistantSoinBindingSource;
            this.assistantSoinDataGridView.Location = new System.Drawing.Point(12, 240);
            this.assistantSoinDataGridView.Name = "assistantSoinDataGridView";
            this.assistantSoinDataGridView.ReadOnly = true;
            this.assistantSoinDataGridView.Size = new System.Drawing.Size(144, 197);
            this.assistantSoinDataGridView.TabIndex = 36;
            // 
            // dgNoSoin
            // 
            this.dgNoSoin.DataPropertyName = "NoSoin";
            this.dgNoSoin.DataSource = this.soinBindingSource;
            this.dgNoSoin.DisplayMember = "Description";
            this.dgNoSoin.HeaderText = "Soins offert";
            this.dgNoSoin.Name = "dgNoSoin";
            this.dgNoSoin.ReadOnly = true;
            this.dgNoSoin.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgNoSoin.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgNoSoin.ValueMember = "NoSoin";
            // 
            // soinBindingSource
            // 
            this.soinBindingSource.DataMember = "Soin";
            this.soinBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // assistantSoinBindingSource
            // 
            this.assistantSoinBindingSource.DataMember = "AssistantSoin";
            this.assistantSoinBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // assistantTableAdapter
            // 
            this.assistantTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = this.assistantTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = this.soinTableAdapter;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // soinTableAdapter
            // 
            this.soinTableAdapter.ClearBeforeFill = true;
            // 
            // assistantSoinTableAdapter
            // 
            this.assistantSoinTableAdapter.ClearBeforeFill = true;
            // 
            // frmGestionAssistant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(578, 447);
            this.Controls.Add(this.assistantSoinDataGridView);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnSupprAssistant);
            this.Controls.Add(this.btnAjouterAssistant);
            this.Controls.Add(this.btnDernierAssistant);
            this.Controls.Add(this.btnAssistantSuivant);
            this.Controls.Add(this.btnAssistantPrecedent);
            this.Controls.Add(this.btnPremierAssistant);
            this.Controls.Add(this.dgAssistant);
            this.Name = "frmGestionAssistant";
            this.Text = "Gestion des assistants";
            this.Load += new System.EventHandler(this.frmGestionAssistant_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgAssistant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantSoinDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantSoinBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource assistantBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.AssistantTableAdapter assistantTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView dgAssistant;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.Button btnSupprAssistant;
        private System.Windows.Forms.Button btnAjouterAssistant;
        private System.Windows.Forms.Button btnDernierAssistant;
        private System.Windows.Forms.Button btnAssistantSuivant;
        private System.Windows.Forms.Button btnAssistantPrecedent;
        private System.Windows.Forms.Button btnPremierAssistant;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.SoinTableAdapter soinTableAdapter;
        private System.Windows.Forms.BindingSource soinBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgNoAssistant;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgPrenom;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgNom;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgSpecialites;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgRemarques;
        private System.Windows.Forms.BindingSource assistantSoinBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.AssistantSoinTableAdapter assistantSoinTableAdapter;
        private System.Windows.Forms.DataGridView assistantSoinDataGridView;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgNoSoin;
    }
}