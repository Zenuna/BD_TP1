﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmReservationChambre : Form
    {
        public frmReservationChambre()
        {
            InitializeComponent();
        }

        private void reservationChambreBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.reservationChambreBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bD5B6TP1_KoumaJouaniqueDataSet);

        }

        private void frmReservationChambre_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.reservationChambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre);

        }

        private void btnAjouterReservationChambre_Click(object sender, EventArgs e)
        {
            BD5B6TP1_KoumaJouaniqueDataSet.ReservationChambreRow uneReservation = bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre.NewReservationChambreRow();
            uneReservation.DateArrivee = DateTime.MaxValue;
            frmAjouterReservationChambre fAjouterReservationChambre = new frmAjouterReservationChambre();
            fAjouterReservationChambre.uneReservation = uneReservation;
            fAjouterReservationChambre.ShowDialog();

            if (uneReservation.DateDepart != DateTime.MaxValue)
            {
                bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre.AddReservationChambreRow(uneReservation);
                reservationChambreBindingSource.MoveLast();
                MessageBox.Show("La nouvelle réservation a été planifié avec succès");
            }
        }

        private void btnSupprimerReservationChambre_Click(object sender, EventArgs e)
        {
            reservationChambreBindingSource.RemoveCurrent();
        }
    }
}
