﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmRapportSoinsClient : Form
    {
        public frmRapportSoinsClient()
        {
            InitializeComponent();
        }

        private void frmRapportSoinsClient_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.tableRapportSoins'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.tableRapportSoinsTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.tableRapportSoins);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.rapportSoins'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.rapportSoinsTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.rapportSoins);
            double totalSoin = 0;
            foreach (DataGridViewRow row in dgRapportSoin.Rows)
            {
                totalSoin += double.Parse(row.Cells["dgPrix"].Value.ToString());

            }
            lbPrix.Text = "Total des soins:" + totalSoin.ToString() + "$";

        }
        

        private void btnEnvoyer_Click(object sender, EventArgs e)
        {
            double totalSoin = 0;
            foreach (DataGridViewRow row in dgRapportSoin.Rows)
            {
                totalSoin += double.Parse(row.Cells["dgPrix"].Value.ToString());

            }
            lbPrix.Text = "Total des soins:" + totalSoin.ToString() + "$";
        }
    }
}
