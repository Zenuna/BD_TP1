﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TP1
{
    public partial class frmAjouterReservationChambre : Form
    {
        public BD5B6TP1_KoumaJouaniqueDataSet.ReservationChambreRow uneReservation;
        static String maChaineDeConnexion = "Data Source = sqlinfo.cgodin.qc.ca; Initial Catalog = BD5B6TP1_KoumaJouanique; Persist Security Info=True;User ID = 5B6Kouma;Password=1PetitDioulaBanchi";

        public frmAjouterReservationChambre()
        {
            InitializeComponent();
        }

        private void nomClientBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.nomClientBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bD5B6TP1_KoumaJouaniqueDataSet);

        }

        private void frmAjouterReservationChambre_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.DataGridViewDeChambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.dataGridViewDeChambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.DataGridViewDeChambre);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Chambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.chambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Chambre);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.NomClient'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.nomClientTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.NomClient);

        }

        private void btnFermer_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {

            if (dtpDateArrivee.Value > dtpDepart.Value)
            {
                errMessage.SetError(dtpDateArrivee, "La date d'arrivée ne peut être supérieure à la date de départ ");
            }
            else
            {
                Boolean booReserve = false;
                SqlConnection maConnexion = new SqlConnection(maChaineDeConnexion);
                maConnexion.Open();
               // MessageBox.Show(dataGridViewDeChambreDataGridView.CurrentRow.Cells[0].Value.ToString());
                int noChambre = int.Parse(dataGridViewDeChambreDataGridView.CurrentRow.Cells[0].Value.ToString());
                String maRequeteSQL = "select DateArrivee, DateDepart from ReservationChambre where NoChambre =  " + noChambre;
                SqlCommand maCommande = new SqlCommand(maRequeteSQL, maConnexion);
                SqlDataReader monReader = maCommande.ExecuteReader();
                while (monReader.Read()) // Lire le prochain enregistrement (la prochaine ligne)
                {
                    // L'index peut être un numéro de colonne ou le nom d'une colonne
                    //Console.WriteLine("Prénom = " + monReader[0] + ", Nom = " + monReader["empNom"]);
                    if (dtpDateArrivee.Value.CompareTo(monReader[0]) > 0 && dtpDateArrivee.Value.CompareTo(monReader[1]) > 0)
                    {
                        booReserve = true;
                    }
                }

                if (booReserve)
                {
                    errMessage.SetError(dtpDateArrivee, "La chambre n'est pas disponible dans cet intervalle de date");
                }
                else
                {
                    errMessage.Clear();
                    uneReservation.NoClient = int.Parse(nomComboBox.SelectedValue.ToString());
                    uneReservation.NoChambre = noChambre;
                    uneReservation.DateArrivee = dtpDateArrivee.Value;
                    uneReservation.DateDepart = dtpDepart.Value;
                    uneReservation.NbPersonnes =int.Parse(nupNbPersonne.Value.ToString());
                    this.Close();
                }
            }

        }
    }
}
