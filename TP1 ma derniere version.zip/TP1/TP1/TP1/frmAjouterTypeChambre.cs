﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TP1
{
    public partial class frmAjouterTypeChambre : Form
    {
        public BD5B6TP1_KoumaJouaniqueDataSet.TypeChambreRow unTypeChambre;
        static String maChaineDeConnexion = "Data Source = sqlinfo.cgodin.qc.ca; Initial Catalog = BD5B6TP1_KoumaJouanique; Persist Security Info=True;User ID = 5B6Kouma;Password=1PetitDioulaBanchi";

        public frmAjouterTypeChambre()
        {
            InitializeComponent();
        }

        private void btnFermer_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {
            SqlConnection maConnexion = new SqlConnection(maChaineDeConnexion);
            maConnexion.Open();
            String maRequeteSQL = "select count(*) from TypeChambre where Description = '" + txtDescription.Text + "'" ;
            SqlCommand maCommande = new SqlCommand(maRequeteSQL, maConnexion);
            
            // Toujours convertir car ExecuteScalar retourne un objet sans type
            int compteur = 0;
            dynamic retour = maCommande.ExecuteScalar();
            compteur = int.Parse(retour + "");

           // MessageBox.Show(compteur.ToString());
            //MessageBox.Show(compteur);
            if (txtDescription.Text == "")
            {
                errMessage.SetError(txtDescription, "La description ne peut etre vide");
            }
            else if (txtPrixHaut.Text == "")
            {
                errMessage.SetError(txtPrixHaut, "Le prix haut ne peut être vide");
            }
            else if (txtPrixBas.Text == "")
            {
                errMessage.SetError(txtPrixBas, "Le prix bas ne peut être vide");
            }
            else if (txtPrixMoyen.Text == "")
            {
                errMessage.SetError(txtPrixMoyen, "Le prix moyen ne peut être vide");
            }
            else if (int.Parse(txtPrixBas.Text) > int.Parse(txtPrixHaut.Text))
            {
                errMessage.SetError(txtPrixBas, "Le prix bas ne peut être plus grand que le prix haut");
            }
            else if (int.Parse(txtPrixMoyen.Text) > int.Parse(txtPrixHaut.Text) || int.Parse(txtPrixMoyen.Text) < int.Parse(txtPrixBas.Text))
            {
                errMessage.SetError(txtPrixMoyen, "Le prix moyen doit etre entre le prix bas et le prix haut");
            }
          

            else if (compteur > 0)
            {
                errMessage.SetError(txtDescription, "La description doit être unique");
            }
            else
            {
                errMessage.Clear();
                unTypeChambre.Description = txtDescription.Text;
                unTypeChambre.PrixBas = int.Parse(txtPrixBas.Text);
                unTypeChambre.PrixHaut = int.Parse(txtPrixHaut.Text);
                unTypeChambre.PrixMoyen = int.Parse(txtPrixMoyen.Text);
                // uneChambre.NoTypeChambre = int.Parse(cboNoTypeChambre.SelectedValue.ToString());
                this.Close();
            }

        }
    }
}
