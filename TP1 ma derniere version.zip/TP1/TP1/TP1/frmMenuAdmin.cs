﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmMenuAdmin : Form
    {
        public String noUtilisateur;
        public frmMenuAdmin()
        {
            InitializeComponent();
        }

        private void lblBienvenue_Click(object sender, EventArgs e)
        {

        }

        private void btnGererUsers_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmGestionUtilisateur fGestionUtilisateur = new frmGestionUtilisateur();
            fGestionUtilisateur.noUtilisateur = noUtilisateur;
            fGestionUtilisateur.ShowDialog();
            this.Show();
        }

        private void btnGererCLientEtInvite_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMenuGestionClientInvite fMenuGestionClientInvité = new frmMenuGestionClientInvite();
            fMenuGestionClientInvité.ShowDialog();
            this.Show();
        }

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            bD5B6TP1_KoumaJouaniqueDataSet.Utilisateur.WriteXml("Utilisateur.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.Client.WriteXml("Client.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.Invite.WriteXml("Invite.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.Assistant.WriteXml("Assistant.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.AssistantSoin.WriteXml("AssistantSoin.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.Soin.WriteXml("Soin.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.PlanifSoin.WriteXml("PlanifSoin.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.Chambre.WriteXml("Chambre.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.TypeChambre.WriteXml("TypeChambre.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre.WriteXml("ReservationCHambre.xml");
            Environment.Exit(1);

        }

        private void btnDeconnexion_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGererAssistantEtSoins_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMenuGestionAssistantSoin fMenuGestionAssistantSoin = new frmMenuGestionAssistantSoin();
            fMenuGestionAssistantSoin.ShowDialog();
            this.Show();
        }

        private void btnVisualiserRapport_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMenuVisualiserRapport fMenuVisualiserRapport = new frmMenuVisualiserRapport();
            fMenuVisualiserRapport.ShowDialog();
            this.Show();
        }


        private void frmMenuAdmin_Load(object sender, EventArgs e)
        {

        }

        private void btnGererSOins_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmGestionSoins fGestionSoins = new frmGestionSoins();
            fGestionSoins.ShowDialog();
            this.Show();
        }

        private void btnPlannifierSoins_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmPlanificationSoins fPlanificationSoin = new frmPlanificationSoins();
            fPlanificationSoin.ShowDialog();
            this.Show();
        }

        private void btnGererChambre_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmGestionChambreEtTypeChambre fGestionChambreEtTypeChambre = new frmGestionChambreEtTypeChambre();
            fGestionChambreEtTypeChambre.ShowDialog();
            this.Show();
        }

        private void btnReserverChambre_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmReservationChambre fReservationChambre = new frmReservationChambre();
            fReservationChambre.ShowDialog();
            this.Show();
        }
    }
}
