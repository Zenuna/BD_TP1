﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmRapportSoinsAssistant : Form
    {
        public frmRapportSoinsAssistant()
        {
            InitializeComponent();
        }

        private void frmRapportSoinsAssistant_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.PrenomNomAssistant'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.prenomNomAssistantTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.PrenomNomAssistant);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.RapportAssistantJour'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.rapportAssistantJourTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.RapportAssistantJour);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.rapportSoins'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.rapportSoinsTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.rapportSoins);
            this.rapportSoinsJournalierTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.RapportSoinsJournalier, DateSoin.Value.ToShortDateString());

        }

        private void DateSoin_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                this.rapportSoinsJournalierTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.RapportSoinsJournalier, DateSoin.Value.ToShortDateString());
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

    }
}
