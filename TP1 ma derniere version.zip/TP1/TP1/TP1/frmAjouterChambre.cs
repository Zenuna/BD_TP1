﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Globalization;

namespace TP1
{
    public partial class frmAjouterChambre : Form
    {
        public BD5B6TP1_KoumaJouaniqueDataSet.ChambreRow uneChambre;
        public frmAjouterChambre()
        {
            InitializeComponent();
        }

        private void frmAjouterChambre_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.typeSoinsEtDescription'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.typeSoinsEtDescriptionTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.typeSoinsEtDescription);

        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {
            if (txtDecoration.Text == "")
            {
                errMessage.SetError(txtDecoration, "La décoration ne peut etre vide");
            }
            else if (txtEmplacement.Text == "")
            {
                errMessage.SetError(txtEmplacement, "L'emplacement ne peut être vide");
            }
            else { 
            uneChambre.Decorations = txtDecoration.Text;
            uneChambre.Emplacement = txtEmplacement.Text;
            uneChambre.NoTypeChambre = int.Parse(cboNoTypeChambre.SelectedValue.ToString());
            this.Close();
        }
        }

        private void btnFermer_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
