﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmMenuVisualiserRapport : Form
    {
        public frmMenuVisualiserRapport()
        {
            InitializeComponent();
        }

        private void btnRapportSoinsClient_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmRapportSoinsClient fRapportSoinsClient = new frmRapportSoinsClient();
            fRapportSoinsClient.ShowDialog();
            this.Show();
        }

        private void btnRapportReservation_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmRapportChambre fRapportChambre = new frmRapportChambre();
            fRapportChambre.ShowDialog();
            this.Show();
        }

        private void btnRapportSoinsAssistants_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmRapportSoinsAssistant fRapportSoinsAssistant = new frmRapportSoinsAssistant();
            fRapportSoinsAssistant.ShowDialog();
            this.Show();
        }
    }
}
