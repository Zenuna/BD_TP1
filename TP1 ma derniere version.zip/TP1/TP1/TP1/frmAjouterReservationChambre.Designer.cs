﻿namespace TP1
{
    partial class frmAjouterReservationChambre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.nomClientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nomClientTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.NomClientTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.chambreTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ChambreTableAdapter();
            this.nomComboBox = new System.Windows.Forms.ComboBox();
            this.chambreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewDeChambreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewDeChambreTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.DataGridViewDeChambreTableAdapter();
            this.dataGridViewDeChambreDataGridView = new System.Windows.Forms.DataGridView();
            this.dgNoChambre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgEmplacement = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgDecoration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPrixHaut = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPrixBas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPrixMoyen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtpDateArrivee = new System.Windows.Forms.DateTimePicker();
            this.dtpDepart = new System.Windows.Forms.DateTimePicker();
            this.nupNbPersonne = new System.Windows.Forms.NumericUpDown();
            this.btnAjouter = new System.Windows.Forms.Button();
            this.btnFermer = new System.Windows.Forms.Button();
            this.errMessage = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nomClientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chambreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDeChambreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDeChambreDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupNbPersonne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMessage)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "No Client";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "No Chambre";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 308);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Date d\'arrivée";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 344);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Date de départ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 381);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "nbPersonne";
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nomClientBindingSource
            // 
            this.nomClientBindingSource.DataMember = "NomClient";
            this.nomClientBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // nomClientTableAdapter
            // 
            this.nomClientTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = this.chambreTableAdapter;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.NomClientTableAdapter = this.nomClientTableAdapter;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.PrenomNomClientTableAdapter = null;
            this.tableAdapterManager.RapportAssistantJourTableAdapter = null;
            this.tableAdapterManager.RapportChambreTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.typchambreEtDescriptionTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.typeSoinsEtDescriptionTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // chambreTableAdapter
            // 
            this.chambreTableAdapter.ClearBeforeFill = true;
            // 
            // nomComboBox
            // 
            this.nomComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nomClientBindingSource, "Nom", true));
            this.nomComboBox.DataSource = this.nomClientBindingSource;
            this.nomComboBox.DisplayMember = "Nom";
            this.nomComboBox.FormattingEnabled = true;
            this.nomComboBox.Location = new System.Drawing.Point(113, 26);
            this.nomComboBox.Name = "nomComboBox";
            this.nomComboBox.Size = new System.Drawing.Size(121, 21);
            this.nomComboBox.TabIndex = 7;
            this.nomComboBox.ValueMember = "NoClient";
            // 
            // chambreBindingSource
            // 
            this.chambreBindingSource.DataMember = "Chambre";
            this.chambreBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // dataGridViewDeChambreBindingSource
            // 
            this.dataGridViewDeChambreBindingSource.DataMember = "DataGridViewDeChambre";
            this.dataGridViewDeChambreBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // dataGridViewDeChambreTableAdapter
            // 
            this.dataGridViewDeChambreTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewDeChambreDataGridView
            // 
            this.dataGridViewDeChambreDataGridView.AllowUserToAddRows = false;
            this.dataGridViewDeChambreDataGridView.AutoGenerateColumns = false;
            this.dataGridViewDeChambreDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDeChambreDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgNoChambre,
            this.dgEmplacement,
            this.dgDecoration,
            this.dgPrixHaut,
            this.dgPrixBas,
            this.dgPrixMoyen});
            this.dataGridViewDeChambreDataGridView.DataSource = this.dataGridViewDeChambreBindingSource;
            this.dataGridViewDeChambreDataGridView.Location = new System.Drawing.Point(113, 53);
            this.dataGridViewDeChambreDataGridView.Name = "dataGridViewDeChambreDataGridView";
            this.dataGridViewDeChambreDataGridView.Size = new System.Drawing.Size(645, 220);
            this.dataGridViewDeChambreDataGridView.TabIndex = 7;
            // 
            // dgNoChambre
            // 
            this.dgNoChambre.DataPropertyName = "NoChambre";
            this.dgNoChambre.HeaderText = "NoChambre";
            this.dgNoChambre.Name = "dgNoChambre";
            // 
            // dgEmplacement
            // 
            this.dgEmplacement.DataPropertyName = "Emplacement";
            this.dgEmplacement.HeaderText = "Emplacement";
            this.dgEmplacement.Name = "dgEmplacement";
            // 
            // dgDecoration
            // 
            this.dgDecoration.DataPropertyName = "Decorations";
            this.dgDecoration.HeaderText = "Decorations";
            this.dgDecoration.Name = "dgDecoration";
            // 
            // dgPrixHaut
            // 
            this.dgPrixHaut.DataPropertyName = "PrixHaut";
            this.dgPrixHaut.HeaderText = "PrixHaut";
            this.dgPrixHaut.Name = "dgPrixHaut";
            // 
            // dgPrixBas
            // 
            this.dgPrixBas.DataPropertyName = "PrixBas";
            this.dgPrixBas.HeaderText = "PrixBas";
            this.dgPrixBas.Name = "dgPrixBas";
            // 
            // dgPrixMoyen
            // 
            this.dgPrixMoyen.DataPropertyName = "PrixMoyen";
            this.dgPrixMoyen.HeaderText = "PrixMoyen";
            this.dgPrixMoyen.Name = "dgPrixMoyen";
            // 
            // dtpDateArrivee
            // 
            this.dtpDateArrivee.Location = new System.Drawing.Point(137, 300);
            this.dtpDateArrivee.Name = "dtpDateArrivee";
            this.dtpDateArrivee.Size = new System.Drawing.Size(200, 20);
            this.dtpDateArrivee.TabIndex = 8;
            // 
            // dtpDepart
            // 
            this.dtpDepart.Location = new System.Drawing.Point(137, 336);
            this.dtpDepart.Name = "dtpDepart";
            this.dtpDepart.Size = new System.Drawing.Size(200, 20);
            this.dtpDepart.TabIndex = 9;
            // 
            // nupNbPersonne
            // 
            this.nupNbPersonne.Location = new System.Drawing.Point(137, 379);
            this.nupNbPersonne.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.nupNbPersonne.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nupNbPersonne.Name = "nupNbPersonne";
            this.nupNbPersonne.Size = new System.Drawing.Size(120, 20);
            this.nupNbPersonne.TabIndex = 11;
            this.nupNbPersonne.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnAjouter
            // 
            this.btnAjouter.Location = new System.Drawing.Point(474, 300);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(75, 23);
            this.btnAjouter.TabIndex = 12;
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.UseVisualStyleBackColor = true;
            this.btnAjouter.Click += new System.EventHandler(this.btnAjouter_Click);
            // 
            // btnFermer
            // 
            this.btnFermer.Location = new System.Drawing.Point(474, 344);
            this.btnFermer.Name = "btnFermer";
            this.btnFermer.Size = new System.Drawing.Size(75, 23);
            this.btnFermer.TabIndex = 13;
            this.btnFermer.Text = "Fermer";
            this.btnFermer.UseVisualStyleBackColor = true;
            this.btnFermer.Click += new System.EventHandler(this.btnFermer_Click);
            // 
            // errMessage
            // 
            this.errMessage.ContainerControl = this;
            // 
            // frmAjouterReservationChambre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 414);
            this.Controls.Add(this.btnFermer);
            this.Controls.Add(this.btnAjouter);
            this.Controls.Add(this.nupNbPersonne);
            this.Controls.Add(this.dtpDepart);
            this.Controls.Add(this.dtpDateArrivee);
            this.Controls.Add(this.dataGridViewDeChambreDataGridView);
            this.Controls.Add(this.nomComboBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmAjouterReservationChambre";
            this.Text = "Ajouter une reservation de chambre";
            this.Load += new System.EventHandler(this.frmAjouterReservationChambre_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nomClientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chambreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDeChambreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDeChambreDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupNbPersonne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMessage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource nomClientBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.NomClientTableAdapter nomClientTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ChambreTableAdapter chambreTableAdapter;
        private System.Windows.Forms.ComboBox nomComboBox;
        private System.Windows.Forms.BindingSource chambreBindingSource;
        private System.Windows.Forms.BindingSource dataGridViewDeChambreBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.DataGridViewDeChambreTableAdapter dataGridViewDeChambreTableAdapter;
        private System.Windows.Forms.DataGridView dataGridViewDeChambreDataGridView;
        private System.Windows.Forms.DateTimePicker dtpDateArrivee;
        private System.Windows.Forms.DateTimePicker dtpDepart;
        private System.Windows.Forms.NumericUpDown nupNbPersonne;
        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.Button btnFermer;
        private System.Windows.Forms.ErrorProvider errMessage;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgNoChambre;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgEmplacement;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgDecoration;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgPrixHaut;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgPrixBas;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgPrixMoyen;
    }
}