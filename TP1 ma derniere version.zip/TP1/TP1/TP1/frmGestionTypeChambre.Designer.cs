﻿namespace TP1
{
    partial class frmGestionTypeChambre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnSupprimerTypeChambre = new System.Windows.Forms.Button();
            this.btnModifierTypeChambre = new System.Windows.Forms.Button();
            this.btnAjouterTypeChambre = new System.Windows.Forms.Button();
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.typeChambreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.typeChambreTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TypeChambreTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.typeChambreDataGridView = new System.Windows.Forms.DataGridView();
            this.dgNoTypeChambre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPrixHaut = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPrixBas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPrixMoyen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chambreTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ChambreTableAdapter();
            this.chambreDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chambreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeChambreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeChambreDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chambreDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chambreBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSupprimerTypeChambre
            // 
            this.btnSupprimerTypeChambre.Location = new System.Drawing.Point(326, 247);
            this.btnSupprimerTypeChambre.Name = "btnSupprimerTypeChambre";
            this.btnSupprimerTypeChambre.Size = new System.Drawing.Size(104, 48);
            this.btnSupprimerTypeChambre.TabIndex = 5;
            this.btnSupprimerTypeChambre.Text = "Supprimer un type de chambre";
            this.btnSupprimerTypeChambre.UseVisualStyleBackColor = true;
            this.btnSupprimerTypeChambre.Click += new System.EventHandler(this.btnSupprimerTypeChambre_Click);
            // 
            // btnModifierTypeChambre
            // 
            this.btnModifierTypeChambre.Location = new System.Drawing.Point(201, 247);
            this.btnModifierTypeChambre.Name = "btnModifierTypeChambre";
            this.btnModifierTypeChambre.Size = new System.Drawing.Size(104, 48);
            this.btnModifierTypeChambre.TabIndex = 4;
            this.btnModifierTypeChambre.Text = "Enrégistrer les modifications";
            this.btnModifierTypeChambre.UseVisualStyleBackColor = true;
            this.btnModifierTypeChambre.Click += new System.EventHandler(this.btnModifierTypeChambre_Click);
            // 
            // btnAjouterTypeChambre
            // 
            this.btnAjouterTypeChambre.Location = new System.Drawing.Point(82, 247);
            this.btnAjouterTypeChambre.Name = "btnAjouterTypeChambre";
            this.btnAjouterTypeChambre.Size = new System.Drawing.Size(104, 48);
            this.btnAjouterTypeChambre.TabIndex = 3;
            this.btnAjouterTypeChambre.Text = "Ajouter un type de chambre";
            this.btnAjouterTypeChambre.UseVisualStyleBackColor = true;
            this.btnAjouterTypeChambre.Click += new System.EventHandler(this.btnAjouterTypeChambre_Click);
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // typeChambreBindingSource
            // 
            this.typeChambreBindingSource.DataMember = "TypeChambre";
            this.typeChambreBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // typeChambreTableAdapter
            // 
            this.typeChambreTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.NomClientTableAdapter = null;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.PrenomNomClientTableAdapter = null;
            this.tableAdapterManager.RapportAssistantJourTableAdapter = null;
            this.tableAdapterManager.RapportChambreTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.typchambreEtDescriptionTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = this.typeChambreTableAdapter;
            this.tableAdapterManager.typeSoinsEtDescriptionTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // typeChambreDataGridView
            // 
            this.typeChambreDataGridView.AllowUserToAddRows = false;
            this.typeChambreDataGridView.AutoGenerateColumns = false;
            this.typeChambreDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.typeChambreDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgNoTypeChambre,
            this.dgDescription,
            this.dgPrixHaut,
            this.dgPrixBas,
            this.dgPrixMoyen});
            this.typeChambreDataGridView.DataSource = this.typeChambreBindingSource;
            this.typeChambreDataGridView.Location = new System.Drawing.Point(11, 12);
            this.typeChambreDataGridView.Name = "typeChambreDataGridView";
            this.typeChambreDataGridView.Size = new System.Drawing.Size(543, 220);
            this.typeChambreDataGridView.TabIndex = 6;
            this.typeChambreDataGridView.RowValidating += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.typeChambreDataGridView_RowValidating);
            // 
            // dgNoTypeChambre
            // 
            this.dgNoTypeChambre.DataPropertyName = "NoTypeChambre";
            this.dgNoTypeChambre.HeaderText = "NoTypeChambre";
            this.dgNoTypeChambre.Name = "dgNoTypeChambre";
            this.dgNoTypeChambre.ReadOnly = true;
            // 
            // dgDescription
            // 
            this.dgDescription.DataPropertyName = "Description";
            this.dgDescription.HeaderText = "Description";
            this.dgDescription.Name = "dgDescription";
            // 
            // dgPrixHaut
            // 
            this.dgPrixHaut.DataPropertyName = "PrixHaut";
            this.dgPrixHaut.HeaderText = "PrixHaut";
            this.dgPrixHaut.Name = "dgPrixHaut";
            // 
            // dgPrixBas
            // 
            this.dgPrixBas.DataPropertyName = "PrixBas";
            this.dgPrixBas.HeaderText = "PrixBas";
            this.dgPrixBas.Name = "dgPrixBas";
            // 
            // dgPrixMoyen
            // 
            this.dgPrixMoyen.DataPropertyName = "PrixMoyen";
            this.dgPrixMoyen.HeaderText = "PrixMoyen";
            this.dgPrixMoyen.Name = "dgPrixMoyen";
            // 
            // chambreTableAdapter
            // 
            this.chambreTableAdapter.ClearBeforeFill = true;
            // 
            // chambreDataGridView
            // 
            this.chambreDataGridView.AllowUserToAddRows = false;
            this.chambreDataGridView.AutoGenerateColumns = false;
            this.chambreDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.chambreDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.chambreDataGridView.DataSource = this.chambreBindingSource;
            this.chambreDataGridView.Location = new System.Drawing.Point(578, 12);
            this.chambreDataGridView.Name = "chambreDataGridView";
            this.chambreDataGridView.Size = new System.Drawing.Size(346, 220);
            this.chambreDataGridView.TabIndex = 6;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "NoChambre";
            this.dataGridViewTextBoxColumn6.HeaderText = "NoChambre";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Emplacement";
            this.dataGridViewTextBoxColumn7.HeaderText = "Emplacement";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Decorations";
            this.dataGridViewTextBoxColumn8.HeaderText = "Decorations";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // chambreBindingSource
            // 
            this.chambreBindingSource.DataMember = "FK_NoTypeChambre";
            this.chambreBindingSource.DataSource = this.typeChambreBindingSource;
            // 
            // frmGestionTypeChambre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(945, 315);
            this.Controls.Add(this.chambreDataGridView);
            this.Controls.Add(this.typeChambreDataGridView);
            this.Controls.Add(this.btnSupprimerTypeChambre);
            this.Controls.Add(this.btnModifierTypeChambre);
            this.Controls.Add(this.btnAjouterTypeChambre);
            this.Name = "frmGestionTypeChambre";
            this.Text = "Gestion des Type de Chambres";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmGestionTypeChambre_FormClosing);
            this.Load += new System.EventHandler(this.frmGestionTypeChambre_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeChambreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeChambreDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chambreDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chambreBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSupprimerTypeChambre;
        private System.Windows.Forms.Button btnModifierTypeChambre;
        private System.Windows.Forms.Button btnAjouterTypeChambre;
        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource typeChambreBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TypeChambreTableAdapter typeChambreTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView typeChambreDataGridView;
        private System.Windows.Forms.BindingSource chambreBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ChambreTableAdapter chambreTableAdapter;
        private System.Windows.Forms.DataGridView chambreDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgNoTypeChambre;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgPrixHaut;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgPrixBas;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgPrixMoyen;
    }
}