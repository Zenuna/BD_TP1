﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TP1
{
    public partial class frmReservationChambre : Form
    {
        static String maChaineDeConnexion = "Data Source = sqlinfo.cgodin.qc.ca; Initial Catalog = BD5B6TP1_KoumaJouanique; Persist Security Info=True;User ID = 5B6Kouma;Password=1PetitDioulaBanchi";

        public frmReservationChambre()
        {
            InitializeComponent();
        }

        private void reservationChambreBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.reservationChambreBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bD5B6TP1_KoumaJouaniqueDataSet);

        }

        private void frmReservationChambre_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.reservationChambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre);

        }

        private void btnAjouterReservationChambre_Click(object sender, EventArgs e)
        {
            BD5B6TP1_KoumaJouaniqueDataSet.ReservationChambreRow uneReservation = bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre.NewReservationChambreRow();
            uneReservation.DateArrivee = DateTime.MaxValue;
            frmAjouterReservationChambre fAjouterReservationChambre = new frmAjouterReservationChambre();
            fAjouterReservationChambre.uneReservation = uneReservation;
            fAjouterReservationChambre.ShowDialog();



            if (uneReservation.DateDepart != DateTime.MaxValue)
            {
                bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre.AddReservationChambreRow(uneReservation);
                reservationChambreBindingSource.MoveLast();
                MessageBox.Show("La nouvelle réservation a été planifié avec succès mais pas enregistré. Pour faire la sauvegarde veuillez cliquer sur le bouton enregistrer", "Confirmation d'ajout", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSupprimerReservationChambre_Click(object sender, EventArgs e)
        {
            reservationChambreBindingSource.RemoveCurrent();
        }

        private void btnModifierReservationChambre_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.reservationChambreBindingSource.EndEdit();
            try
            {
                this.reservationChambreTableAdapter.Update(this.bD5B6TP1_KoumaJouaniqueDataSet);
                MessageBox.Show("Modifications enrégistré avec succès", "Confirmation de sauvegarde", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Conflit d'accès concurrentiel", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void frmReservationChambre_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Vous êtes sur le point de fermer ce formulaire. Voulez-vous l'enregistrer ?", "Fermeture",
   MessageBoxButtons.YesNo, MessageBoxIcon.Question,
   MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.Yes)
            {
                this.Validate();
                this.reservationChambreBindingSource.EndEdit();
                try
                {
                    this.reservationChambreTableAdapter.Update(this.bD5B6TP1_KoumaJouaniqueDataSet);
                    MessageBox.Show("Modifications enrégistré avec succès", "Confirmation de sauvegarde", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch
                {
                    MessageBox.Show("Conflit d'accès concurrentiel", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void reservationChambreDataGridView_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {
            String strMessageErreur = "";
            DateTime dateArrive = (DateTime) reservationChambreDataGridView.CurrentRow.Cells[2].Value;
            DateTime dateDepart = (DateTime)reservationChambreDataGridView.CurrentRow.Cells[3].Value;
            if (dateArrive > dateDepart)
            {
                strMessageErreur = "La date d'arrivée ne peut être supérieure à la date de départ ";
                e.Cancel = true;
            }
            else
            {
                Boolean booReserve = false;
                SqlConnection maConnexion = new SqlConnection(maChaineDeConnexion);
                maConnexion.Open();
                // MessageBox.Show(dataGridViewDeChambreDataGridView.CurrentRow.Cells[0].Value.ToString());
                int noChambre = int.Parse(reservationChambreDataGridView.CurrentRow.Cells[1].Value.ToString());
                String maRequeteSQL = "select DateArrivee, DateDepart from ReservationChambre where NoChambre =  " + noChambre;
                SqlCommand maCommande = new SqlCommand(maRequeteSQL, maConnexion);
                SqlDataReader monReader = maCommande.ExecuteReader();
                while (monReader.Read()) // Lire le prochain enregistrement (la prochaine ligne)
                {
                    // L'index peut être un numéro de colonne ou le nom d'une colonne
                    //Console.WriteLine("Prénom = " + monReader[0] + ", Nom = " + monReader["empNom"]);
                    if (dateArrive.CompareTo(monReader[0]) > 0 && dateArrive.CompareTo(monReader[1]) > 0)
                    {
                        booReserve = true;
                    }
                }

                if (booReserve)
                {
                    strMessageErreur = "La chambre n'est pas disponible dans cet intervalle de date";
                    e.Cancel = true;
                }
            }
            reservationChambreDataGridView.Rows[e.RowIndex].ErrorText = strMessageErreur;
        }
    }
}
