﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmGestionChambre : Form
    {
        public frmGestionChambre()
        {
            InitializeComponent();
        }

        private void chambreBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.chambreBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bD5B6TP1_KoumaJouaniqueDataSet);

        }

        private void frmGestionChambre_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.typchambreEtDescription'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.typchambreEtDescriptionTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.typchambreEtDescription);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.reservationChambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.typeSoinsEtDescription'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.typeSoinsEtDescriptionTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.typeSoinsEtDescription);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Chambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.chambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Chambre);

        }

        private void btnAjouterChambre_Click(object sender, EventArgs e)
        {
            BD5B6TP1_KoumaJouaniqueDataSet.ChambreRow uneChambre = bD5B6TP1_KoumaJouaniqueDataSet.Chambre.NewChambreRow();
            decimal noChambreMax = 0;
            foreach (BD5B6TP1_KoumaJouaniqueDataSet.ChambreRow uneLigne in bD5B6TP1_KoumaJouaniqueDataSet.Chambre.Rows)
                if (uneLigne.NoChambre > noChambreMax) noChambreMax = uneLigne.NoChambre;
            uneChambre.NoChambre = int.Parse(noChambreMax.ToString()) + 1;
            uneChambre.Emplacement = "";
            frmAjouterChambre fAjouterChambre = new frmAjouterChambre();
            fAjouterChambre.uneChambre = uneChambre;
            fAjouterChambre.ShowDialog();
            if (uneChambre.Emplacement != "")
            {
                bD5B6TP1_KoumaJouaniqueDataSet.Chambre.AddChambreRow(uneChambre);
                chambreBindingSource.MoveLast();
                MessageBox.Show("La chambre a été ajoutée avec succès mais pas enrégistré. Pour enregistrer les modification dans la base de données, veuillez cliquer sur le bouton enregistrer.","Confirmation d'ajout",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }

        private void chambreDataGridView_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {
            String strMessagErreur = "";
            String strEmplacement = "";
            String strDecoration = ""; ;
            try
            {
                strEmplacement = chambreDataGridView["dgEmplacement", e.RowIndex].Value.ToString();
                strDecoration = chambreDataGridView["dgDecoration", e.RowIndex].Value.ToString();
            }
            catch
            {

            }
            if (strEmplacement == "")
            {
                strMessagErreur = "L'emplacement ne peut être vide";
                e.Cancel = true;
            }
            else if (strDecoration == "")
            {
                strMessagErreur = "La décoretion ne peut être vide";
                e.Cancel = true;
            }
            chambreDataGridView.Rows[e.RowIndex].ErrorText = strMessagErreur;
        }

        private void btnModifierChambre_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.chambreBindingSource.EndEdit();
            try
            {
                this.tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                MessageBox.Show("Les modifications ont été enrégistré avec succès","Confirmation d'ajout", MessageBoxButtons.OK,MessageBoxIcon.Asterisk);
            }
            catch (DBConcurrencyException erreur)
            {
                //String noPersonne = erreur.Row["dgNoPersonne"].ToString();
                MessageBox.Show("Conflit d'accès concurrentiel","Erreur",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void btnSupprimerChambre_Click(object sender, EventArgs e)
        {
            int nbLigne = reservationChambreDataGridView.Rows.Count;
            /* Boolean bPasSuppr = false;
             String strNoClient = chambreDataGridView.CurrentRow.Cells[0].Value.ToString();
             foreach (DataTable myDataTable in bD5B6TP1_KoumaJouaniqueDataSet.Tables)
             {
                 if (myDataTable.TableName.ToString() != "Chambre" && !bPasSuppr)
                 {
                     foreach (DataRow myDataRow in myDataTable.Rows)
                     {
                         foreach (DataColumn myDataColumn in myDataTable.Columns)
                         {
                             if (myDataColumn.ColumnName.ToString() == "NoChambre" || myDataColumn.ColumnName.ToString() == "NoPersonne" && !bPasSuppr)
                             {
                                 if (myDataRow[myDataColumn].ToString().Equals(strNoClient))
                                 {
                                     bPasSuppr = true;
                                 }
                             }
                         }
                     }

                 }

             }*/
            // MessageBox.Show(nbLigne.ToString());
            if (nbLigne <= 1)
            {
                chambreBindingSource.RemoveCurrent();
            }
            else
            {
                MessageBox.Show("Impossible de supprimer une chambre réservée","Erreur",MessageBoxButtons.OK,MessageBoxIcon.Hand);
            }
        }

        private void frmGestionChambre_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Voulez-vous enregistrer les modifications ?", "Quitter",
    MessageBoxButtons.YesNo, MessageBoxIcon.Question,
    MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.Yes)
            {
                this.Validate();
                this.chambreBindingSource.EndEdit();
                try
                {
                    this.tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                    MessageBox.Show("Les modifications ont été enrégistré avec succès");
                }
                catch (DBConcurrencyException erreur)
                {
                    //String noPersonne = erreur.Row["dgNoPersonne"].ToString();
                    MessageBox.Show("Conflit d'accès concurrentiel");
                }
            }
        }
    }
}
