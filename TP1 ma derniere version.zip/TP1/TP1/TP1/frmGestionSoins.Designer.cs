﻿namespace TP1
{
    partial class frmGestionSoins
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.soinTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.SoinTableAdapter();
            this.soinDataGridView = new System.Windows.Forms.DataGridView();
            this.dgTxtNoSoin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgTxtDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgTxtNoTypeSoin = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.typeSoinsEtDescriptionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dgTxtPrix = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgTxtDuree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.typeSoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.btnSupprSoins = new System.Windows.Forms.Button();
            this.btnAjouterSoins = new System.Windows.Forms.Button();
            this.btnDernierSoins = new System.Windows.Forms.Button();
            this.btnSoinsSuivant = new System.Windows.Forms.Button();
            this.btnSoinsPrecedent = new System.Windows.Forms.Button();
            this.btnPremierSoins = new System.Windows.Forms.Button();
            this.btnModifierSoins = new System.Windows.Forms.Button();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.typeSoinTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TypeSoinTableAdapter();
            this.fKSoinNoTypeSoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.typeSoinsEtDescriptionTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typeSoinsEtDescriptionTableAdapter();
            this.assistantSoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.assistantSoinTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.AssistantSoinTableAdapter();
            this.assistantSoinDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.planifSoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.planifSoinTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PlanifSoinTableAdapter();
            this.planifSoinDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soinDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeSoinsEtDescriptionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeSoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKSoinNoTypeSoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantSoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantSoinDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // soinTableAdapter
            // 
            this.soinTableAdapter.ClearBeforeFill = true;
            // 
            // soinDataGridView
            // 
            this.soinDataGridView.AllowUserToAddRows = false;
            this.soinDataGridView.AutoGenerateColumns = false;
            this.soinDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.soinDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgTxtNoSoin,
            this.dgTxtDescription,
            this.dgTxtNoTypeSoin,
            this.dgTxtPrix,
            this.dgTxtDuree});
            this.soinDataGridView.DataSource = this.soinBindingSource;
            this.soinDataGridView.Location = new System.Drawing.Point(12, 12);
            this.soinDataGridView.Name = "soinDataGridView";
            this.soinDataGridView.Size = new System.Drawing.Size(545, 220);
            this.soinDataGridView.TabIndex = 1;
            this.soinDataGridView.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.soinDataGridView_DataError);
            this.soinDataGridView.RowValidating += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.soinDataGridView_RowValidating);
            // 
            // dgTxtNoSoin
            // 
            this.dgTxtNoSoin.DataPropertyName = "NoSoin";
            this.dgTxtNoSoin.HeaderText = "NoSoin";
            this.dgTxtNoSoin.Name = "dgTxtNoSoin";
            this.dgTxtNoSoin.ReadOnly = true;
            // 
            // dgTxtDescription
            // 
            this.dgTxtDescription.DataPropertyName = "Description";
            this.dgTxtDescription.HeaderText = "Description";
            this.dgTxtDescription.Name = "dgTxtDescription";
            // 
            // dgTxtNoTypeSoin
            // 
            this.dgTxtNoTypeSoin.DataPropertyName = "NoTypeSoin";
            this.dgTxtNoTypeSoin.DataSource = this.typeSoinsEtDescriptionBindingSource;
            this.dgTxtNoTypeSoin.DisplayMember = "TypeSoinEtDescription";
            this.dgTxtNoTypeSoin.HeaderText = "NoTypeSoin";
            this.dgTxtNoTypeSoin.Name = "dgTxtNoTypeSoin";
            this.dgTxtNoTypeSoin.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgTxtNoTypeSoin.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgTxtNoTypeSoin.ValueMember = "No Type Soin";
            // 
            // typeSoinsEtDescriptionBindingSource
            // 
            this.typeSoinsEtDescriptionBindingSource.DataMember = "typeSoinsEtDescription";
            this.typeSoinsEtDescriptionBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // dgTxtPrix
            // 
            this.dgTxtPrix.DataPropertyName = "Prix";
            this.dgTxtPrix.HeaderText = "Prix";
            this.dgTxtPrix.Name = "dgTxtPrix";
            // 
            // dgTxtDuree
            // 
            this.dgTxtDuree.DataPropertyName = "Duree";
            this.dgTxtDuree.HeaderText = "Duree";
            this.dgTxtDuree.Name = "dgTxtDuree";
            this.dgTxtDuree.ReadOnly = true;
            // 
            // soinBindingSource
            // 
            this.soinBindingSource.DataMember = "Soin";
            this.soinBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // typeSoinBindingSource
            // 
            this.typeSoinBindingSource.DataMember = "TypeSoin";
            this.typeSoinBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(164, 267);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(117, 23);
            this.btnAnnuler.TabIndex = 22;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
            // 
            // btnSupprSoins
            // 
            this.btnSupprSoins.Location = new System.Drawing.Point(404, 267);
            this.btnSupprSoins.Name = "btnSupprSoins";
            this.btnSupprSoins.Size = new System.Drawing.Size(107, 23);
            this.btnSupprSoins.TabIndex = 21;
            this.btnSupprSoins.Text = "Supprimer soins";
            this.btnSupprSoins.UseVisualStyleBackColor = true;
            this.btnSupprSoins.Click += new System.EventHandler(this.btnSupprSoins_Click);
            // 
            // btnAjouterSoins
            // 
            this.btnAjouterSoins.Location = new System.Drawing.Point(55, 267);
            this.btnAjouterSoins.Name = "btnAjouterSoins";
            this.btnAjouterSoins.Size = new System.Drawing.Size(103, 23);
            this.btnAjouterSoins.TabIndex = 20;
            this.btnAjouterSoins.Text = "Ajouter soins";
            this.btnAjouterSoins.UseVisualStyleBackColor = true;
            this.btnAjouterSoins.Click += new System.EventHandler(this.btnAjouterSoins_Click);
            // 
            // btnDernierSoins
            // 
            this.btnDernierSoins.Location = new System.Drawing.Point(404, 238);
            this.btnDernierSoins.Name = "btnDernierSoins";
            this.btnDernierSoins.Size = new System.Drawing.Size(107, 23);
            this.btnDernierSoins.TabIndex = 19;
            this.btnDernierSoins.Text = "Dernier soins";
            this.btnDernierSoins.UseVisualStyleBackColor = true;
            this.btnDernierSoins.Click += new System.EventHandler(this.btnDernierSoins_Click);
            // 
            // btnSoinsSuivant
            // 
            this.btnSoinsSuivant.Location = new System.Drawing.Point(287, 238);
            this.btnSoinsSuivant.Name = "btnSoinsSuivant";
            this.btnSoinsSuivant.Size = new System.Drawing.Size(111, 23);
            this.btnSoinsSuivant.TabIndex = 18;
            this.btnSoinsSuivant.Text = "Soins suivant";
            this.btnSoinsSuivant.UseVisualStyleBackColor = true;
            this.btnSoinsSuivant.Click += new System.EventHandler(this.btnSoinsSuivant_Click);
            // 
            // btnSoinsPrecedent
            // 
            this.btnSoinsPrecedent.Location = new System.Drawing.Point(164, 238);
            this.btnSoinsPrecedent.Name = "btnSoinsPrecedent";
            this.btnSoinsPrecedent.Size = new System.Drawing.Size(117, 23);
            this.btnSoinsPrecedent.TabIndex = 17;
            this.btnSoinsPrecedent.Text = "Soins précédent";
            this.btnSoinsPrecedent.UseVisualStyleBackColor = true;
            this.btnSoinsPrecedent.Click += new System.EventHandler(this.btnSoinsPrecedent_Click);
            // 
            // btnPremierSoins
            // 
            this.btnPremierSoins.Location = new System.Drawing.Point(55, 238);
            this.btnPremierSoins.Name = "btnPremierSoins";
            this.btnPremierSoins.Size = new System.Drawing.Size(103, 23);
            this.btnPremierSoins.TabIndex = 16;
            this.btnPremierSoins.Text = "Premier soins";
            this.btnPremierSoins.UseVisualStyleBackColor = true;
            this.btnPremierSoins.Click += new System.EventHandler(this.btnPremierSoins_Click);
            // 
            // btnModifierSoins
            // 
            this.btnModifierSoins.Location = new System.Drawing.Point(288, 266);
            this.btnModifierSoins.Name = "btnModifierSoins";
            this.btnModifierSoins.Size = new System.Drawing.Size(110, 35);
            this.btnModifierSoins.TabIndex = 23;
            this.btnModifierSoins.Text = "Enregistrer modification";
            this.btnModifierSoins.UseVisualStyleBackColor = true;
            this.btnModifierSoins.Click += new System.EventHandler(this.btnModifierSoins_Click);
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.NomClientTableAdapter = null;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.PrenomNomClientTableAdapter = null;
            this.tableAdapterManager.RapportAssistantJourTableAdapter = null;
            this.tableAdapterManager.RapportChambreTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.typchambreEtDescriptionTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.typeSoinsEtDescriptionTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // typeSoinTableAdapter
            // 
            this.typeSoinTableAdapter.ClearBeforeFill = true;
            // 
            // fKSoinNoTypeSoinBindingSource
            // 
            this.fKSoinNoTypeSoinBindingSource.DataMember = "FK_SoinNoTypeSoin";
            this.fKSoinNoTypeSoinBindingSource.DataSource = this.typeSoinBindingSource;
            // 
            // typeSoinsEtDescriptionTableAdapter
            // 
            this.typeSoinsEtDescriptionTableAdapter.ClearBeforeFill = true;
            // 
            // assistantSoinBindingSource
            // 
            this.assistantSoinBindingSource.DataMember = "FK_AssistantSoinNoSoin";
            this.assistantSoinBindingSource.DataSource = this.soinBindingSource;
            // 
            // assistantSoinTableAdapter
            // 
            this.assistantSoinTableAdapter.ClearBeforeFill = true;
            // 
            // assistantSoinDataGridView
            // 
            this.assistantSoinDataGridView.AutoGenerateColumns = false;
            this.assistantSoinDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.assistantSoinDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.assistantSoinDataGridView.DataSource = this.assistantSoinBindingSource;
            this.assistantSoinDataGridView.Location = new System.Drawing.Point(626, 62);
            this.assistantSoinDataGridView.Name = "assistantSoinDataGridView";
            this.assistantSoinDataGridView.Size = new System.Drawing.Size(300, 220);
            this.assistantSoinDataGridView.TabIndex = 23;
            this.assistantSoinDataGridView.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "NoAssistant";
            this.dataGridViewTextBoxColumn1.HeaderText = "NoAssistant";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NoSoin";
            this.dataGridViewTextBoxColumn2.HeaderText = "NoSoin";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // planifSoinBindingSource
            // 
            this.planifSoinBindingSource.DataMember = "FK_PlanifSoinNoSoin";
            this.planifSoinBindingSource.DataSource = this.soinBindingSource;
            // 
            // planifSoinTableAdapter
            // 
            this.planifSoinTableAdapter.ClearBeforeFill = true;
            // 
            // planifSoinDataGridView
            // 
            this.planifSoinDataGridView.AutoGenerateColumns = false;
            this.planifSoinDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.planifSoinDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.planifSoinDataGridView.DataSource = this.planifSoinBindingSource;
            this.planifSoinDataGridView.Location = new System.Drawing.Point(626, 332);
            this.planifSoinDataGridView.Name = "planifSoinDataGridView";
            this.planifSoinDataGridView.Size = new System.Drawing.Size(300, 220);
            this.planifSoinDataGridView.TabIndex = 23;
            this.planifSoinDataGridView.Visible = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "NoPersonne";
            this.dataGridViewTextBoxColumn3.HeaderText = "NoPersonne";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "NoAssistant";
            this.dataGridViewTextBoxColumn4.HeaderText = "NoAssistant";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "DateHeure";
            this.dataGridViewTextBoxColumn5.HeaderText = "DateHeure";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "NoSoin";
            this.dataGridViewTextBoxColumn6.HeaderText = "NoSoin";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // frmGestionSoins
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(575, 315);
            this.Controls.Add(this.planifSoinDataGridView);
            this.Controls.Add(this.assistantSoinDataGridView);
            this.Controls.Add(this.btnModifierSoins);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnSupprSoins);
            this.Controls.Add(this.btnAjouterSoins);
            this.Controls.Add(this.btnDernierSoins);
            this.Controls.Add(this.btnSoinsSuivant);
            this.Controls.Add(this.btnSoinsPrecedent);
            this.Controls.Add(this.btnPremierSoins);
            this.Controls.Add(this.soinDataGridView);
            this.Name = "frmGestionSoins";
            this.Text = "Gestion des Soins";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmGestionSoins_FormClosing);
            this.Load += new System.EventHandler(this.frmGestionSoins_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soinDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeSoinsEtDescriptionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeSoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKSoinNoTypeSoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantSoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantSoinDataGridView)).EndInit();
            //((System.ComponentModel.ISupportInitialize)(this.planifSoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource soinBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.SoinTableAdapter soinTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView soinDataGridView;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.Button btnSupprSoins;
        private System.Windows.Forms.Button btnAjouterSoins;
        private System.Windows.Forms.Button btnDernierSoins;
        private System.Windows.Forms.Button btnSoinsSuivant;
        private System.Windows.Forms.Button btnSoinsPrecedent;
        private System.Windows.Forms.Button btnPremierSoins;
        private System.Windows.Forms.Button btnModifierSoins;
        private System.Windows.Forms.BindingSource typeSoinBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TypeSoinTableAdapter typeSoinTableAdapter;
        private System.Windows.Forms.BindingSource fKSoinNoTypeSoinBindingSource;
        private System.Windows.Forms.BindingSource typeSoinsEtDescriptionBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typeSoinsEtDescriptionTableAdapter typeSoinsEtDescriptionTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgTxtNoSoin;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgTxtDescription;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgTxtNoTypeSoin;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgTxtPrix;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgTxtDuree;
        private System.Windows.Forms.BindingSource assistantSoinBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.AssistantSoinTableAdapter assistantSoinTableAdapter;
        private System.Windows.Forms.DataGridView assistantSoinDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.BindingSource planifSoinBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PlanifSoinTableAdapter planifSoinTableAdapter;
        private System.Windows.Forms.DataGridView planifSoinDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}