﻿namespace TP1
{
    partial class frmPlanificationSoins
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnEnregistrerModification = new System.Windows.Forms.Button();
            this.btnSupprimerReservationSoin = new System.Windows.Forms.Button();
            this.btnAjouterReserVationSoin = new System.Windows.Forms.Button();
            this.planifSoinDataGridView = new System.Windows.Forms.DataGridView();
            this.noPersonneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.noAssistantDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateHeureDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.noSoinDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.planifSoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.planifSoinTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PlanifSoinTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // btnEnregistrerModification
            // 
            this.btnEnregistrerModification.Location = new System.Drawing.Point(151, 373);
            this.btnEnregistrerModification.Name = "btnEnregistrerModification";
            this.btnEnregistrerModification.Size = new System.Drawing.Size(156, 23);
            this.btnEnregistrerModification.TabIndex = 9;
            this.btnEnregistrerModification.Text = "Enregistrer les modifications";
            this.btnEnregistrerModification.UseVisualStyleBackColor = true;
            this.btnEnregistrerModification.Click += new System.EventHandler(this.btnEnregistrerModification_Click_1);
            // 
            // btnSupprimerReservationSoin
            // 
            this.btnSupprimerReservationSoin.Location = new System.Drawing.Point(262, 329);
            this.btnSupprimerReservationSoin.Name = "btnSupprimerReservationSoin";
            this.btnSupprimerReservationSoin.Size = new System.Drawing.Size(194, 23);
            this.btnSupprimerReservationSoin.TabIndex = 8;
            this.btnSupprimerReservationSoin.Text = "Supprimer une réservation de soin";
            this.btnSupprimerReservationSoin.UseVisualStyleBackColor = true;
            this.btnSupprimerReservationSoin.Click += new System.EventHandler(this.btnSupprimerReservationSoin_Click_1);
            // 
            // btnAjouterReserVationSoin
            // 
            this.btnAjouterReserVationSoin.Location = new System.Drawing.Point(12, 329);
            this.btnAjouterReserVationSoin.Name = "btnAjouterReserVationSoin";
            this.btnAjouterReserVationSoin.Size = new System.Drawing.Size(183, 23);
            this.btnAjouterReserVationSoin.TabIndex = 7;
            this.btnAjouterReserVationSoin.Text = "Ajouter une reservation de soins";
            this.btnAjouterReserVationSoin.UseVisualStyleBackColor = true;
            this.btnAjouterReserVationSoin.Click += new System.EventHandler(this.btnAjouterReserVationSoin_Click);
            // 
            // planifSoinDataGridView
            // 
            this.planifSoinDataGridView.AllowUserToAddRows = false;
            this.planifSoinDataGridView.AutoGenerateColumns = false;
            this.planifSoinDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.planifSoinDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.noPersonneDataGridViewTextBoxColumn,
            this.noAssistantDataGridViewTextBoxColumn,
            this.dateHeureDataGridViewTextBoxColumn,
            this.noSoinDataGridViewTextBoxColumn});
            this.planifSoinDataGridView.DataSource = this.planifSoinBindingSource;
            this.planifSoinDataGridView.Location = new System.Drawing.Point(12, 42);
            this.planifSoinDataGridView.Name = "planifSoinDataGridView";
            this.planifSoinDataGridView.Size = new System.Drawing.Size(444, 220);
            this.planifSoinDataGridView.TabIndex = 10;
            // 
            // noPersonneDataGridViewTextBoxColumn
            // 
            this.noPersonneDataGridViewTextBoxColumn.DataPropertyName = "NoPersonne";
            this.noPersonneDataGridViewTextBoxColumn.HeaderText = "NoPersonne";
            this.noPersonneDataGridViewTextBoxColumn.Name = "noPersonneDataGridViewTextBoxColumn";
            // 
            // noAssistantDataGridViewTextBoxColumn
            // 
            this.noAssistantDataGridViewTextBoxColumn.DataPropertyName = "NoAssistant";
            this.noAssistantDataGridViewTextBoxColumn.HeaderText = "NoAssistant";
            this.noAssistantDataGridViewTextBoxColumn.Name = "noAssistantDataGridViewTextBoxColumn";
            // 
            // dateHeureDataGridViewTextBoxColumn
            // 
            this.dateHeureDataGridViewTextBoxColumn.DataPropertyName = "DateHeure";
            this.dateHeureDataGridViewTextBoxColumn.HeaderText = "DateHeure";
            this.dateHeureDataGridViewTextBoxColumn.Name = "dateHeureDataGridViewTextBoxColumn";
            // 
            // noSoinDataGridViewTextBoxColumn
            // 
            this.noSoinDataGridViewTextBoxColumn.DataPropertyName = "NoSoin";
            this.noSoinDataGridViewTextBoxColumn.HeaderText = "NoSoin";
            this.noSoinDataGridViewTextBoxColumn.Name = "noSoinDataGridViewTextBoxColumn";
            // 
            // planifSoinBindingSource
            // 
            this.planifSoinBindingSource.DataMember = "PlanifSoin";
            this.planifSoinBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // planifSoinTableAdapter
            // 
            this.planifSoinTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.NomClientTableAdapter = null;
            this.tableAdapterManager.PlanifSoinTableAdapter = this.planifSoinTableAdapter;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.PrenomNomClientTableAdapter = null;
            this.tableAdapterManager.RapportAssistantJourTableAdapter = null;
            this.tableAdapterManager.RapportChambreTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.typchambreEtDescriptionTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.typeSoinsEtDescriptionTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // frmPlanificationSoins
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 407);
            this.Controls.Add(this.planifSoinDataGridView);
            this.Controls.Add(this.btnEnregistrerModification);
            this.Controls.Add(this.btnSupprimerReservationSoin);
            this.Controls.Add(this.btnAjouterReserVationSoin);
            this.Name = "frmPlanificationSoins";
            this.Text = "Planification de Soins";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPlanificationSoins_FormClosing);
            this.Load += new System.EventHandler(this.frmPlanificationSoins_Load);
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEnregistrerModification;
        private System.Windows.Forms.Button btnSupprimerReservationSoin;
        private System.Windows.Forms.Button btnAjouterReserVationSoin;
        private System.Windows.Forms.DataGridView planifSoinDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn noPersonneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn noAssistantDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateHeureDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn noSoinDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource planifSoinBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PlanifSoinTableAdapter planifSoinTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
    }
}