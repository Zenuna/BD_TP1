﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Globalization;

namespace TP1
{
    public partial class frmGestionSoins : Form
    {
        public String noUtilisateur;
        static String maChaineDeConnexion = "Data Source = sqlinfo.cgodin.qc.ca; Initial Catalog = BD5B6TP1_KoumaJouanique; Persist Security Info=True;User ID = 5B6Kouma;Password=1PetitDioulaBanchi";
        SqlConnection maConnexion = new SqlConnection(maChaineDeConnexion);
        public frmGestionSoins()
        {
            InitializeComponent();
        }

        private void soinBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.soinBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bD5B6TP1_KoumaJouaniqueDataSet);

        }

        private void frmGestionSoins_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.PlanifSoin'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.planifSoinTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.PlanifSoin);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.AssistantSoin'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.assistantSoinTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.AssistantSoin);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.typeSoinsEtDescription'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.typeSoinsEtDescriptionTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.typeSoinsEtDescription);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.TypeSoin'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            //this.typeSoinTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.TypeSoin);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Soin'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.soinTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Soin);

        }

        private void btnPremierSoins_Click(object sender, EventArgs e)
        {
            soinBindingSource.MoveFirst();
        }

        private void btnSoinsPrecedent_Click(object sender, EventArgs e)
        {
            soinBindingSource.MovePrevious();
        }

        private void btnSoinsSuivant_Click(object sender, EventArgs e)
        {
            soinBindingSource.MoveNext();
        }

        private void btnDernierSoins_Click(object sender, EventArgs e)
        {
            soinBindingSource.MoveLast();
        }

        private void btnAjouterSoins_Click(object sender, EventArgs e)
        {

            BD5B6TP1_KoumaJouaniqueDataSet.SoinRow unSoins = bD5B6TP1_KoumaJouaniqueDataSet.Soin.NewSoinRow();

            int noSoinMax = 0;
            foreach (BD5B6TP1_KoumaJouaniqueDataSet.SoinRow uneLigne in bD5B6TP1_KoumaJouaniqueDataSet.Soin.Rows)
            {
                if (uneLigne.NoSoin > noSoinMax) noSoinMax = uneLigne.NoSoin;
            }
            unSoins.NoSoin = noSoinMax + 1;
            unSoins.Description = "";
            frmAjouterSoins fAjouterSoin = new frmAjouterSoins();
            fAjouterSoin.unSoins = unSoins;
            fAjouterSoin.ShowDialog();
            // MessageBox.Show("OKK " + unSoins.NoTypeSoin);
            if (unSoins.Description != "")
            {
                bD5B6TP1_KoumaJouaniqueDataSet.Soin.AddSoinRow(unSoins);
                soinBindingSource.MoveLast();
                MessageBox.Show("Soins ajouté avec succès mais pas enrégistré. Pour enrégistrer ce soins dans la base de données veuillez cliquer sur le bouton enregistrer.","Confirmation de l'ajout");
            }


            /*soinBindingSource.CancelEdit();
            soinBindingSource.AddNew();
            //  BD5B6TP1_KoumaJouaniqueDataSet.SoinRow unSoins = bD5B6TP1_KoumaJouaniqueDataSet.Soin.NewSoinRow();
            maConnexion.Open();
            SqlCommand maCommande = new SqlCommand("SELECT MAX(NoSoin) FROM Soin", maConnexion);
            dynamic NoSoins = maCommande.ExecuteScalar();

            // unSoins.NoSoin = NoSoins + 1;
            maConnexion.Close();
            soinDataGridView.CurrentRow.Cells[0].Value = NoSoins + 1;
            soinDataGridView.CurrentRow.Cells[0].ReadOnly = true;
            soinDataGridView.CurrentRow.Cells[4].Value = 60;
            soinDataGridView.CurrentRow.Cells[4].ReadOnly = true;*/

        }

        private void btnSupprSoins_Click(object sender, EventArgs e)
        {
            Boolean booSupprimer = true;
            foreach (var row in assistantSoinBindingSource)
            {
                booSupprimer = false;
            }
            foreach (var row in planifSoinBindingSource)
            {
                booSupprimer = false;
            }
            if (booSupprimer) soinBindingSource.RemoveCurrent();
            else
            {
                MessageBox.Show("Ce soins ne peut être supprimé, car il est utilisé dans une autre table", "Erreur",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }

        }

        private void soinDataGridView_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {
            char point = Convert.ToChar(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
            var exprDonnee = new Regex("^[0-9]{1,4}(" + point + "[0-9]{2})?$");
            String strPrix = "";
            String strDescription = "";
            try
            {
                strPrix = soinDataGridView["dgTxtPrix", e.RowIndex].Value.ToString();
                strDescription = soinDataGridView["dgTxtDescription", e.RowIndex].Value.ToString();
            }
            catch
            {
              
            }

            String strMessageErreur = "";
            if (strPrix == "")
            {
                strMessageErreur = "Le prix ne peut être vide";
                e.Cancel = true;
            }
            else if (!exprDonnee.IsMatch(strPrix))
            {
                strMessageErreur = "Le prix n'est pas dans un format valide";
                e.Cancel = true;
            }
            else if(strDescription == "")
            {
                strMessageErreur = "La description ne peut être vide";
                e.Cancel = true;
            }

            soinDataGridView.Rows[e.RowIndex].ErrorText = strMessageErreur;
            /*if (soinDataGridView["dgTxtNoUtil", e.RowIndex].Value != null)
            {
                try
                {
                    tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                }
                catch (DBConcurrencyException erreur)
                {
                    MessageBox.Show("Conflit d'accès concurrentiel pour l'utilisateur " + erreur.Row["dgTxtNomUtil"].ToString() + ".Aucun enregistrement possible.", "Conflit d'accès");
                }
                soinDataGridView["dgTxtNomUtil", e.RowIndex].ReadOnly = true;
            }*/
        }

        private void soinDataGridView_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            soinDataGridView.Rows[e.RowIndex].ErrorText = "Le type de données de " + soinDataGridView.Columns[e.ColumnIndex].HeaderText + " n'est pas valide.";
            e.Cancel = true;
        }

        private void btnModifierSoins_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.soinBindingSource.EndEdit();
            try
            {
                this.soinTableAdapter.Update(this.bD5B6TP1_KoumaJouaniqueDataSet);
                MessageBox.Show("Modification enrégistrée dans la base de données", "Confirmation de sauvegarde", MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }
            catch (DBConcurrencyException erreur)
            {
                MessageBox.Show("Conflis d'accès concurrentiel","Erreur",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            bD5B6TP1_KoumaJouaniqueDataSet.RejectChanges();
            soinBindingSource.ResetBindings(false);
            MessageBox.Show("Les modification ont été annulées");
        }

        private void frmGestionSoins_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Vous êtes sur le point de fermer ce formulaire. Voulez-vous l'enregistrer ?", "Fermeture",
    MessageBoxButtons.YesNo, MessageBoxIcon.Question,
    MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.Yes)
            {
                this.Validate();
                this.soinBindingSource.EndEdit();
                try
                {
                    this.soinTableAdapter.Update(this.bD5B6TP1_KoumaJouaniqueDataSet);
                    MessageBox.Show("Modification enrégistrée dans la base de données");
                }
                catch (DBConcurrencyException erreur)
                {
                    MessageBox.Show("Conflis d'accès concurrentiel");
                }
            }
        }
    }
}
