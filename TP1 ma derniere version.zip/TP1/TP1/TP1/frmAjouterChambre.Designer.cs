﻿namespace TP1
{
    partial class frmAjouterChambre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblEmplacement = new System.Windows.Forms.Label();
            this.lblDecoration = new System.Windows.Forms.Label();
            this.lblNoTypeChambre = new System.Windows.Forms.Label();
            this.txtEmplacement = new System.Windows.Forms.TextBox();
            this.txtDecoration = new System.Windows.Forms.TextBox();
            this.cboNoTypeChambre = new System.Windows.Forms.ComboBox();
            this.typeSoinsEtDescriptionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.typeSoinsEtDescriptionTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typeSoinsEtDescriptionTableAdapter();
            this.btnAjouter = new System.Windows.Forms.Button();
            this.btnFermer = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.errMessage = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.typeSoinsEtDescriptionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMessage)).BeginInit();
            this.SuspendLayout();
            // 
            // lblEmplacement
            // 
            this.lblEmplacement.AutoSize = true;
            this.lblEmplacement.Location = new System.Drawing.Point(22, 73);
            this.lblEmplacement.Name = "lblEmplacement";
            this.lblEmplacement.Size = new System.Drawing.Size(71, 13);
            this.lblEmplacement.TabIndex = 1;
            this.lblEmplacement.Text = "Emplacement";
            // 
            // lblDecoration
            // 
            this.lblDecoration.AutoSize = true;
            this.lblDecoration.Location = new System.Drawing.Point(22, 109);
            this.lblDecoration.Name = "lblDecoration";
            this.lblDecoration.Size = new System.Drawing.Size(59, 13);
            this.lblDecoration.TabIndex = 2;
            this.lblDecoration.Text = "Decoration";
            // 
            // lblNoTypeChambre
            // 
            this.lblNoTypeChambre.AutoSize = true;
            this.lblNoTypeChambre.Location = new System.Drawing.Point(22, 147);
            this.lblNoTypeChambre.Name = "lblNoTypeChambre";
            this.lblNoTypeChambre.Size = new System.Drawing.Size(103, 13);
            this.lblNoTypeChambre.TabIndex = 3;
            this.lblNoTypeChambre.Text = "No type de chambre";
            // 
            // txtEmplacement
            // 
            this.txtEmplacement.Location = new System.Drawing.Point(170, 70);
            this.txtEmplacement.Name = "txtEmplacement";
            this.txtEmplacement.Size = new System.Drawing.Size(100, 20);
            this.txtEmplacement.TabIndex = 5;
            // 
            // txtDecoration
            // 
            this.txtDecoration.Location = new System.Drawing.Point(170, 106);
            this.txtDecoration.Name = "txtDecoration";
            this.txtDecoration.Size = new System.Drawing.Size(100, 20);
            this.txtDecoration.TabIndex = 6;
            // 
            // cboNoTypeChambre
            // 
            this.cboNoTypeChambre.DataSource = this.typeSoinsEtDescriptionBindingSource;
            this.cboNoTypeChambre.DisplayMember = "TypeSoinEtDescription";
            this.cboNoTypeChambre.FormattingEnabled = true;
            this.cboNoTypeChambre.Location = new System.Drawing.Point(170, 144);
            this.cboNoTypeChambre.Name = "cboNoTypeChambre";
            this.cboNoTypeChambre.Size = new System.Drawing.Size(121, 21);
            this.cboNoTypeChambre.TabIndex = 7;
            this.cboNoTypeChambre.ValueMember = "No Type Soin";
            // 
            // typeSoinsEtDescriptionBindingSource
            // 
            this.typeSoinsEtDescriptionBindingSource.DataMember = "typeSoinsEtDescription";
            this.typeSoinsEtDescriptionBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // typeSoinsEtDescriptionTableAdapter
            // 
            this.typeSoinsEtDescriptionTableAdapter.ClearBeforeFill = true;
            // 
            // btnAjouter
            // 
            this.btnAjouter.Location = new System.Drawing.Point(308, 68);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(75, 23);
            this.btnAjouter.TabIndex = 8;
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.UseVisualStyleBackColor = true;
            this.btnAjouter.Click += new System.EventHandler(this.btnAjouter_Click);
            // 
            // btnFermer
            // 
            this.btnFermer.Location = new System.Drawing.Point(308, 107);
            this.btnFermer.Name = "btnFermer";
            this.btnFermer.Size = new System.Drawing.Size(75, 23);
            this.btnFermer.TabIndex = 9;
            this.btnFermer.Text = "Fermer";
            this.btnFermer.UseVisualStyleBackColor = true;
            this.btnFermer.Click += new System.EventHandler(this.btnFermer_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(125, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 24);
            this.label1.TabIndex = 10;
            this.label1.Text = "Ajouter Chambre";
            // 
            // errMessage
            // 
            this.errMessage.ContainerControl = this;
            // 
            // frmAjouterChambre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 226);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnFermer);
            this.Controls.Add(this.btnAjouter);
            this.Controls.Add(this.cboNoTypeChambre);
            this.Controls.Add(this.txtDecoration);
            this.Controls.Add(this.txtEmplacement);
            this.Controls.Add(this.lblNoTypeChambre);
            this.Controls.Add(this.lblDecoration);
            this.Controls.Add(this.lblEmplacement);
            this.Name = "frmAjouterChambre";
            this.Text = "Ajouter une chambre";
            this.Load += new System.EventHandler(this.frmAjouterChambre_Load);
            ((System.ComponentModel.ISupportInitialize)(this.typeSoinsEtDescriptionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMessage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblEmplacement;
        private System.Windows.Forms.Label lblDecoration;
        private System.Windows.Forms.Label lblNoTypeChambre;
        private System.Windows.Forms.TextBox txtEmplacement;
        private System.Windows.Forms.TextBox txtDecoration;
        private System.Windows.Forms.ComboBox cboNoTypeChambre;
        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource typeSoinsEtDescriptionBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typeSoinsEtDescriptionTableAdapter typeSoinsEtDescriptionTableAdapter;
        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.Button btnFermer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ErrorProvider errMessage;
    }
}