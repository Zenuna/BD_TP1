﻿namespace TP1
{
    partial class frmRapportSoinsAssistant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nomCompletLabel;
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.rapportSoinsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rapportSoinsTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.rapportSoinsTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.rapportAssistantJourBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rapportAssistantJourTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.RapportAssistantJourTableAdapter();
            this.nomCompletComboBox = new System.Windows.Forms.ComboBox();
            this.rapportSoinsJournalierBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rapportSoinsJournalierTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.RapportSoinsJournalierTableAdapter();
            this.DateSoin = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.prenomNomAssistantBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.prenomNomAssistantTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PrenomNomAssistantTableAdapter();
            this.rapportSoinsJournalierBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.rapportSoinsJournalierDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            nomCompletLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportSoinsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportAssistantJourBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportSoinsJournalierBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prenomNomAssistantBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportSoinsJournalierBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportSoinsJournalierDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // nomCompletLabel
            // 
            nomCompletLabel.AutoSize = true;
            nomCompletLabel.Location = new System.Drawing.Point(12, 31);
            nomCompletLabel.Name = "nomCompletLabel";
            nomCompletLabel.Size = new System.Drawing.Size(73, 13);
            nomCompletLabel.TabIndex = 0;
            nomCompletLabel.Text = "Nom Complet:";
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rapportSoinsBindingSource
            // 
            this.rapportSoinsBindingSource.DataMember = "rapportSoins";
            this.rapportSoinsBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // rapportSoinsTableAdapter
            // 
            this.rapportSoinsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.PrenomNomClientTableAdapter = null;
            this.tableAdapterManager.RapportAssistantJourTableAdapter = null;
            this.tableAdapterManager.RapportChambreTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // rapportAssistantJourBindingSource
            // 
            this.rapportAssistantJourBindingSource.DataMember = "RapportAssistantJour";
            this.rapportAssistantJourBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // rapportAssistantJourTableAdapter
            // 
            this.rapportAssistantJourTableAdapter.ClearBeforeFill = true;
            // 
            // nomCompletComboBox
            // 
            this.nomCompletComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rapportAssistantJourBindingSource, "NomComplet", true));
            this.nomCompletComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.prenomNomAssistantBindingSource, "NoAssistant", true));
            this.nomCompletComboBox.DataSource = this.prenomNomAssistantBindingSource;
            this.nomCompletComboBox.DisplayMember = "NomComplet";
            this.nomCompletComboBox.FormattingEnabled = true;
            this.nomCompletComboBox.Location = new System.Drawing.Point(91, 28);
            this.nomCompletComboBox.Name = "nomCompletComboBox";
            this.nomCompletComboBox.Size = new System.Drawing.Size(245, 21);
            this.nomCompletComboBox.TabIndex = 1;
            this.nomCompletComboBox.ValueMember = "NoAssistant";
            // 
            // rapportSoinsJournalierBindingSource
            // 
            this.rapportSoinsJournalierBindingSource.DataMember = "FK_PlanifSoinNoAssistant2";
            this.rapportSoinsJournalierBindingSource.DataSource = this.rapportAssistantJourBindingSource;
            // 
            // rapportSoinsJournalierTableAdapter
            // 
            this.rapportSoinsJournalierTableAdapter.ClearBeforeFill = true;
            // 
            // DateSoin
            // 
            this.DateSoin.Location = new System.Drawing.Point(91, 76);
            this.DateSoin.Name = "DateSoin";
            this.DateSoin.Size = new System.Drawing.Size(245, 20);
            this.DateSoin.TabIndex = 4;
            this.DateSoin.ValueChanged += new System.EventHandler(this.DateSoin_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Date: ";
            // 
            // prenomNomAssistantBindingSource
            // 
            this.prenomNomAssistantBindingSource.DataMember = "PrenomNomAssistant";
            this.prenomNomAssistantBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // prenomNomAssistantTableAdapter
            // 
            this.prenomNomAssistantTableAdapter.ClearBeforeFill = true;
            // 
            // rapportSoinsJournalierBindingSource1
            // 
            this.rapportSoinsJournalierBindingSource1.DataMember = "FK_PlanifSoinNoAssistant5";
            this.rapportSoinsJournalierBindingSource1.DataSource = this.prenomNomAssistantBindingSource;
            // 
            // rapportSoinsJournalierDataGridView
            // 
            this.rapportSoinsJournalierDataGridView.AllowUserToAddRows = false;
            this.rapportSoinsJournalierDataGridView.AllowUserToDeleteRows = false;
            this.rapportSoinsJournalierDataGridView.AutoGenerateColumns = false;
            this.rapportSoinsJournalierDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rapportSoinsJournalierDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rapportSoinsJournalierDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn6});
            this.rapportSoinsJournalierDataGridView.DataSource = this.rapportSoinsJournalierBindingSource1;
            this.rapportSoinsJournalierDataGridView.Location = new System.Drawing.Point(342, 28);
            this.rapportSoinsJournalierDataGridView.Name = "rapportSoinsJournalierDataGridView";
            this.rapportSoinsJournalierDataGridView.ReadOnly = true;
            this.rapportSoinsJournalierDataGridView.Size = new System.Drawing.Size(446, 220);
            this.rapportSoinsJournalierDataGridView.TabIndex = 6;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Description";
            this.dataGridViewTextBoxColumn2.HeaderText = "Description";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "DateHeure";
            this.dataGridViewTextBoxColumn3.HeaderText = "Date-Heure du soin";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "NOM";
            this.dataGridViewTextBoxColumn6.HeaderText = "Nom du receveur";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // frmRapportSoinsAssistant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 272);
            this.Controls.Add(this.rapportSoinsJournalierDataGridView);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DateSoin);
            this.Controls.Add(nomCompletLabel);
            this.Controls.Add(this.nomCompletComboBox);
            this.Name = "frmRapportSoinsAssistant";
            this.Text = "Rapport des soins journaliers des assistants";
            this.Load += new System.EventHandler(this.frmRapportSoinsAssistant_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportSoinsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportAssistantJourBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportSoinsJournalierBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prenomNomAssistantBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportSoinsJournalierBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportSoinsJournalierDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource rapportSoinsBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.rapportSoinsTableAdapter rapportSoinsTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingSource rapportAssistantJourBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.RapportAssistantJourTableAdapter rapportAssistantJourTableAdapter;
        private System.Windows.Forms.ComboBox nomCompletComboBox;
        private System.Windows.Forms.BindingSource rapportSoinsJournalierBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.RapportSoinsJournalierTableAdapter rapportSoinsJournalierTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DateTimePicker DateSoin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource prenomNomAssistantBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PrenomNomAssistantTableAdapter prenomNomAssistantTableAdapter;
        private System.Windows.Forms.BindingSource rapportSoinsJournalierBindingSource1;
        private System.Windows.Forms.DataGridView rapportSoinsJournalierDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}