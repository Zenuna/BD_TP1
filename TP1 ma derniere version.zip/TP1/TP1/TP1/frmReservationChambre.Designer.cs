﻿namespace TP1
{
    partial class frmReservationChambre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.reservationChambreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reservationChambreTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ReservationChambreTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.reservationChambreDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSupprimerReservationChambre = new System.Windows.Forms.Button();
            this.btnModifierReservationChambre = new System.Windows.Forms.Button();
            this.btnAjouterReservationChambre = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservationChambreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservationChambreDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reservationChambreBindingSource
            // 
            this.reservationChambreBindingSource.DataMember = "ReservationChambre";
            this.reservationChambreBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // reservationChambreTableAdapter
            // 
            this.reservationChambreTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.NomClientTableAdapter = null;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.PrenomNomClientTableAdapter = null;
            this.tableAdapterManager.RapportAssistantJourTableAdapter = null;
            this.tableAdapterManager.RapportChambreTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = this.reservationChambreTableAdapter;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.typchambreEtDescriptionTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.typeSoinsEtDescriptionTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // reservationChambreDataGridView
            // 
            this.reservationChambreDataGridView.AllowUserToAddRows = false;
            this.reservationChambreDataGridView.AutoGenerateColumns = false;
            this.reservationChambreDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reservationChambreDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.reservationChambreDataGridView.DataSource = this.reservationChambreBindingSource;
            this.reservationChambreDataGridView.Location = new System.Drawing.Point(12, 12);
            this.reservationChambreDataGridView.Name = "reservationChambreDataGridView";
            this.reservationChambreDataGridView.Size = new System.Drawing.Size(547, 220);
            this.reservationChambreDataGridView.TabIndex = 1;
            this.reservationChambreDataGridView.RowValidating += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.reservationChambreDataGridView_RowValidating);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "NoClient";
            this.dataGridViewTextBoxColumn1.HeaderText = "NoClient";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NoChambre";
            this.dataGridViewTextBoxColumn2.HeaderText = "NoChambre";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "DateArrivee";
            this.dataGridViewTextBoxColumn3.HeaderText = "DateArrivee";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "DateDepart";
            this.dataGridViewTextBoxColumn4.HeaderText = "DateDepart";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "NbPersonnes";
            this.dataGridViewTextBoxColumn5.HeaderText = "NbPersonnes";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // btnSupprimerReservationChambre
            // 
            this.btnSupprimerReservationChambre.Location = new System.Drawing.Point(312, 254);
            this.btnSupprimerReservationChambre.Name = "btnSupprimerReservationChambre";
            this.btnSupprimerReservationChambre.Size = new System.Drawing.Size(104, 48);
            this.btnSupprimerReservationChambre.TabIndex = 8;
            this.btnSupprimerReservationChambre.Text = "Supprimer une Reservation de chambre";
            this.btnSupprimerReservationChambre.UseVisualStyleBackColor = true;
            this.btnSupprimerReservationChambre.Click += new System.EventHandler(this.btnSupprimerReservationChambre_Click);
            // 
            // btnModifierReservationChambre
            // 
            this.btnModifierReservationChambre.Location = new System.Drawing.Point(187, 254);
            this.btnModifierReservationChambre.Name = "btnModifierReservationChambre";
            this.btnModifierReservationChambre.Size = new System.Drawing.Size(104, 48);
            this.btnModifierReservationChambre.TabIndex = 7;
            this.btnModifierReservationChambre.Text = "Enrégistrer les modifications";
            this.btnModifierReservationChambre.UseVisualStyleBackColor = true;
            this.btnModifierReservationChambre.Click += new System.EventHandler(this.btnModifierReservationChambre_Click);
            // 
            // btnAjouterReservationChambre
            // 
            this.btnAjouterReservationChambre.Location = new System.Drawing.Point(68, 254);
            this.btnAjouterReservationChambre.Name = "btnAjouterReservationChambre";
            this.btnAjouterReservationChambre.Size = new System.Drawing.Size(104, 48);
            this.btnAjouterReservationChambre.TabIndex = 6;
            this.btnAjouterReservationChambre.Text = "Ajouter une Reservation de chambre";
            this.btnAjouterReservationChambre.UseVisualStyleBackColor = true;
            this.btnAjouterReservationChambre.Click += new System.EventHandler(this.btnAjouterReservationChambre_Click);
            // 
            // frmReservationChambre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 325);
            this.Controls.Add(this.btnSupprimerReservationChambre);
            this.Controls.Add(this.btnModifierReservationChambre);
            this.Controls.Add(this.btnAjouterReservationChambre);
            this.Controls.Add(this.reservationChambreDataGridView);
            this.Name = "frmReservationChambre";
            this.Text = "Reservation de Chambre";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmReservationChambre_FormClosing);
            this.Load += new System.EventHandler(this.frmReservationChambre_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservationChambreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservationChambreDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource reservationChambreBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ReservationChambreTableAdapter reservationChambreTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView reservationChambreDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.Button btnSupprimerReservationChambre;
        private System.Windows.Forms.Button btnModifierReservationChambre;
        private System.Windows.Forms.Button btnAjouterReservationChambre;
    }
}