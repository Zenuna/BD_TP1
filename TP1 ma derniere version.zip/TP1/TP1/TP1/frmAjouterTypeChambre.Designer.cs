﻿namespace TP1
{
    partial class frmAjouterTypeChambre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.btnFermer = new System.Windows.Forms.Button();
            this.btnAjouter = new System.Windows.Forms.Button();
            this.txtPrixHaut = new System.Windows.Forms.TextBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblPrixBas = new System.Windows.Forms.Label();
            this.lblPrixHaut = new System.Windows.Forms.Label();
            this.lblDescriptionTypeChambre = new System.Windows.Forms.Label();
            this.lblPrixMoyen = new System.Windows.Forms.Label();
            this.txtPrixMoyen = new System.Windows.Forms.TextBox();
            this.txtPrixBas = new System.Windows.Forms.TextBox();
            this.errMessage = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errMessage)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(273, 24);
            this.label1.TabIndex = 19;
            this.label1.Text = "Ajouter un type de Chambre";
            // 
            // btnFermer
            // 
            this.btnFermer.Location = new System.Drawing.Point(299, 116);
            this.btnFermer.Name = "btnFermer";
            this.btnFermer.Size = new System.Drawing.Size(75, 23);
            this.btnFermer.TabIndex = 18;
            this.btnFermer.Text = "Fermer";
            this.btnFermer.UseVisualStyleBackColor = true;
            this.btnFermer.Click += new System.EventHandler(this.btnFermer_Click);
            // 
            // btnAjouter
            // 
            this.btnAjouter.Location = new System.Drawing.Point(299, 77);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(75, 23);
            this.btnAjouter.TabIndex = 17;
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.UseVisualStyleBackColor = true;
            this.btnAjouter.Click += new System.EventHandler(this.btnAjouter_Click);
            // 
            // txtPrixHaut
            // 
            this.txtPrixHaut.Location = new System.Drawing.Point(161, 115);
            this.txtPrixHaut.Name = "txtPrixHaut";
            this.txtPrixHaut.Size = new System.Drawing.Size(100, 20);
            this.txtPrixHaut.TabIndex = 15;
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(161, 79);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(100, 20);
            this.txtDescription.TabIndex = 14;
            // 
            // lblPrixBas
            // 
            this.lblPrixBas.AutoSize = true;
            this.lblPrixBas.Location = new System.Drawing.Point(13, 156);
            this.lblPrixBas.Name = "lblPrixBas";
            this.lblPrixBas.Size = new System.Drawing.Size(44, 13);
            this.lblPrixBas.TabIndex = 13;
            this.lblPrixBas.Text = "Prix bas";
            // 
            // lblPrixHaut
            // 
            this.lblPrixHaut.AutoSize = true;
            this.lblPrixHaut.Location = new System.Drawing.Point(13, 118);
            this.lblPrixHaut.Name = "lblPrixHaut";
            this.lblPrixHaut.Size = new System.Drawing.Size(48, 13);
            this.lblPrixHaut.TabIndex = 12;
            this.lblPrixHaut.Text = "Prix haut";
            // 
            // lblDescriptionTypeChambre
            // 
            this.lblDescriptionTypeChambre.AutoSize = true;
            this.lblDescriptionTypeChambre.Location = new System.Drawing.Point(13, 82);
            this.lblDescriptionTypeChambre.Name = "lblDescriptionTypeChambre";
            this.lblDescriptionTypeChambre.Size = new System.Drawing.Size(60, 13);
            this.lblDescriptionTypeChambre.TabIndex = 11;
            this.lblDescriptionTypeChambre.Text = "Description";
            // 
            // lblPrixMoyen
            // 
            this.lblPrixMoyen.AutoSize = true;
            this.lblPrixMoyen.Location = new System.Drawing.Point(13, 192);
            this.lblPrixMoyen.Name = "lblPrixMoyen";
            this.lblPrixMoyen.Size = new System.Drawing.Size(58, 13);
            this.lblPrixMoyen.TabIndex = 20;
            this.lblPrixMoyen.Text = "Prix moyen";
            // 
            // txtPrixMoyen
            // 
            this.txtPrixMoyen.Location = new System.Drawing.Point(161, 185);
            this.txtPrixMoyen.Name = "txtPrixMoyen";
            this.txtPrixMoyen.Size = new System.Drawing.Size(100, 20);
            this.txtPrixMoyen.TabIndex = 21;
            // 
            // txtPrixBas
            // 
            this.txtPrixBas.Location = new System.Drawing.Point(161, 148);
            this.txtPrixBas.Name = "txtPrixBas";
            this.txtPrixBas.Size = new System.Drawing.Size(100, 20);
            this.txtPrixBas.TabIndex = 22;
            // 
            // errMessage
            // 
            this.errMessage.ContainerControl = this;
            // 
            // frmAjouterTypeChambre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(394, 224);
            this.Controls.Add(this.txtPrixBas);
            this.Controls.Add(this.txtPrixMoyen);
            this.Controls.Add(this.lblPrixMoyen);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnFermer);
            this.Controls.Add(this.btnAjouter);
            this.Controls.Add(this.txtPrixHaut);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.lblPrixBas);
            this.Controls.Add(this.lblPrixHaut);
            this.Controls.Add(this.lblDescriptionTypeChambre);
            this.Name = "frmAjouterTypeChambre";
            this.Text = "Ajouter un Type de Chambre";
            ((System.ComponentModel.ISupportInitialize)(this.errMessage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnFermer;
        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.TextBox txtPrixHaut;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label lblPrixBas;
        private System.Windows.Forms.Label lblPrixHaut;
        private System.Windows.Forms.Label lblDescriptionTypeChambre;
        private System.Windows.Forms.Label lblPrixMoyen;
        private System.Windows.Forms.TextBox txtPrixMoyen;
        private System.Windows.Forms.TextBox txtPrixBas;
        private System.Windows.Forms.ErrorProvider errMessage;
    }
}