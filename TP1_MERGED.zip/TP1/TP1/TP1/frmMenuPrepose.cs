﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmMenuPrepose : Form
    {
        public frmMenuPrepose()
        {
            InitializeComponent();
        }

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            bD5B6TP1_KoumaJouaniqueDataSet.Utilisateur.WriteXml("Utilisateur.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.Client.WriteXml("Client.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.Invite.WriteXml("Invite.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.Assistant.WriteXml("Assistant.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.AssistantSoin.WriteXml("AssistantSoin.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.Soin.WriteXml("Soin.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.PlanifSoin.WriteXml("PlanifSoin.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.Chambre.WriteXml("Chambre.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.TypeChambre.WriteXml("TypeChambre.xml");
            bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre.WriteXml("ReservationCHambre.xml");
            Environment.Exit(1);

        }

        private void btnDeconnexion_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGererClientEtInvite_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMenuGestionClientInvite fMenuGestionClientInvite = new frmMenuGestionClientInvite();
            fMenuGestionClientInvite.ShowDialog();
            this.Show();
        }

        private void btnPlanifierSoinsClientEtInvite_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmPlanificationSoins fPlanificationSoin = new frmPlanificationSoins();
            fPlanificationSoin.ShowDialog();
            this.Show();
        }

        private void btnReserverChambre_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmReservationChambre fReservationChambre = new frmReservationChambre();
            fReservationChambre.ShowDialog();
            this.Show();
        }


        private void frmMenuPrepose_Load(object sender, EventArgs e)
        {

        }
    }
}
