﻿namespace TP1
{
    partial class frmRapportChambre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label chambreLabel;
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.rapportChambreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rapportChambreTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.RapportChambreTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.chambreComboBox = new System.Windows.Forms.ComboBox();
            this.rapportReservationChambreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rapportReservationChambreTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.RapportReservationChambreTableAdapter();
            this.rapportReservationChambreDataGridView = new System.Windows.Forms.DataGridView();
            this.rapportReservationChambreBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.nomCompletDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateArriveDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDepartDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nbPersonnesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            chambreLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportChambreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportReservationChambreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportReservationChambreDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportReservationChambreBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // chambreLabel
            // 
            chambreLabel.AutoSize = true;
            chambreLabel.Location = new System.Drawing.Point(12, 15);
            chambreLabel.Name = "chambreLabel";
            chambreLabel.Size = new System.Drawing.Size(52, 13);
            chambreLabel.TabIndex = 1;
            chambreLabel.Text = "Chambre:";
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rapportChambreBindingSource
            // 
            this.rapportChambreBindingSource.DataMember = "RapportChambre";
            this.rapportChambreBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // rapportChambreTableAdapter
            // 
            this.rapportChambreTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.PrenomNomClientTableAdapter = null;
            this.tableAdapterManager.RapportAssistantJourTableAdapter = null;
            this.tableAdapterManager.RapportChambreTableAdapter = this.rapportChambreTableAdapter;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // chambreComboBox
            // 
            this.chambreComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rapportChambreBindingSource, "Chambre", true));
            this.chambreComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.rapportChambreBindingSource, "Chambre", true));
            this.chambreComboBox.DataSource = this.rapportChambreBindingSource;
            this.chambreComboBox.DisplayMember = "Chambre";
            this.chambreComboBox.FormattingEnabled = true;
            this.chambreComboBox.Location = new System.Drawing.Point(70, 12);
            this.chambreComboBox.Name = "chambreComboBox";
            this.chambreComboBox.Size = new System.Drawing.Size(121, 21);
            this.chambreComboBox.TabIndex = 2;
            this.chambreComboBox.ValueMember = "NoChambre";
            // 
            // rapportReservationChambreBindingSource
            // 
            this.rapportReservationChambreBindingSource.DataMember = "FK_NoChambre3";
            this.rapportReservationChambreBindingSource.DataSource = this.rapportChambreBindingSource;
            // 
            // rapportReservationChambreTableAdapter
            // 
            this.rapportReservationChambreTableAdapter.ClearBeforeFill = true;
            // 
            // rapportReservationChambreDataGridView
            // 
            this.rapportReservationChambreDataGridView.AllowUserToAddRows = false;
            this.rapportReservationChambreDataGridView.AllowUserToDeleteRows = false;
            this.rapportReservationChambreDataGridView.AutoGenerateColumns = false;
            this.rapportReservationChambreDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rapportReservationChambreDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rapportReservationChambreDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nomCompletDataGridViewTextBoxColumn,
            this.dateArriveDataGridViewTextBoxColumn,
            this.dateDepartDataGridViewTextBoxColumn,
            this.nbPersonnesDataGridViewTextBoxColumn});
            this.rapportReservationChambreDataGridView.DataSource = this.rapportReservationChambreBindingSource1;
            this.rapportReservationChambreDataGridView.Location = new System.Drawing.Point(197, 12);
            this.rapportReservationChambreDataGridView.Name = "rapportReservationChambreDataGridView";
            this.rapportReservationChambreDataGridView.ReadOnly = true;
            this.rapportReservationChambreDataGridView.Size = new System.Drawing.Size(451, 220);
            this.rapportReservationChambreDataGridView.TabIndex = 2;
            // 
            // rapportReservationChambreBindingSource1
            // 
            this.rapportReservationChambreBindingSource1.DataMember = "FK_NoChambre1";
            this.rapportReservationChambreBindingSource1.DataSource = this.rapportChambreBindingSource;
            // 
            // nomCompletDataGridViewTextBoxColumn
            // 
            this.nomCompletDataGridViewTextBoxColumn.DataPropertyName = "NomComplet";
            this.nomCompletDataGridViewTextBoxColumn.HeaderText = "Nom complet";
            this.nomCompletDataGridViewTextBoxColumn.Name = "nomCompletDataGridViewTextBoxColumn";
            this.nomCompletDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dateArriveDataGridViewTextBoxColumn
            // 
            this.dateArriveDataGridViewTextBoxColumn.DataPropertyName = "DateArrive";
            this.dateArriveDataGridViewTextBoxColumn.HeaderText = "Date d\'arrivée";
            this.dateArriveDataGridViewTextBoxColumn.Name = "dateArriveDataGridViewTextBoxColumn";
            this.dateArriveDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dateDepartDataGridViewTextBoxColumn
            // 
            this.dateDepartDataGridViewTextBoxColumn.DataPropertyName = "DateDepart";
            this.dateDepartDataGridViewTextBoxColumn.HeaderText = "Date de départ";
            this.dateDepartDataGridViewTextBoxColumn.Name = "dateDepartDataGridViewTextBoxColumn";
            this.dateDepartDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nbPersonnesDataGridViewTextBoxColumn
            // 
            this.nbPersonnesDataGridViewTextBoxColumn.DataPropertyName = "NbPersonnes";
            this.nbPersonnesDataGridViewTextBoxColumn.HeaderText = "Nombre de personnes";
            this.nbPersonnesDataGridViewTextBoxColumn.Name = "nbPersonnesDataGridViewTextBoxColumn";
            this.nbPersonnesDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // frmRapportChambre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 260);
            this.Controls.Add(this.rapportReservationChambreDataGridView);
            this.Controls.Add(chambreLabel);
            this.Controls.Add(this.chambreComboBox);
            this.Name = "frmRapportChambre";
            this.Text = "Rapport des réservations de chambres";
            this.Load += new System.EventHandler(this.frmRapportChambre_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportChambreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportReservationChambreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportReservationChambreDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportReservationChambreBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource rapportChambreBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.RapportChambreTableAdapter rapportChambreTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ComboBox chambreComboBox;
        private System.Windows.Forms.BindingSource rapportReservationChambreBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.RapportReservationChambreTableAdapter rapportReservationChambreTableAdapter;
        private System.Windows.Forms.DataGridView rapportReservationChambreDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.BindingSource rapportReservationChambreBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomCompletDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateArriveDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDepartDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nbPersonnesDataGridViewTextBoxColumn;
    }
}