﻿namespace TP1
{
    partial class frmAjouterSoins
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnFermer = new System.Windows.Forms.Button();
            this.btnAjouter = new System.Windows.Forms.Button();
            this.cboNoTypeSoin = new System.Windows.Forms.ComboBox();
            this.typeSoinsEtDescriptionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.typeUtilisateurBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtPrix = new System.Windows.Forms.TextBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lbNoTypeSoin = new System.Windows.Forms.Label();
            this.lblPrix = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.typeUtilisateurTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typeUtilisateurTableAdapter();
            this.typeSoinsEtDescriptionTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typeSoinsEtDescriptionTableAdapter();
            this.errMessage = new System.Windows.Forms.ErrorProvider(this.components);
            this.bD5B6TP1_KoumaJouaniqueDataSet1 = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.typeSoinsEtDescriptionBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.typeSoinsEtDescriptionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeUtilisateurBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMessage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeSoinsEtDescriptionBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnFermer
            // 
            this.btnFermer.Location = new System.Drawing.Point(311, 80);
            this.btnFermer.Name = "btnFermer";
            this.btnFermer.Size = new System.Drawing.Size(75, 23);
            this.btnFermer.TabIndex = 23;
            this.btnFermer.Text = "Fermer";
            this.btnFermer.UseVisualStyleBackColor = true;
            this.btnFermer.Click += new System.EventHandler(this.btnFermer_Click);
            // 
            // btnAjouter
            // 
            this.btnAjouter.Location = new System.Drawing.Point(311, 37);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(75, 23);
            this.btnAjouter.TabIndex = 22;
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.UseVisualStyleBackColor = true;
            this.btnAjouter.Click += new System.EventHandler(this.btnAjouter_Click);
            // 
            // cboNoTypeSoin
            // 
            this.cboNoTypeSoin.DataSource = this.typeSoinsEtDescriptionBindingSource1;
            this.cboNoTypeSoin.DisplayMember = "TypeSoinEtDescription";
            this.cboNoTypeSoin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNoTypeSoin.FormattingEnabled = true;
            this.cboNoTypeSoin.Location = new System.Drawing.Point(156, 121);
            this.cboNoTypeSoin.Name = "cboNoTypeSoin";
            this.cboNoTypeSoin.Size = new System.Drawing.Size(230, 21);
            this.cboNoTypeSoin.TabIndex = 21;
            this.cboNoTypeSoin.ValueMember = "No Type Soin";
            // 
            // typeSoinsEtDescriptionBindingSource
            // 
            this.typeSoinsEtDescriptionBindingSource.DataMember = "typeSoinsEtDescription";
            this.typeSoinsEtDescriptionBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // typeUtilisateurBindingSource
            // 
            this.typeUtilisateurBindingSource.DataMember = "typeUtilisateur";
            this.typeUtilisateurBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // txtPrix
            // 
            this.txtPrix.Location = new System.Drawing.Point(156, 82);
            this.txtPrix.Name = "txtPrix";
            this.txtPrix.Size = new System.Drawing.Size(121, 20);
            this.txtPrix.TabIndex = 18;
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(156, 39);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(121, 20);
            this.txtDescription.TabIndex = 17;
            // 
            // lbNoTypeSoin
            // 
            this.lbNoTypeSoin.AutoSize = true;
            this.lbNoTypeSoin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNoTypeSoin.Location = new System.Drawing.Point(35, 121);
            this.lbNoTypeSoin.Name = "lbNoTypeSoin";
            this.lbNoTypeSoin.Size = new System.Drawing.Size(107, 16);
            this.lbNoTypeSoin.TabIndex = 16;
            this.lbNoTypeSoin.Text = "No Type Soin:";
            // 
            // lblPrix
            // 
            this.lblPrix.AutoSize = true;
            this.lblPrix.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrix.Location = new System.Drawing.Point(35, 82);
            this.lblPrix.Name = "lblPrix";
            this.lblPrix.Size = new System.Drawing.Size(38, 16);
            this.lblPrix.TabIndex = 13;
            this.lblPrix.Text = "Prix:";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescription.Location = new System.Drawing.Point(35, 40);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(91, 16);
            this.lblDescription.TabIndex = 12;
            this.lblDescription.Text = "Description:";
            // 
            // typeUtilisateurTableAdapter
            // 
            this.typeUtilisateurTableAdapter.ClearBeforeFill = true;
            // 
            // typeSoinsEtDescriptionTableAdapter
            // 
            this.typeSoinsEtDescriptionTableAdapter.ClearBeforeFill = true;
            // 
            // errMessage
            // 
            this.errMessage.ContainerControl = this;
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet1
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet1.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // typeSoinsEtDescriptionBindingSource1
            // 
            this.typeSoinsEtDescriptionBindingSource1.DataMember = "typeSoinsEtDescription";
            this.typeSoinsEtDescriptionBindingSource1.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet1;
            // 
            // frmAjouterSoins
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(446, 256);
            this.Controls.Add(this.btnFermer);
            this.Controls.Add(this.btnAjouter);
            this.Controls.Add(this.cboNoTypeSoin);
            this.Controls.Add(this.txtPrix);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.lbNoTypeSoin);
            this.Controls.Add(this.lblPrix);
            this.Controls.Add(this.lblDescription);
            this.Name = "frmAjouterSoins";
            this.Text = "frmAjouterSoins";
            this.Load += new System.EventHandler(this.frmAjouterSoins_Load);
            ((System.ComponentModel.ISupportInitialize)(this.typeSoinsEtDescriptionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeUtilisateurBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMessage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeSoinsEtDescriptionBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFermer;
        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.ComboBox cboNoTypeSoin;
        private System.Windows.Forms.TextBox txtPrix;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label lbNoTypeSoin;
        private System.Windows.Forms.Label lblPrix;
        private System.Windows.Forms.Label lblDescription;
        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource typeUtilisateurBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typeUtilisateurTableAdapter typeUtilisateurTableAdapter;
        private System.Windows.Forms.BindingSource typeSoinsEtDescriptionBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typeSoinsEtDescriptionTableAdapter typeSoinsEtDescriptionTableAdapter;
        private System.Windows.Forms.ErrorProvider errMessage;
        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet1;
        private System.Windows.Forms.BindingSource typeSoinsEtDescriptionBindingSource1;
    }
}