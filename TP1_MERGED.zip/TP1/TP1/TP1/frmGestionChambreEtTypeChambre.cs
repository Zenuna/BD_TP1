﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmGestionChambreEtTypeChambre : Form
    {
        public frmGestionChambreEtTypeChambre()
        {
            InitializeComponent();
        }

        private void btnGestionChambre_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmGestionChambre fGestionChambre= new frmGestionChambre();
            fGestionChambre.ShowDialog();
            this.Show();
        }

        private void btnGestionTypeChambre_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmGestionTypeChambre fGestionTypeChambre = new frmGestionTypeChambre();
            fGestionTypeChambre.ShowDialog();
            this.Show();

        }
    }
}
