﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmAjouterReservationChambre : Form
    {
        public BD5B6TP1_KoumaJouaniqueDataSet.ReservationChambreRow uneReservation;
        public frmAjouterReservationChambre()
        {
            InitializeComponent();
        }

        private void nomClientBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.nomClientBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bD5B6TP1_KoumaJouaniqueDataSet);

        }

        private void frmAjouterReservationChambre_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.DataGridViewDeChambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.dataGridViewDeChambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.DataGridViewDeChambre);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Chambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.chambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Chambre);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.NomClient'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.nomClientTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.NomClient);

        }

        private void btnFermer_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {

            if (dtpDateArrivee.Value > dtpDepart.Value)
            {
                errMessage.SetError(dtpDateArrivee, "La date d'arrivée ne peut être supérieure à la date de départ ");
            }
            else
            {
                //DateTime datetime = Convert.ToDateTime(dtpDate.Value.ToShortDateString() + ' ' + dtpHeure.Value.ToShortTimeString());
                /*uneReservation.NoChambre = int.Parse(dataGridViewDeChambreDataGridView    chambreDataGridView["dgEmplacement", e.RowIndex]);
                unePlanification.NoAssistant = int.Parse(cboNoAssistant.SelectedValue.ToString());
                MessageBox.Show(dtpDate.Value.ToString() + ' ' + dtpHeure.Value.ToString());
                unePlanification.DateHeure = Convert.ToDateTime(datetime);
                unePlanification.NoSoin = int.Parse(cboNoSoins.SelectedValue.ToString());
                this.Close();*/
            }
           /* if (int.Parse(dtpHeure.Value.Hour.ToString()) < 8 && int.Parse(dtpHeure.Value.Hour.ToString()) > 17)
            {
                errMessage.SetError(dtpHeure, "L'heure ne peut être inférieur à 8 ou suppérieur à 17 ");
            }
            else if (dtpDate.Value.CompareTo(DateTime.Now) < 0)
            {
                errMessage.SetError(dtpDate, "La date ne peut être antérieur à la date du jour");
            }

            else if (dtpDate.Value.DayOfWeek.ToString().Equals("Sunday") || dtpDate.Value.DayOfWeek.ToString().Equals("Saturday"))
            {
                errMessage.SetError(dtpDate, "La date ne peut être un samedi ou un dimanche");
            }
            else
            {
                SqlConnection maConnexion = new SqlConnection(maChaineDeConnexion);
                maConnexion.Open();
                String maRequeteSQL = "SELECT COUNT(DateHeure) FROM PlanifSoin where NoAssistant = '" + cboNoAssistant.SelectedValue + "' GROUP BY DateHeure HAVING COUNT(DateHeure) > 1 ";
                SqlCommand maCommande = new SqlCommand(maRequeteSQL, maConnexion);

                // Toujours convertir car ExecuteScalar retourne un objet sans type

                // try
                // {
                int compteur = 0;
                dynamic retour = maCommande.ExecuteScalar();
                compteur = int.Parse(retour + "");
                if (compteur == 0)
                {
                    DateTime datetime = Convert.ToDateTime(dtpDate.Value.ToShortDateString() + ' ' + dtpHeure.Value.ToShortTimeString());
                    unePlanification.NoPersonne = int.Parse(cboClientEtInvite.SelectedValue.ToString());
                    unePlanification.NoAssistant = int.Parse(cboNoAssistant.SelectedValue.ToString());
                    MessageBox.Show(dtpDate.Value.ToString() + ' ' + dtpHeure.Value.ToString());
                    unePlanification.DateHeure = Convert.ToDateTime(datetime);
                    unePlanification.NoSoin = int.Parse(cboNoSoins.SelectedValue.ToString());
                    this.Close();
                }
                //  }
                //  catch
                //  {
                else
                    errMessage.SetError(cboNoAssistant, "Un assistant ne peut donner un soins a la meme heure à deux personnes");
                //}
            }*/
        }
    }
}
