﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmRapportChambre : Form
    {
        public frmRapportChambre()
        {
            InitializeComponent();
        }

        private void rapportChambreBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.rapportChambreBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bD5B6TP1_KoumaJouaniqueDataSet);

        }

        private void rapportChambreBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.rapportChambreBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bD5B6TP1_KoumaJouaniqueDataSet);

        }

        private void frmRapportChambre_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.RapportReservationChambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.rapportReservationChambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.RapportReservationChambre);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.RapportChambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.rapportChambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.RapportChambre);

        }
    }
}
