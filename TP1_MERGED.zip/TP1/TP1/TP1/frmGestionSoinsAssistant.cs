﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmGestionSoinsAssistant : Form
    {
        public String noUtilisateur;
        static String maChaineDeConnexion = "Data Source = sqlinfo.cgodin.qc.ca; Initial Catalog = BD5B6TP1_KoumaJouanique; Persist Security Info=True;User ID = 5B6Kouma;Password=1PetitDioulaBanchi";
        SqlConnection maConnexion = new SqlConnection(maChaineDeConnexion);
        public frmGestionSoinsAssistant()
        {
            InitializeComponent();
        }

        private void frmGestionSoinsAssistant_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.PlanifSoin'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.planifSoinTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.PlanifSoin);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.AssistantSoin'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.assistantSoinTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.AssistantSoin);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.PrenomNomAssistant'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.prenomNomAssistantTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.PrenomNomAssistant);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Soin'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.soinTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Soin);




        }

        private void btnPremierSoin_Click(object sender, EventArgs e)
        {
            assistantSoinBindingSource.MoveFirst();
        }

        private void btnSoinPrecedent_Click(object sender, EventArgs e)
        {
            assistantSoinBindingSource.MovePrevious();
        }

        private void btnSoinSuivant_Click(object sender, EventArgs e)
        {
            assistantSoinBindingSource.MoveNext();
        }

        private void btnDernierSoin_Click(object sender, EventArgs e)
        {
            assistantSoinBindingSource.MoveLast();
        }

        private void btnSupprSoin_Click(object sender, EventArgs e)
        {
            if (cbAssistant.SelectedValue != null)
            {
                String strNoAssistant = cbAssistant.SelectedValue.ToString();
                String strNoSoin = assistantSoinDataGridView.CurrentRow.Cells[0].Value.ToString();
                Boolean bTrouver = false;
                foreach(DataGridViewRow dGRV in planifSoinDataGridView.Rows)
                {
                    if(dGRV.Cells[1].Value != null && dGRV.Cells[3].Value != null) if (dGRV.Cells[1].Value.ToString().Equals(strNoAssistant) && dGRV.Cells[3].Value.ToString().Equals(strNoSoin)) bTrouver = true;
                }
                if (!bTrouver)
                {
                    String SelectedText = Convert.ToString((assistantSoinDataGridView.Rows[0].Cells["dgSoin"] as DataGridViewComboBoxCell).FormattedValue.ToString());
                    String strNomSoin = assistantSoinDataGridView.CurrentRow.Cells[0].ToString();
                    DialogResult res = MessageBox.Show(this, "Voulez-vous vraiment supprimer le soin " + SelectedText + " de cet assistant?", "Suppression d'un soin-assistant", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
                    if (res == DialogResult.OK)
                    {
                        assistantSoinBindingSource.RemoveCurrent();
                        try
                        {
                            tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                        }
                        catch (DBConcurrencyException erreur)
                        {
                            MessageBox.Show("Conflit d'accès concurrentiel pour le soin " + erreur.Row["dgSoin"].ToString() + ".Aucun enregistrement possible.", "Conflit d'accès");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Un soin-assistant ne peut pas être supprimé si une donnée y est liée. Vérifier la table : Soins planifiés");
                }
            }
            else
                {
                    MessageBox.Show("Sélectionner un assistant dans la liste d'assistants");
                }
            }
        

        private void btnAjouterSoin_Click(object sender, EventArgs e)
        {
            if (cbAssistant.SelectedValue == null) MessageBox.Show("Sélectionner un assistant dans la liste d'assistants");
            else
            {
                assistantSoinBindingSource.CancelEdit();
                assistantSoinBindingSource.AddNew();
                assistantSoinDataGridView.CurrentRow.Cells[0].ReadOnly = false;
            }
        }

        private void dgAssistantSoin_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {
            assistantSoinDataGridView.CurrentRow.Cells[0].ReadOnly = true;
            try
            {
                this.Validate();
                tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
            }
            catch (DBConcurrencyException erreur)
            {
                MessageBox.Show("Conflit d'accès concurrentiel pour le soin " + erreur.Row["dgSoin"].ToString() + ".Aucun enregistrement possible.", "Conflit d'accès");
            }
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            bD5B6TP1_KoumaJouaniqueDataSet.AssistantSoin.RejectChanges();
            assistantSoinBindingSource.ResetBindings(false);
        }
    }
}
