﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TP1
{
    public partial class frmGestionTypeChambre : Form
    {
        static String maChaineDeConnexion = "Data Source = sqlinfo.cgodin.qc.ca; Initial Catalog = BD5B6TP1_KoumaJouanique; Persist Security Info=True;User ID = 5B6Kouma;Password=1PetitDioulaBanchi";

        public frmGestionTypeChambre()
        {
            InitializeComponent();
        }

        private void typeChambreBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.typeChambreBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bD5B6TP1_KoumaJouaniqueDataSet);

        }

        private void frmGestionTypeChambre_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Chambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.chambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Chambre);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            // this.reservationChambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.TypeChambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.typeChambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.TypeChambre);

        }

        private void btnAjouterTypeChambre_Click(object sender, EventArgs e)
        {
            BD5B6TP1_KoumaJouaniqueDataSet.TypeChambreRow unTypeChambre = bD5B6TP1_KoumaJouaniqueDataSet.TypeChambre.NewTypeChambreRow();
            decimal noTypeChambreMax = 0;
            foreach (BD5B6TP1_KoumaJouaniqueDataSet.TypeChambreRow uneLigne in bD5B6TP1_KoumaJouaniqueDataSet.TypeChambre.Rows)
            {
                if (uneLigne.NoTypeChambre > noTypeChambreMax) noTypeChambreMax = uneLigne.NoTypeChambre;
            }

            unTypeChambre.NoTypeChambre = int.Parse(noTypeChambreMax.ToString()) + 1;
            unTypeChambre.Description = "";
            frmAjouterTypeChambre fAjouterTypeChambre = new frmAjouterTypeChambre();
            fAjouterTypeChambre.unTypeChambre = unTypeChambre;
            fAjouterTypeChambre.ShowDialog();
            if (unTypeChambre.Description != "")
            {
                bD5B6TP1_KoumaJouaniqueDataSet.TypeChambre.AddTypeChambreRow(unTypeChambre);
                typeChambreBindingSource.MoveLast();
                MessageBox.Show("Le type chambre a été ajoutée avec succès");
            }
        }

        private void typeChambreDataGridView_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {

            String strMessagErreur = "";
            String strDescription = typeChambreDataGridView["dgDescription", e.RowIndex].Value.ToString();
            decimal PrixHaut = decimal.Parse(typeChambreDataGridView["dgPrixHaut", e.RowIndex].Value.ToString());
            decimal PrixBas = decimal.Parse(typeChambreDataGridView["dgPrixBas", e.RowIndex].Value.ToString());
            decimal PrixMoyen = decimal.Parse(typeChambreDataGridView["dgPrixMoyen", e.RowIndex].Value.ToString());
            SqlConnection maConnexion = new SqlConnection(maChaineDeConnexion);
            maConnexion.Open();
            String maRequeteSQL = "SELECT count(*) FROM TypeChambre WHERE description IN ( SELECT Description FROM TypeChambre where description = '" + strDescription + "' GROUP BY Description HAVING COUNT(*) > 1 )";
            SqlCommand maCommande = new SqlCommand(maRequeteSQL, maConnexion);
            int compteur = 0;
            compteur = (int)maCommande.ExecuteScalar();
            if (strDescription == "")
            {
                strMessagErreur = "La description ne peut être vide";
                e.Cancel = true;
            }
            else if (PrixHaut.ToString() == "")
            {
                strMessagErreur = "Le prix haut ne peut être vide";
                e.Cancel = true;
            }
            else if (PrixBas.ToString() == "")
            {
                strMessagErreur = "Le prix bas ne peut être vide";
                e.Cancel = true;
            }
            else if (PrixMoyen.ToString() == "")
            {
                strMessagErreur = "Le prix moyen ne peut être vide";
                e.Cancel = true;
            }
            else if (PrixBas > PrixHaut)
            {
                strMessagErreur = "Le prix bas ne peut être plus grand que le prix haut";
                e.Cancel = true;
            }
            else if (PrixMoyen > PrixHaut || PrixMoyen < PrixBas)
            {
                strMessagErreur = "Le prix moyen doit etre entre le prix bas et le prix haut";
            }
         else if (compteur > 0)
            {
                strMessagErreur = "La description doit être unique";
            }
            typeChambreDataGridView.Rows[e.RowIndex].ErrorText = strMessagErreur;
        }

        private void btnSupprimerTypeChambre_Click(object sender, EventArgs e)
        {
            int nbLigne = chambreDataGridView.Rows.Count;
            if (nbLigne == 0)
            {
                chambreBindingSource.RemoveCurrent();
            }
            else
            {
                MessageBox.Show("Impossible de supprimer un type de chambre dans lequel on a deja des chambres");
            }
        }

        private void btnModifierTypeChambre_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.typeChambreBindingSource.EndEdit();
            try
            {
                this.tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                MessageBox.Show("Les modifications ont été enrégistré avec succès");
            }
            catch (DBConcurrencyException erreur)
            {
                //String noPersonne = erreur.Row["dgNoPersonne"].ToString();
                MessageBox.Show("Conflit d'accès concurrentiel");
            }
        }
    }
}
