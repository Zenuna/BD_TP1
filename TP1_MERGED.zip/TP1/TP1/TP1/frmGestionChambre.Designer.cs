﻿namespace TP1
{
    partial class frmGestionChambre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnAjouterChambre = new System.Windows.Forms.Button();
            this.btnModifierChambre = new System.Windows.Forms.Button();
            this.btnSupprimerChambre = new System.Windows.Forms.Button();
            this.chambreDataGridView = new System.Windows.Forms.DataGridView();
            this.reservationChambreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reservationChambreDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chambreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.typeSoinsEtDescriptionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.chambreTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ChambreTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.reservationChambreTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ReservationChambreTableAdapter();
            this.typeSoinsEtDescriptionTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typeSoinsEtDescriptionTableAdapter();
            this.typchambreEtDescriptionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.typchambreEtDescriptionTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typchambreEtDescriptionTableAdapter();
            this.dgNoChambre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgEmplacement = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgDecoration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgNoTypeChambre = new System.Windows.Forms.DataGridViewComboBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.chambreDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservationChambreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservationChambreDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chambreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeSoinsEtDescriptionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typchambreEtDescriptionBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAjouterChambre
            // 
            this.btnAjouterChambre.Location = new System.Drawing.Point(44, 256);
            this.btnAjouterChambre.Name = "btnAjouterChambre";
            this.btnAjouterChambre.Size = new System.Drawing.Size(104, 48);
            this.btnAjouterChambre.TabIndex = 0;
            this.btnAjouterChambre.Text = "Ajouter une chambre";
            this.btnAjouterChambre.UseVisualStyleBackColor = true;
            this.btnAjouterChambre.Click += new System.EventHandler(this.btnAjouterChambre_Click);
            // 
            // btnModifierChambre
            // 
            this.btnModifierChambre.Location = new System.Drawing.Point(163, 256);
            this.btnModifierChambre.Name = "btnModifierChambre";
            this.btnModifierChambre.Size = new System.Drawing.Size(104, 48);
            this.btnModifierChambre.TabIndex = 1;
            this.btnModifierChambre.Text = "Modifier";
            this.btnModifierChambre.UseVisualStyleBackColor = true;
            this.btnModifierChambre.Click += new System.EventHandler(this.btnModifierChambre_Click);
            // 
            // btnSupprimerChambre
            // 
            this.btnSupprimerChambre.Location = new System.Drawing.Point(288, 256);
            this.btnSupprimerChambre.Name = "btnSupprimerChambre";
            this.btnSupprimerChambre.Size = new System.Drawing.Size(104, 48);
            this.btnSupprimerChambre.TabIndex = 2;
            this.btnSupprimerChambre.Text = "Supprimer chambre";
            this.btnSupprimerChambre.UseVisualStyleBackColor = true;
            this.btnSupprimerChambre.Click += new System.EventHandler(this.btnSupprimerChambre_Click);
            // 
            // chambreDataGridView
            // 
            this.chambreDataGridView.AutoGenerateColumns = false;
            this.chambreDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.chambreDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgNoChambre,
            this.dgEmplacement,
            this.dgDecoration,
            this.dgNoTypeChambre});
            this.chambreDataGridView.DataSource = this.chambreBindingSource;
            this.chambreDataGridView.Location = new System.Drawing.Point(12, 12);
            this.chambreDataGridView.Name = "chambreDataGridView";
            this.chambreDataGridView.Size = new System.Drawing.Size(448, 220);
            this.chambreDataGridView.TabIndex = 4;
            this.chambreDataGridView.RowValidating += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.chambreDataGridView_RowValidating);
            // 
            // reservationChambreBindingSource
            // 
            this.reservationChambreBindingSource.DataMember = "FK_NoChambre";
            this.reservationChambreBindingSource.DataSource = this.chambreBindingSource;
            // 
            // reservationChambreDataGridView
            // 
            this.reservationChambreDataGridView.AutoGenerateColumns = false;
            this.reservationChambreDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reservationChambreDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.reservationChambreDataGridView.DataSource = this.reservationChambreBindingSource;
            this.reservationChambreDataGridView.Location = new System.Drawing.Point(428, 270);
            this.reservationChambreDataGridView.Name = "reservationChambreDataGridView";
            this.reservationChambreDataGridView.Size = new System.Drawing.Size(300, 220);
            this.reservationChambreDataGridView.TabIndex = 4;
            this.reservationChambreDataGridView.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "NoClient";
            this.dataGridViewTextBoxColumn1.HeaderText = "NoClient";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NoChambre";
            this.dataGridViewTextBoxColumn2.HeaderText = "NoChambre";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "DateArrivee";
            this.dataGridViewTextBoxColumn3.HeaderText = "DateArrivee";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "DateDepart";
            this.dataGridViewTextBoxColumn4.HeaderText = "DateDepart";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "NbPersonnes";
            this.dataGridViewTextBoxColumn5.HeaderText = "NbPersonnes";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // chambreBindingSource
            // 
            this.chambreBindingSource.DataMember = "Chambre";
            this.chambreBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // typeSoinsEtDescriptionBindingSource
            // 
            this.typeSoinsEtDescriptionBindingSource.DataMember = "typeSoinsEtDescription";
            this.typeSoinsEtDescriptionBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // chambreTableAdapter
            // 
            this.chambreTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = this.chambreTableAdapter;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = this.reservationChambreTableAdapter;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.typchambreEtDescriptionTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // reservationChambreTableAdapter
            // 
            this.reservationChambreTableAdapter.ClearBeforeFill = true;
            // 
            // typeSoinsEtDescriptionTableAdapter
            // 
            this.typeSoinsEtDescriptionTableAdapter.ClearBeforeFill = true;
            // 
            // typchambreEtDescriptionBindingSource
            // 
            this.typchambreEtDescriptionBindingSource.DataMember = "typchambreEtDescription";
            this.typchambreEtDescriptionBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // typchambreEtDescriptionTableAdapter
            // 
            this.typchambreEtDescriptionTableAdapter.ClearBeforeFill = true;
            // 
            // dgNoChambre
            // 
            this.dgNoChambre.DataPropertyName = "NoChambre";
            this.dgNoChambre.HeaderText = "NoChambre";
            this.dgNoChambre.Name = "dgNoChambre";
            this.dgNoChambre.ReadOnly = true;
            // 
            // dgEmplacement
            // 
            this.dgEmplacement.DataPropertyName = "Emplacement";
            this.dgEmplacement.HeaderText = "Emplacement";
            this.dgEmplacement.Name = "dgEmplacement";
            // 
            // dgDecoration
            // 
            this.dgDecoration.DataPropertyName = "Decorations";
            this.dgDecoration.HeaderText = "Decorations";
            this.dgDecoration.Name = "dgDecoration";
            // 
            // dgNoTypeChambre
            // 
            this.dgNoTypeChambre.DataPropertyName = "NoTypeChambre";
            this.dgNoTypeChambre.DataSource = this.typchambreEtDescriptionBindingSource;
            this.dgNoTypeChambre.DisplayMember = "Description";
            this.dgNoTypeChambre.HeaderText = "NoTypeChambre";
            this.dgNoTypeChambre.Name = "dgNoTypeChambre";
            this.dgNoTypeChambre.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgNoTypeChambre.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgNoTypeChambre.ValueMember = "NoTypeChambre";
            // 
            // frmGestionChambre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(748, 510);
            this.Controls.Add(this.reservationChambreDataGridView);
            this.Controls.Add(this.chambreDataGridView);
            this.Controls.Add(this.btnSupprimerChambre);
            this.Controls.Add(this.btnModifierChambre);
            this.Controls.Add(this.btnAjouterChambre);
            this.Name = "frmGestionChambre";
            this.Text = "frmGestionChambre";
            this.Load += new System.EventHandler(this.frmGestionChambre_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chambreDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservationChambreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reservationChambreDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chambreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeSoinsEtDescriptionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typchambreEtDescriptionBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAjouterChambre;
        private System.Windows.Forms.Button btnModifierChambre;
        private System.Windows.Forms.Button btnSupprimerChambre;
        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource chambreBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ChambreTableAdapter chambreTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView chambreDataGridView;
        private System.Windows.Forms.BindingSource typeSoinsEtDescriptionBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typeSoinsEtDescriptionTableAdapter typeSoinsEtDescriptionTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ReservationChambreTableAdapter reservationChambreTableAdapter;
        private System.Windows.Forms.BindingSource reservationChambreBindingSource;
        private System.Windows.Forms.DataGridView reservationChambreDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.BindingSource typchambreEtDescriptionBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.typchambreEtDescriptionTableAdapter typchambreEtDescriptionTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgNoChambre;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgEmplacement;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgDecoration;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgNoTypeChambre;
    }
}