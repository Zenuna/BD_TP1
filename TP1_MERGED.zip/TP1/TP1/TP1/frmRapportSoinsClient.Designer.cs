﻿namespace TP1
{
    partial class frmRapportSoinsClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label noNomLabel;
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.rapportSoinsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rapportSoinsTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.rapportSoinsTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.noNomComboBox = new System.Windows.Forms.ComboBox();
            this.tableRapportSoinsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tableRapportSoinsTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.tableRapportSoinsTableAdapter();
            this.dgRapportSoin = new System.Windows.Forms.DataGridView();
            this.dgDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgDateHeure = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPrix = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgNomAssistant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbPrix = new System.Windows.Forms.Label();
            this.btnCalculer = new System.Windows.Forms.Button();
            noNomLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportSoinsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableRapportSoinsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRapportSoin)).BeginInit();
            this.SuspendLayout();
            // 
            // noNomLabel
            // 
            noNomLabel.AutoSize = true;
            noNomLabel.Location = new System.Drawing.Point(18, 15);
            noNomLabel.Name = "noNomLabel";
            noNomLabel.Size = new System.Drawing.Size(49, 13);
            noNomLabel.TabIndex = 1;
            noNomLabel.Text = "No Nom:";
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rapportSoinsBindingSource
            // 
            this.rapportSoinsBindingSource.DataMember = "rapportSoins";
            this.rapportSoinsBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // rapportSoinsTableAdapter
            // 
            this.rapportSoinsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.InviteTableAdapter = null;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.PrenomNomClientTableAdapter = null;
            this.tableAdapterManager.RapportAssistantJourTableAdapter = null;
            this.tableAdapterManager.RapportChambreTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // noNomComboBox
            // 
            this.noNomComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.rapportSoinsBindingSource, "NoNom", true));
            this.noNomComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.rapportSoinsBindingSource, "NoNom", true));
            this.noNomComboBox.DataSource = this.rapportSoinsBindingSource;
            this.noNomComboBox.DisplayMember = "NoNom";
            this.noNomComboBox.FormattingEnabled = true;
            this.noNomComboBox.Location = new System.Drawing.Point(73, 12);
            this.noNomComboBox.Name = "noNomComboBox";
            this.noNomComboBox.Size = new System.Drawing.Size(249, 21);
            this.noNomComboBox.TabIndex = 2;
            this.noNomComboBox.ValueMember = "NoClient";
            // 
            // tableRapportSoinsBindingSource
            // 
            this.tableRapportSoinsBindingSource.DataMember = "rapportSoins_DataTable1";
            this.tableRapportSoinsBindingSource.DataSource = this.rapportSoinsBindingSource;
            // 
            // tableRapportSoinsTableAdapter
            // 
            this.tableRapportSoinsTableAdapter.ClearBeforeFill = true;
            // 
            // dgRapportSoin
            // 
            this.dgRapportSoin.AllowUserToAddRows = false;
            this.dgRapportSoin.AllowUserToDeleteRows = false;
            this.dgRapportSoin.AutoGenerateColumns = false;
            this.dgRapportSoin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRapportSoin.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgDesc,
            this.dgDateHeure,
            this.dgPrix,
            this.dgNomAssistant});
            this.dgRapportSoin.DataSource = this.tableRapportSoinsBindingSource;
            this.dgRapportSoin.Location = new System.Drawing.Point(338, 12);
            this.dgRapportSoin.Name = "dgRapportSoin";
            this.dgRapportSoin.ReadOnly = true;
            this.dgRapportSoin.Size = new System.Drawing.Size(450, 426);
            this.dgRapportSoin.TabIndex = 2;
            // 
            // dgDesc
            // 
            this.dgDesc.DataPropertyName = "Description";
            this.dgDesc.HeaderText = "Description";
            this.dgDesc.Name = "dgDesc";
            this.dgDesc.ReadOnly = true;
            // 
            // dgDateHeure
            // 
            this.dgDateHeure.DataPropertyName = "DateHeure";
            this.dgDateHeure.HeaderText = "Date-heure  du soin";
            this.dgDateHeure.Name = "dgDateHeure";
            this.dgDateHeure.ReadOnly = true;
            // 
            // dgPrix
            // 
            this.dgPrix.DataPropertyName = "Prix";
            this.dgPrix.HeaderText = "Prix";
            this.dgPrix.Name = "dgPrix";
            this.dgPrix.ReadOnly = true;
            // 
            // dgNomAssistant
            // 
            this.dgNomAssistant.DataPropertyName = "NomComplet";
            this.dgNomAssistant.HeaderText = "Nom complet de l\'assistant";
            this.dgNomAssistant.Name = "dgNomAssistant";
            this.dgNomAssistant.ReadOnly = true;
            // 
            // lbPrix
            // 
            this.lbPrix.AutoSize = true;
            this.lbPrix.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPrix.Location = new System.Drawing.Point(16, 66);
            this.lbPrix.Name = "lbPrix";
            this.lbPrix.Size = new System.Drawing.Size(72, 25);
            this.lbPrix.TabIndex = 3;
            this.lbPrix.Text = "Total: ";
            // 
            // btnCalculer
            // 
            this.btnCalculer.Location = new System.Drawing.Point(205, 39);
            this.btnCalculer.Name = "btnCalculer";
            this.btnCalculer.Size = new System.Drawing.Size(117, 23);
            this.btnCalculer.TabIndex = 4;
            this.btnCalculer.Text = "Calculer total";
            this.btnCalculer.UseVisualStyleBackColor = true;
            this.btnCalculer.Click += new System.EventHandler(this.btnEnvoyer_Click);
            // 
            // frmRapportSoinsClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalculer);
            this.Controls.Add(this.lbPrix);
            this.Controls.Add(this.dgRapportSoin);
            this.Controls.Add(noNomLabel);
            this.Controls.Add(this.noNomComboBox);
            this.Name = "frmRapportSoinsClient";
            this.Text = "Rapport des soins offerts aux clients et aux invités";
            this.Load += new System.EventHandler(this.frmRapportSoinsClient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportSoinsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableRapportSoinsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRapportSoin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource rapportSoinsBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.rapportSoinsTableAdapter rapportSoinsTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ComboBox noNomComboBox;
        private System.Windows.Forms.BindingSource tableRapportSoinsBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.tableRapportSoinsTableAdapter tableRapportSoinsTableAdapter;
        private System.Windows.Forms.DataGridView dgRapportSoin;
        private System.Windows.Forms.Label lbPrix;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgDateHeure;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgPrix;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgNomAssistant;
        private System.Windows.Forms.Button btnCalculer;
    }
}