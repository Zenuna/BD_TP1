﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TP1
{
    public partial class frmPlanificationSoins : Form
    {
        static String maChaineDeConnexion = "Data Source = sqlinfo.cgodin.qc.ca; Initial Catalog = BD5B6TP1_KoumaJouanique; Persist Security Info=True;User ID = 5B6Kouma;Password=1PetitDioulaBanchi";
        SqlConnection maConnexion = new SqlConnection(maChaineDeConnexion);
        public frmPlanificationSoins()
        {
            InitializeComponent();
        }

        private void planifSoinBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {

        }

        private void frmPlanificationSoins2_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            // this.reservationChambreTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.ReservationChambre);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.PlanifSoin'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.planifSoinTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.PlanifSoin);

        }

        private void btnAjouterReserVationSoin_Click(object sender, EventArgs e)
        {
            BD5B6TP1_KoumaJouaniqueDataSet.PlanifSoinRow unePlanification = bD5B6TP1_KoumaJouaniqueDataSet.PlanifSoin.NewPlanifSoinRow();
            unePlanification.DateHeure = DateTime.MaxValue;
            frmAjouterReservationSoin fAjouterReservationSoin = new frmAjouterReservationSoin();
            fAjouterReservationSoin.unePlanification = unePlanification;
            fAjouterReservationSoin.ShowDialog();

            if (unePlanification.DateHeure != DateTime.MaxValue)
            {
                bD5B6TP1_KoumaJouaniqueDataSet.PlanifSoin.AddPlanifSoinRow(unePlanification);
                planifSoinBindingSource.MoveLast();
                MessageBox.Show("Le nouveau soin a été planifié avec succès");
            }
        }

        private void btnEnregistrerModification_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.planifSoinBindingSource.EndEdit();
            try
            {
                this.tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                MessageBox.Show("Les modifications ont été enrégistré avec succès");
            }
            catch (DBConcurrencyException erreur)
            {
                //String noPersonne = erreur.Row["dgNoPersonne"].ToString();
                MessageBox.Show("Conflit d'accès concurrentiel");
            }
        }

        private void btnSupprimerReservationSoin_Click(object sender, EventArgs e)
        {

            planifSoinBindingSource.RemoveCurrent();
        }
    }
}
