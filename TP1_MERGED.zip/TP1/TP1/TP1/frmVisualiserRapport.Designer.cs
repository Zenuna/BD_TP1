﻿namespace TP1
{
    partial class frmMenuVisualiserRapport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRapportSoinsAssistants = new System.Windows.Forms.Button();
            this.btnRapportReservation = new System.Windows.Forms.Button();
            this.btnRapportSoinsClient = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnRapportSoinsAssistants
            // 
            this.btnRapportSoinsAssistants.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRapportSoinsAssistants.Location = new System.Drawing.Point(12, 202);
            this.btnRapportSoinsAssistants.Name = "btnRapportSoinsAssistants";
            this.btnRapportSoinsAssistants.Size = new System.Drawing.Size(234, 89);
            this.btnRapportSoinsAssistants.TabIndex = 15;
            this.btnRapportSoinsAssistants.Text = "C. Rapport des soins journaliers des assistants";
            this.btnRapportSoinsAssistants.UseVisualStyleBackColor = true;
            this.btnRapportSoinsAssistants.Click += new System.EventHandler(this.btnRapportSoinsAssistants_Click);
            // 
            // btnRapportReservation
            // 
            this.btnRapportReservation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRapportReservation.Location = new System.Drawing.Point(12, 107);
            this.btnRapportReservation.Name = "btnRapportReservation";
            this.btnRapportReservation.Size = new System.Drawing.Size(234, 89);
            this.btnRapportReservation.TabIndex = 16;
            this.btnRapportReservation.Text = "B. Rapport des réservations de chambres";
            this.btnRapportReservation.UseVisualStyleBackColor = true;
            this.btnRapportReservation.Click += new System.EventHandler(this.btnRapportReservation_Click);
            // 
            // btnRapportSoinsClient
            // 
            this.btnRapportSoinsClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRapportSoinsClient.Location = new System.Drawing.Point(12, 12);
            this.btnRapportSoinsClient.Name = "btnRapportSoinsClient";
            this.btnRapportSoinsClient.Size = new System.Drawing.Size(234, 89);
            this.btnRapportSoinsClient.TabIndex = 17;
            this.btnRapportSoinsClient.Text = "A. Rapport des soins offerts aux clients et aux invités";
            this.btnRapportSoinsClient.UseVisualStyleBackColor = true;
            this.btnRapportSoinsClient.Click += new System.EventHandler(this.btnRapportSoinsClient_Click);
            // 
            // frmMenuVisualiserRapport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(261, 302);
            this.Controls.Add(this.btnRapportSoinsClient);
            this.Controls.Add(this.btnRapportReservation);
            this.Controls.Add(this.btnRapportSoinsAssistants);
            this.Name = "frmMenuVisualiserRapport";
            this.Text = "Menu visualisation de rapports";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRapportSoinsAssistants;
        private System.Windows.Forms.Button btnRapportReservation;
        private System.Windows.Forms.Button btnRapportSoinsClient;
    }
}