﻿namespace TP1
{
    partial class frmGestionInvite
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.prenomNomClientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.prenomNomClientTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PrenomNomClientTableAdapter();
            this.inviteTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.InviteTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.cbClient = new System.Windows.Forms.ComboBox();
            this.dgInvite = new System.Windows.Forms.DataGridView();
            this.inviteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.btnSupprInvite = new System.Windows.Forms.Button();
            this.btnAjouterInvite = new System.Windows.Forms.Button();
            this.btnDernierInvite = new System.Windows.Forms.Button();
            this.btnInviteSuivant = new System.Windows.Forms.Button();
            this.btnInvitePrecedent = new System.Windows.Forms.Button();
            this.btnPremierInvite = new System.Windows.Forms.Button();
            this.lblClient = new System.Windows.Forms.Label();
            this.dgNomPrenom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgNoInvite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.planifSoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.planifSoinTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PlanifSoinTableAdapter();
            this.planifSoinDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.prenomNomClientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgInvite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inviteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // prenomNomClientBindingSource
            // 
            this.prenomNomClientBindingSource.DataMember = "PrenomNomClient";
            this.prenomNomClientBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // prenomNomClientTableAdapter
            // 
            this.prenomNomClientTableAdapter.ClearBeforeFill = true;
            // 
            // inviteTableAdapter
            // 
            this.inviteTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = null;
            this.tableAdapterManager.InviteTableAdapter = this.inviteTableAdapter;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.PrenomNomAssistantTableAdapter = null;
            this.tableAdapterManager.PrenomNomClientTableAdapter = null;
            this.tableAdapterManager.RapportAssistantJourTableAdapter = null;
            this.tableAdapterManager.RapportChambreTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // cbClient
            // 
            this.cbClient.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.prenomNomClientBindingSource, "NomComplet", true));
            this.cbClient.DataSource = this.prenomNomClientBindingSource;
            this.cbClient.DisplayMember = "NomComplet";
            this.cbClient.FormattingEnabled = true;
            this.cbClient.Location = new System.Drawing.Point(63, 12);
            this.cbClient.Name = "cbClient";
            this.cbClient.Size = new System.Drawing.Size(239, 21);
            this.cbClient.TabIndex = 0;
            this.cbClient.ValueMember = "Noclient";
            // 
            // dgInvite
            // 
            this.dgInvite.AllowUserToAddRows = false;
            this.dgInvite.AllowUserToDeleteRows = false;
            this.dgInvite.AutoGenerateColumns = false;
            this.dgInvite.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgInvite.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgInvite.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgNoInvite,
            this.dgNomPrenom});
            this.dgInvite.DataSource = this.inviteBindingSource;
            this.dgInvite.Location = new System.Drawing.Point(12, 48);
            this.dgInvite.Name = "dgInvite";
            this.dgInvite.Size = new System.Drawing.Size(290, 220);
            this.dgInvite.TabIndex = 1;
            this.dgInvite.RowValidating += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgInvite_RowValidating);
            // 
            // inviteBindingSource
            // 
            this.inviteBindingSource.DataMember = "FK_NoClientInvite1";
            this.inviteBindingSource.DataSource = this.prenomNomClientBindingSource;
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(308, 202);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(169, 23);
            this.btnAnnuler.TabIndex = 29;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
            // 
            // btnSupprInvite
            // 
            this.btnSupprInvite.Location = new System.Drawing.Point(308, 240);
            this.btnSupprInvite.Name = "btnSupprInvite";
            this.btnSupprInvite.Size = new System.Drawing.Size(169, 23);
            this.btnSupprInvite.TabIndex = 28;
            this.btnSupprInvite.Text = "Supprimer invité";
            this.btnSupprInvite.UseVisualStyleBackColor = true;
            this.btnSupprInvite.Click += new System.EventHandler(this.btnSupprInvite_Click);
            // 
            // btnAjouterInvite
            // 
            this.btnAjouterInvite.Location = new System.Drawing.Point(308, 164);
            this.btnAjouterInvite.Name = "btnAjouterInvite";
            this.btnAjouterInvite.Size = new System.Drawing.Size(169, 23);
            this.btnAjouterInvite.TabIndex = 27;
            this.btnAjouterInvite.Text = "Ajouter invité";
            this.btnAjouterInvite.UseVisualStyleBackColor = true;
            this.btnAjouterInvite.Click += new System.EventHandler(this.btnAjouterInvite_Click);
            // 
            // btnDernierInvite
            // 
            this.btnDernierInvite.Location = new System.Drawing.Point(308, 126);
            this.btnDernierInvite.Name = "btnDernierInvite";
            this.btnDernierInvite.Size = new System.Drawing.Size(169, 23);
            this.btnDernierInvite.TabIndex = 26;
            this.btnDernierInvite.Text = "Dernier invité";
            this.btnDernierInvite.UseVisualStyleBackColor = true;
            this.btnDernierInvite.Click += new System.EventHandler(this.btnDernierInvite_Click);
            // 
            // btnInviteSuivant
            // 
            this.btnInviteSuivant.Location = new System.Drawing.Point(308, 88);
            this.btnInviteSuivant.Name = "btnInviteSuivant";
            this.btnInviteSuivant.Size = new System.Drawing.Size(169, 23);
            this.btnInviteSuivant.TabIndex = 25;
            this.btnInviteSuivant.Text = "Invité suivant";
            this.btnInviteSuivant.UseVisualStyleBackColor = true;
            this.btnInviteSuivant.Click += new System.EventHandler(this.btnInviteSuivant_Click);
            // 
            // btnInvitePrecedent
            // 
            this.btnInvitePrecedent.Location = new System.Drawing.Point(308, 50);
            this.btnInvitePrecedent.Name = "btnInvitePrecedent";
            this.btnInvitePrecedent.Size = new System.Drawing.Size(169, 23);
            this.btnInvitePrecedent.TabIndex = 24;
            this.btnInvitePrecedent.Text = "Invité précédent";
            this.btnInvitePrecedent.UseVisualStyleBackColor = true;
            this.btnInvitePrecedent.Click += new System.EventHandler(this.btnInvitePrecedent_Click);
            // 
            // btnPremierInvite
            // 
            this.btnPremierInvite.Location = new System.Drawing.Point(308, 12);
            this.btnPremierInvite.Name = "btnPremierInvite";
            this.btnPremierInvite.Size = new System.Drawing.Size(169, 23);
            this.btnPremierInvite.TabIndex = 23;
            this.btnPremierInvite.Text = "Premier invité";
            this.btnPremierInvite.UseVisualStyleBackColor = true;
            this.btnPremierInvite.Click += new System.EventHandler(this.btnPremierInvite_Click);
            // 
            // lblClient
            // 
            this.lblClient.AutoSize = true;
            this.lblClient.Location = new System.Drawing.Point(12, 17);
            this.lblClient.Name = "lblClient";
            this.lblClient.Size = new System.Drawing.Size(42, 13);
            this.lblClient.TabIndex = 30;
            this.lblClient.Text = "Client : ";
            // 
            // dgNomPrenom
            // 
            this.dgNomPrenom.DataPropertyName = "NomPrenom";
            this.dgNomPrenom.HeaderText = "Nom et prénom";
            this.dgNomPrenom.MaxInputLength = 50;
            this.dgNomPrenom.Name = "dgNomPrenom";
            // 
            // dgNoInvite
            // 
            this.dgNoInvite.DataPropertyName = "NoInvite";
            this.dgNoInvite.HeaderText = "Numéro d\'invité";
            this.dgNoInvite.Name = "dgNoInvite";
            this.dgNoInvite.ReadOnly = true;
            // 
            // planifSoinBindingSource
            // 
            this.planifSoinBindingSource.DataMember = "PlanifSoin";
            this.planifSoinBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // planifSoinTableAdapter
            // 
            this.planifSoinTableAdapter.ClearBeforeFill = true;
            // 
            // planifSoinDataGridView
            // 
            this.planifSoinDataGridView.AutoGenerateColumns = false;
            this.planifSoinDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.planifSoinDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.planifSoinDataGridView.DataSource = this.planifSoinBindingSource;
            this.planifSoinDataGridView.Location = new System.Drawing.Point(337, 268);
            this.planifSoinDataGridView.Name = "planifSoinDataGridView";
            this.planifSoinDataGridView.Size = new System.Drawing.Size(300, 220);
            this.planifSoinDataGridView.TabIndex = 30;
            this.planifSoinDataGridView.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "NoPersonne";
            this.dataGridViewTextBoxColumn1.HeaderText = "NoPersonne";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NoAssistant";
            this.dataGridViewTextBoxColumn2.HeaderText = "NoAssistant";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "DateHeure";
            this.dataGridViewTextBoxColumn3.HeaderText = "DateHeure";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "NoSoin";
            this.dataGridViewTextBoxColumn4.HeaderText = "NoSoin";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // frmGestionInvite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 274);
            this.Controls.Add(this.planifSoinDataGridView);
            this.Controls.Add(this.lblClient);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnSupprInvite);
            this.Controls.Add(this.btnAjouterInvite);
            this.Controls.Add(this.btnDernierInvite);
            this.Controls.Add(this.btnInviteSuivant);
            this.Controls.Add(this.btnInvitePrecedent);
            this.Controls.Add(this.btnPremierInvite);
            this.Controls.Add(this.dgInvite);
            this.Controls.Add(this.cbClient);
            this.Name = "frmGestionInvite";
            this.Text = "Gestion des invités";
            this.Load += new System.EventHandler(this.frmGestionInvite_Load);
            ((System.ComponentModel.ISupportInitialize)(this.prenomNomClientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgInvite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inviteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planifSoinDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource prenomNomClientBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PrenomNomClientTableAdapter prenomNomClientTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.InviteTableAdapter inviteTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ComboBox cbClient;
        private System.Windows.Forms.DataGridView dgInvite;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.Button btnSupprInvite;
        private System.Windows.Forms.Button btnAjouterInvite;
        private System.Windows.Forms.Button btnDernierInvite;
        private System.Windows.Forms.Button btnInviteSuivant;
        private System.Windows.Forms.Button btnInvitePrecedent;
        private System.Windows.Forms.Button btnPremierInvite;
        private System.Windows.Forms.Label lblClient;
        private System.Windows.Forms.BindingSource inviteBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgNoInvite;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgNomPrenom;
        private System.Windows.Forms.BindingSource planifSoinBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.PlanifSoinTableAdapter planifSoinTableAdapter;
        private System.Windows.Forms.DataGridView planifSoinDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    }
}