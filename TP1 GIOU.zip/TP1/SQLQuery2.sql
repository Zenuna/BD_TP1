use BD5B6TP1_KoumaJouanique

select s.NoSoin, convert(nvarchar,s.NoSoin)+ ' ' +  t.Description AS 'NumeroEtDescription' from Soin S
inner join TypeSoin T 
on s.NoTypeSoin = t.NoTypeSoin

select * from Assistant
select * from Soin
select * from TypeSoin
select * from AssistantSoin

select * from PlanifSoin

select * from PlanifSoin where NoAssistant

select At.NoAssistant, convert(nvarchar,a.NoAssistant) + ' ' + a.Nom + ' ' + a.Prenom AS 'NumeroNomEtPrenomAssistant' from AssistantSoin AT
inner join Assistant A
on at.NoAssistant = a.NoAssistant where at.NoSoin = cboNoSoins.selectedValue

select NoSoin, convert(nvarchar,NoSoin)+ ' ' +  Description AS 'NumeroEtDescription' from Soin 

insert into AssistantSoin values(1,1)
