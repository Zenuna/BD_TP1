﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Globalization;

namespace TP1
{
    public partial class frmAjouterReservationSoin : Form
    {
        public BD5B6TP1_KoumaJouaniqueDataSet.PlanifSoinRow unePlanification;
        public frmAjouterReservationSoin()
        {
            InitializeComponent();
        }

        private void frmAjouterReservationSoin_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.SoinEtDescription'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.soinEtDescriptionTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.SoinEtDescription);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.ClientEtInvite'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.clientEtInviteTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.ClientEtInvite);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet1.SoinEtDescription'. Vous pouvez la déplacer ou la supprimer selon les besoins.
           // this.soinEtDescriptionTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet1.SoinEtDescription);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.AssistantSoin'. Vous pouvez la déplacer ou la supprimer selon les besoins.
          //  this.assistantSoinTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.AssistantSoin);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Soin'. Vous pouvez la déplacer ou la supprimer selon les besoins.
           // this.soinTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Soin);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.ClientEtInvite'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.clientEtInviteTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.ClientEtInvite);


            this.numeroNomEtPrenomAssistantTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.NumeroNomEtPrenomAssistant, int.Parse(cboNoSoins.SelectedValue.ToString()));
           // MessageBox.Show(int.Parse(cboNoSoins.SelectedValue.ToString()).ToString());

        }

        private void cboNoSoins_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                this.numeroNomEtPrenomAssistantTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.NumeroNomEtPrenomAssistant, int.Parse(cboNoSoins.SelectedValue.ToString()));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            MessageBox.Show(int.Parse(cboNoSoins.SelectedValue.ToString()).ToString());
        }

        private void fillToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.numeroNomEtPrenomAssistantTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.NumeroNomEtPrenomAssistant, ((int)(System.Convert.ChangeType(noSoinsToolStripTextBox.Text, typeof(int)))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {
            if (txtHeure.Text == "")
            {
                errMessage.SetError(txtHeure, "L'heure ne peut être vide");
            }
            else if(int.Parse(txtHeure.Text)<8 && int.Parse(txtHeure.Text) > 17)
            {
                errMessage.SetError(txtHeure, "L'heure ne peut être inférieur à 8 ou suppérieur à 17 ");
            }
            if(dtpDate.Value.CompareTo(DateTime.Now) < 0)
            {
                errMessage.SetError(dtpDate, "La date ne peut être antérieur à la date du jour");
            }

            else if (dtpDate.Value.DayOfWeek.ToString().Equals("Sunday") || dtpDate.Value.DayOfWeek.ToString().Equals("Saturday"))
            {
                errMessage.SetError(dtpDate, "La date ne peut être un samedi ou un dimanche");
            }
            fo
        }
    }
}
