﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmGestionAssistant : Form
    {
        public String noUtilisateur;
        static String maChaineDeConnexion = "Data Source = sqlinfo.cgodin.qc.ca; Initial Catalog = BD5B6TP1_KoumaJouanique; Persist Security Info=True;User ID = 5B6Kouma;Password=1PetitDioulaBanchi";
        SqlConnection maConnexion = new SqlConnection(maChaineDeConnexion);
        public frmGestionAssistant()
        {
            InitializeComponent();
        }

        private void frmGestionAssistant_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.AssistantSoin'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.assistantSoinTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.AssistantSoin);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Soin'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.soinTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Soin);
            // TODO: cette ligne de code charge les données dans la table 'bD5B6TP1_KoumaJouaniqueDataSet.Assistant'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.assistantTableAdapter.Fill(this.bD5B6TP1_KoumaJouaniqueDataSet.Assistant);

        }

        private void btnPremierAssistant_Click(object sender, EventArgs e)
        {
            assistantBindingSource.MoveFirst();
        }

        private void btnAssistantPrecedent_Click(object sender, EventArgs e)
        {
            assistantBindingSource.MovePrevious();
        }

        private void btnAssistantSuivant_Click(object sender, EventArgs e)
        {
            assistantBindingSource.MoveNext();
        }

        private void btnDernierAssistant_Click(object sender, EventArgs e)
        {
            assistantBindingSource.MoveLast();
        }

        private void btnSupprAssistant_Click(object sender, EventArgs e)
        {
            String strPrenomNomAssistant = dgAssistant.CurrentRow.Cells[1].Value.ToString() + " " + dgAssistant.CurrentRow.Cells[2].Value.ToString();
            DialogResult res = MessageBox.Show(this, "Voulez-vous vraiment supprimer l'assistant " + strPrenomNomAssistant + "?", "Suppression d'un assistant", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
            if (res == DialogResult.OK)
            {
                assistantBindingSource.RemoveCurrent();
                try
                {
                    tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                }
                catch (DBConcurrencyException erreur)
                {
                    String strNomComplet = erreur.Row["dgPrenom"].ToString() + " " + erreur.Row["dgNom"].ToString();
                    MessageBox.Show("Conflit d'accès concurrentiel pour l'assistant " + strNomComplet + ".Aucun enregistrement possible.", "Conflit d'accès");
                }
            }
        }

        private void btnAjouterAssistant_Click(object sender, EventArgs e)
        {
            assistantBindingSource.CancelEdit();
            assistantBindingSource.AddNew();
            maConnexion.Open();
            SqlCommand maCommande = new SqlCommand(" SELECT MAX(NoAssistant) FROM Assistant ", maConnexion);
            dynamic NoAssistant = maCommande.ExecuteScalar();
            if (dgAssistant.RowCount > 1)
            {
                dgAssistant.CurrentRow.Cells[0].Value = NoAssistant +1;
            }
            else
            {
                dgAssistant.CurrentRow.Cells[0].Value = 1;
            }
            maConnexion.Close();
        }

        private void dgAssistant_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {
            String msgErreur = "";
            if (dgAssistant["dgNoAssistant", e.RowIndex].Value != null)
            {
                String strNoAssistant = dgAssistant["dgNoAssistant", e.RowIndex].Value.ToString();
                String strPrenomAssistant= dgAssistant["dgPrenom", e.RowIndex].Value.ToString();
                String strNomAssistant = dgAssistant["dgNom", e.RowIndex].Value.ToString();
                String strSpecialites = dgAssistant["dgSpecialites", e.RowIndex].Value.ToString();


                if (strNoAssistant.Trim() == "" || strPrenomAssistant.Trim() == "" || strNomAssistant.Trim() == "" || strSpecialites.Trim() == "")
                {
                    msgErreur = "Seule la colonne remarque peut être vide";
                    e.Cancel = true;
                }
                else
                {

                    SqlCommand maCommande = new SqlCommand(" SELECT NoAssistant FROM Assistant WHERE NoAssistant = '" + strNoAssistant + "'", maConnexion);
                    maConnexion.Open();
                    SqlDataReader monReader = maCommande.ExecuteReader();
                    if (monReader.Read())
                    {
                        try
                        {
                            tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                        }
                        catch (DBConcurrencyException erreur)
                        {
                            String strNomComplet = erreur.Row["dgPrenom"].ToString() + " " + erreur.Row["dgNom"].ToString();
                            MessageBox.Show("Conflit d'accès concurrentiel pour l'assistant " + strNomComplet + ".Aucun enregistrement possible.", "Conflit d'accès");
                        }
                    }
                    else
                    {
                        try
                        {
                            tableAdapterManager.UpdateAll(bD5B6TP1_KoumaJouaniqueDataSet);
                        }
                        catch (DBConcurrencyException erreur)
                        {
                            String strNomComplet = erreur.Row["dgPrenom"].ToString() + " " + erreur.Row["dgNom"].ToString();
                            MessageBox.Show("Conflit d'accès concurrentiel pour l'assistant " + strNomComplet + ".Aucun enregistrement possible.", "Conflit d'accès");
                        }
                    }
                    monReader.Close();
                    maConnexion.Close();
                }
                dgAssistant.Rows[e.RowIndex].ErrorText = msgErreur;
            }
        }
    }
}
