﻿namespace TP1
{
    partial class frmGestionClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgClient = new System.Windows.Forms.DataGridView();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.btnSupprClient = new System.Windows.Forms.Button();
            this.btnAjouterClient = new System.Windows.Forms.Button();
            this.btnDernierClient = new System.Windows.Forms.Button();
            this.btnClientSuivant = new System.Windows.Forms.Button();
            this.btnClientlPrecedent = new System.Windows.Forms.Button();
            this.btnPremierClient = new System.Windows.Forms.Button();
            this.inviteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dgInvite = new System.Windows.Forms.DataGridView();
            this.noInviteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomPrenomDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bD5B6TP1_KoumaJouaniqueDataSet = new TP1.BD5B6TP1_KoumaJouaniqueDataSet();
            this.dgNoClient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgNom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPrenom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgVille = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgPays = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgAdresse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgCodePostal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgDateInscription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ClientTableAdapter();
            this.tableAdapterManager = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager();
            this.inviteTableAdapter = new TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.InviteTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dgClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inviteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgInvite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dgClient
            // 
            this.dgClient.AllowUserToAddRows = false;
            this.dgClient.AllowUserToDeleteRows = false;
            this.dgClient.AutoGenerateColumns = false;
            this.dgClient.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgClient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgClient.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgNoClient,
            this.dgNom,
            this.dgPrenom,
            this.dgVille,
            this.dgPays,
            this.dgAdresse,
            this.dgCodePostal,
            this.dgDateInscription});
            this.dgClient.DataSource = this.clientBindingSource;
            this.dgClient.Location = new System.Drawing.Point(12, 12);
            this.dgClient.Name = "dgClient";
            this.dgClient.Size = new System.Drawing.Size(864, 220);
            this.dgClient.TabIndex = 1;
            this.dgClient.RowValidating += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgClient_RowValidating);
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(707, 383);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(169, 23);
            this.btnAnnuler.TabIndex = 22;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
            // 
            // btnSupprClient
            // 
            this.btnSupprClient.Location = new System.Drawing.Point(707, 412);
            this.btnSupprClient.Name = "btnSupprClient";
            this.btnSupprClient.Size = new System.Drawing.Size(169, 23);
            this.btnSupprClient.TabIndex = 21;
            this.btnSupprClient.Text = "Supprimer client";
            this.btnSupprClient.UseVisualStyleBackColor = true;
            this.btnSupprClient.Click += new System.EventHandler(this.btnSupprClient_Click);
            // 
            // btnAjouterClient
            // 
            this.btnAjouterClient.Location = new System.Drawing.Point(707, 354);
            this.btnAjouterClient.Name = "btnAjouterClient";
            this.btnAjouterClient.Size = new System.Drawing.Size(169, 23);
            this.btnAjouterClient.TabIndex = 20;
            this.btnAjouterClient.Text = "Ajouter client";
            this.btnAjouterClient.UseVisualStyleBackColor = true;
            this.btnAjouterClient.Click += new System.EventHandler(this.btnAjouterClient_Click);
            // 
            // btnDernierClient
            // 
            this.btnDernierClient.Location = new System.Drawing.Point(707, 325);
            this.btnDernierClient.Name = "btnDernierClient";
            this.btnDernierClient.Size = new System.Drawing.Size(169, 23);
            this.btnDernierClient.TabIndex = 19;
            this.btnDernierClient.Text = "Dernier client";
            this.btnDernierClient.UseVisualStyleBackColor = true;
            this.btnDernierClient.Click += new System.EventHandler(this.btnDernierClient_Click);
            // 
            // btnClientSuivant
            // 
            this.btnClientSuivant.Location = new System.Drawing.Point(707, 296);
            this.btnClientSuivant.Name = "btnClientSuivant";
            this.btnClientSuivant.Size = new System.Drawing.Size(169, 23);
            this.btnClientSuivant.TabIndex = 18;
            this.btnClientSuivant.Text = "Client suivant";
            this.btnClientSuivant.UseVisualStyleBackColor = true;
            this.btnClientSuivant.Click += new System.EventHandler(this.btnClientSuivant_Click);
            // 
            // btnClientlPrecedent
            // 
            this.btnClientlPrecedent.Location = new System.Drawing.Point(707, 267);
            this.btnClientlPrecedent.Name = "btnClientlPrecedent";
            this.btnClientlPrecedent.Size = new System.Drawing.Size(169, 23);
            this.btnClientlPrecedent.TabIndex = 17;
            this.btnClientlPrecedent.Text = "Client précédent";
            this.btnClientlPrecedent.UseVisualStyleBackColor = true;
            this.btnClientlPrecedent.Click += new System.EventHandler(this.btnClientPrecedent_Click);
            // 
            // btnPremierClient
            // 
            this.btnPremierClient.Location = new System.Drawing.Point(707, 238);
            this.btnPremierClient.Name = "btnPremierClient";
            this.btnPremierClient.Size = new System.Drawing.Size(169, 23);
            this.btnPremierClient.TabIndex = 16;
            this.btnPremierClient.Text = "Premier client";
            this.btnPremierClient.UseVisualStyleBackColor = true;
            this.btnPremierClient.Click += new System.EventHandler(this.btnPremierClient_Click);
            // 
            // inviteBindingSource
            // 
            this.inviteBindingSource.DataMember = "FK_NoClientInvite";
            this.inviteBindingSource.DataSource = this.clientBindingSource;
            // 
            // dgInvite
            // 
            this.dgInvite.AllowUserToAddRows = false;
            this.dgInvite.AllowUserToDeleteRows = false;
            this.dgInvite.AutoGenerateColumns = false;
            this.dgInvite.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgInvite.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgInvite.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.noInviteDataGridViewTextBoxColumn,
            this.nomPrenomDataGridViewTextBoxColumn});
            this.dgInvite.DataSource = this.inviteBindingSource;
            this.dgInvite.Enabled = false;
            this.dgInvite.Location = new System.Drawing.Point(12, 238);
            this.dgInvite.Name = "dgInvite";
            this.dgInvite.ReadOnly = true;
            this.dgInvite.Size = new System.Drawing.Size(689, 197);
            this.dgInvite.TabIndex = 1;
            // 
            // noInviteDataGridViewTextBoxColumn
            // 
            this.noInviteDataGridViewTextBoxColumn.DataPropertyName = "NoInvite";
            this.noInviteDataGridViewTextBoxColumn.HeaderText = "NoInvite";
            this.noInviteDataGridViewTextBoxColumn.Name = "noInviteDataGridViewTextBoxColumn";
            this.noInviteDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nomPrenomDataGridViewTextBoxColumn
            // 
            this.nomPrenomDataGridViewTextBoxColumn.DataPropertyName = "NomPrenom";
            this.nomPrenomDataGridViewTextBoxColumn.HeaderText = "NomPrenom";
            this.nomPrenomDataGridViewTextBoxColumn.Name = "nomPrenomDataGridViewTextBoxColumn";
            this.nomPrenomDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            this.clientBindingSource.DataSource = this.bD5B6TP1_KoumaJouaniqueDataSet;
            // 
            // bD5B6TP1_KoumaJouaniqueDataSet
            // 
            this.bD5B6TP1_KoumaJouaniqueDataSet.DataSetName = "BD5B6TP1_KoumaJouaniqueDataSet";
            this.bD5B6TP1_KoumaJouaniqueDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dgNoClient
            // 
            this.dgNoClient.DataPropertyName = "NoClient";
            this.dgNoClient.HeaderText = "Numéro de client";
            this.dgNoClient.Name = "dgNoClient";
            // 
            // dgNom
            // 
            this.dgNom.DataPropertyName = "Nom";
            this.dgNom.HeaderText = "Nom";
            this.dgNom.MaxInputLength = 20;
            this.dgNom.Name = "dgNom";
            // 
            // dgPrenom
            // 
            this.dgPrenom.DataPropertyName = "Prenom";
            this.dgPrenom.HeaderText = "Prénom";
            this.dgPrenom.MaxInputLength = 20;
            this.dgPrenom.Name = "dgPrenom";
            // 
            // dgVille
            // 
            this.dgVille.DataPropertyName = "Ville";
            this.dgVille.HeaderText = "Ville";
            this.dgVille.MaxInputLength = 30;
            this.dgVille.Name = "dgVille";
            // 
            // dgPays
            // 
            this.dgPays.DataPropertyName = "Pays";
            this.dgPays.HeaderText = "Pays";
            this.dgPays.MaxInputLength = 20;
            this.dgPays.Name = "dgPays";
            // 
            // dgAdresse
            // 
            this.dgAdresse.DataPropertyName = "Adresse";
            this.dgAdresse.HeaderText = "Adresse";
            this.dgAdresse.MaxInputLength = 50;
            this.dgAdresse.Name = "dgAdresse";
            // 
            // dgCodePostal
            // 
            this.dgCodePostal.DataPropertyName = "CodePostal";
            this.dgCodePostal.HeaderText = "Code postal";
            this.dgCodePostal.MaxInputLength = 7;
            this.dgCodePostal.Name = "dgCodePostal";
            // 
            // dgDateInscription
            // 
            this.dgDateInscription.DataPropertyName = "DateInscription";
            this.dgDateInscription.HeaderText = "Date d\'inscription";
            this.dgDateInscription.Name = "dgDateInscription";
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssistantSoinTableAdapter = null;
            this.tableAdapterManager.AssistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ChambreTableAdapter = null;
            this.tableAdapterManager.ClientTableAdapter = this.clientTableAdapter;
            this.tableAdapterManager.InviteTableAdapter = this.inviteTableAdapter;
            this.tableAdapterManager.PlanifSoinTableAdapter = null;
            this.tableAdapterManager.ReservationChambreTableAdapter = null;
            this.tableAdapterManager.SoinTableAdapter = null;
            this.tableAdapterManager.TypeChambreTableAdapter = null;
            this.tableAdapterManager.TypeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TP1.BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UtilisateurTableAdapter = null;
            // 
            // inviteTableAdapter
            // 
            this.inviteTableAdapter.ClearBeforeFill = true;
            // 
            // frmGestionClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(896, 452);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnSupprClient);
            this.Controls.Add(this.btnAjouterClient);
            this.Controls.Add(this.btnDernierClient);
            this.Controls.Add(this.btnClientSuivant);
            this.Controls.Add(this.btnClientlPrecedent);
            this.Controls.Add(this.btnPremierClient);
            this.Controls.Add(this.dgInvite);
            this.Controls.Add(this.dgClient);
            this.Name = "frmGestionClient";
            this.Text = "Gestion de clients";
            this.Load += new System.EventHandler(this.frmGestionClient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inviteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgInvite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bD5B6TP1_KoumaJouaniqueDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private BD5B6TP1_KoumaJouaniqueDataSet bD5B6TP1_KoumaJouaniqueDataSet;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.ClientTableAdapter clientTableAdapter;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView dgClient;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.Button btnSupprClient;
        private System.Windows.Forms.Button btnAjouterClient;
        private System.Windows.Forms.Button btnDernierClient;
        private System.Windows.Forms.Button btnClientSuivant;
        private System.Windows.Forms.Button btnClientlPrecedent;
        private System.Windows.Forms.Button btnPremierClient;
        private BD5B6TP1_KoumaJouaniqueDataSetTableAdapters.InviteTableAdapter inviteTableAdapter;
        private System.Windows.Forms.BindingSource inviteBindingSource;
        private System.Windows.Forms.DataGridView dgInvite;
        private System.Windows.Forms.DataGridViewTextBoxColumn noInviteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomPrenomDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgNoClient;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgNom;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgPrenom;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgVille;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgPays;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgAdresse;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgCodePostal;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgDateInscription;
    }
}