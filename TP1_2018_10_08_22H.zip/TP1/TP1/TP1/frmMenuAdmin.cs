﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1
{
    public partial class frmMenuAdmin : Form
    {
        public String noUtilisateur;
        public frmMenuAdmin()
        {
            InitializeComponent();
        }

        private void lblBienvenue_Click(object sender, EventArgs e)
        {

        }

        private void btnGererUsers_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmGestionUtilisateur fGestionUtilisateur = new frmGestionUtilisateur();
            fGestionUtilisateur.noUtilisateur = noUtilisateur;
            fGestionUtilisateur.ShowDialog();
            this.Show();
        }

        private void btnGererCLientEtInvite_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMenuGestionClientInvite fMenuGestionClientInvité = new frmMenuGestionClientInvite();
            fMenuGestionClientInvité.ShowDialog();
            this.Show();
        }

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }

        private void btnDeconnexion_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
