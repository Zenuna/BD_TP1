﻿namespace TP1
{
}

namespace TP1
{


    public partial class BD5B6TP1_KoumaJouaniqueDataSet
    {
    }
}
